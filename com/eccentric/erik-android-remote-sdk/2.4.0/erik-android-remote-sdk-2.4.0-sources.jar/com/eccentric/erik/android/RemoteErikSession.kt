package com.eccentric.erik.android

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Parcel
import android.view.MotionEvent
import android.view.SurfaceControlViewHost
import androidx.annotation.RequiresApi
import com.eccentric.erik.ipc.ErikIpcContract
import com.eccentric.erik.ipc.IErikClient
import com.eccentric.erik.ipc.IErikRenderService
import java.io.File
import java.security.SecureRandom
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong
import org.json.JSONObject

/**
 * One process-scoped Erik runtime session.
 *
 * The expensive renderer belongs to this object, while individual
 * [RemoteErikView] instances are temporary surface attachments.
 */
@RequiresApi(android.os.Build.VERSION_CODES.R)
internal class RemoteErikSession private constructor(
    private val applicationContext: Context,
    private val endpoint: ErikServiceEndpoint,
    private var assetDirectoryPath: String?,
) {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val ipcExecutor = Executors.newSingleThreadExecutor()
    private val requestIds = AtomicLong(1)
    private val sessionId = nextSessionId()
    private val pendingCommands = ArrayDeque<PendingCommand>()
    private val activeRequests = mutableMapOf<Long, ActiveRequest>()
    private val doorCommandOrder = ErikDoorCommandOrder()
    private val hotspotListeners = mutableMapOf<Any, (ErikHotspotResult) -> Unit>()
    private val listeners = mutableMapOf<Any, (ErikRuntimeState) -> Unit>()

    private var service: IErikRenderService? = null
    private var serviceBinder: IBinder? = null
    private var serviceDeathRecipient: IBinder.DeathRecipient? = null
    private var cachedState = ErikRuntimeState()
    private var desiredState = ErikState()
    private var desiredStateVersion = 0L
    private var assetDirectoryVersion = 0L
    private var attachmentStateSeeded = false
    private var surfacePackage: SurfaceControlViewHost.SurfacePackage? = null
    private var surfaceHostToken: IBinder? = null
    private var surfaceDisplayId: Int? = null
    private var bound = false
    private var runtimeSessionExists = false
    private var showingInterior = false
    private var attachment: Attachment? = null
    private var nextAttachmentGeneration = 1L
    private var creatingAttachmentGeneration: Long? = null

    private val clientCallback =
        object : IErikClient.Stub() {
            override fun onRuntimeStateChanged(
                callbackSessionId: Long,
                isIntroAnimationPlaying: Boolean,
                isInitializationComplete: Boolean,
            ) {
                if (callbackSessionId != sessionId) {
                    return
                }
                mainHandler.post {
                    cachedState =
                        ErikRuntimeState(
                            isIntroAnimationPlaying = isIntroAnimationPlaying,
                            isInitializationComplete = isInitializationComplete,
                        )
                    listeners.values.toList().forEach { it(cachedState) }
                }
            }

            override fun onHotspotResult(callbackSessionId: Long, resultJson: String) {
                if (callbackSessionId != sessionId) return
                val result = ErikHotspotResult.fromJson(resultJson) ?: return
                mainHandler.post {
                    if (!doorCommandOrder.accepts(result)) return@post
                    if (result.errorMessage == null) remember(ErikState(doorStates = mapOf(result.door to result.isOpen)))
                    hotspotListeners.values.toList().forEach { it(result) }
                }
            }

            override fun onCommandResult(
                callbackSessionId: Long,
                requestId: Long,
                success: Boolean,
                result: String,
                errorMessage: String,
            ) {
                if (callbackSessionId != sessionId) {
                    return
                }
                mainHandler.post {
                    val callback = removeActiveRequest(requestId)?.callback ?: return@post
                    if (success) {
                        callback.onSuccess(result)
                    } else {
                        callback.onError(errorMessage.ifBlank { "Erik command failed." })
                    }
                }
            }
        }

    private val serviceConnection =
        object : ServiceConnection {
            override fun onServiceConnected(
                name: ComponentName,
                binder: IBinder,
            ) {
                val connectedService = IErikRenderService.Stub.asInterface(binder)
                service = connectedService
                serviceBinder = binder
                val deathRecipient =
                    IBinder.DeathRecipient {
                        mainHandler.post {
                            handleServiceLoss("Erik runtime process terminated.")
                        }
                    }
                serviceDeathRecipient = deathRecipient
                runCatching { binder.linkToDeath(deathRecipient, 0) }
                    .onFailure {
                        handleServiceLoss("Unable to monitor the Erik runtime connection.")
                        return
                    }
                maybeAttach()
            }

            override fun onServiceDisconnected(name: ComponentName) {
                handleServiceLoss("Erik runtime service disconnected.")
            }

            override fun onBindingDied(name: ComponentName) {
                handleServiceLoss("Erik runtime binding died.")
            }

            override fun onNullBinding(name: ComponentName) {
                handleServiceLoss("Erik runtime rejected the connection.")
            }
        }

    fun setListener(
        owner: Any,
        listener: ((ErikRuntimeState) -> Unit)?,
    ) {
        if (listener == null) {
            listeners.remove(owner)
        } else {
            listeners[owner] = listener
            listener(cachedState)
        }
    }

    fun setHotspotListener(owner: Any, listener: ((ErikHotspotResult) -> Unit)?) {
        if (listener == null) hotspotListeners.remove(owner) else hotspotListeners[owner] = listener
    }

    fun currentState(): ErikRuntimeState = cachedState

    fun isShowingInterior(): Boolean = showingInterior

    fun attach(
        owner: Any,
        hostToken: IBinder,
        displayId: Int,
        width: Int,
        height: Int,
        onSurfacePackage: (SurfaceControlViewHost.SurfacePackage) -> Unit,
        onSurfaceLost: () -> Unit,
        onError: (String) -> Unit,
    ) {
        val current = attachment
        if (
            current != null &&
            current.owner === owner &&
            current.hostToken == hostToken &&
            current.displayId == displayId
        ) {
            current.width = width.coerceAtLeast(1)
            current.height = height.coerceAtLeast(1)
            current.onSurfacePackage = onSurfacePackage
            current.onSurfaceLost = onSurfaceLost
            current.onError = onError
            if (current.attached) {
                runCatching {
                    service?.resize(sessionId, current.width, current.height)
                }
            } else {
                maybeAttach()
            }
            return
        }

        current?.onSurfaceLost?.invoke()
        attachment =
            Attachment(
                owner = owner,
                generation = nextAttachmentGeneration++,
                hostToken = hostToken,
                displayId = displayId,
                width = width.coerceAtLeast(1),
                height = height.coerceAtLeast(1),
                onSurfacePackage = onSurfacePackage,
                onSurfaceLost = onSurfaceLost,
                onError = onError,
            )
        val reusableSurfacePackage = surfacePackage
        if (
            runtimeSessionExists &&
            reusableSurfacePackage != null &&
            surfaceHostToken == hostToken &&
            surfaceDisplayId == displayId
        ) {
            attachment?.attached = true
            runCatching {
                service?.resize(sessionId, width.coerceAtLeast(1), height.coerceAtLeast(1))
            }
            onSurfacePackage(reusableSurfacePackage.copyForTransfer())
            return
        }

        runtimeSessionExists = false
        releaseSurfacePackage()
        bindRuntime()
        maybeAttach()
    }

    fun detach(owner: Any) {
        val current = attachment
        if (current?.owner !== owner) {
            listeners.remove(owner)
            hotspotListeners.remove(owner)
            return
        }
        current.onSurfaceLost()
        attachment = null
        listeners.remove(owner)
        hotspotListeners.remove(owner)
    }

    fun resume(owner: Any) {
        val current = attachment?.takeIf { it.owner === owner } ?: return
        current.resumed = true
        if (runtimeSessionExists) {
            runCatching { service?.resumeSession(sessionId) }
        }
    }

    fun pause(owner: Any) {
        val current = attachment?.takeIf { it.owner === owner } ?: return
        current.resumed = false
        if (runtimeSessionExists) {
            runCatching { service?.pauseSession(sessionId) }
        }
    }

    fun dispatchTouch(event: MotionEvent): Boolean {
        val connectedService = service
        if (!runtimeSessionExists || connectedService == null) {
            return false
        }
        return runCatching {
            connectedService.dispatchTouch(sessionId, event)
            true
        }.getOrElse {
            handleServiceLoss("Erik runtime connection failed.")
            false
        }
    }

    fun initialize(
        state: ErikState,
        callback: ErikCommandCallback,
    ) {
        if (state == ErikState()) {
            callback.onSuccess()
            maybeAttach()
            return
        }
        attachmentStateSeeded = true
        val stateChanged = remember(state)
        if (!runtimeSessionExists) {
            callback.onSuccess()
            maybeAttach()
            return
        }
        if (!stateChanged) {
            callback.onSuccess()
            return
        }
        sendCommand(
            ErikIpcContract.COMMAND_INIT,
            Bundle().apply {
                putString(ErikIpcContract.ARG_STATE_JSON, state.toJson())
            },
            callback.toRemoteResult(),
        )
    }

    /**
     * Uses a Fragment's desired state only to seed the process-scoped session.
     *
     * A later Fragment can contain an older local copy of the state while the
     * renderer has continued running. Replaying that copy during attachment
     * would animate the live car backwards before a fresh snapshot arrives.
     */
    fun initializeForAttachment(
        state: ErikState,
        applyExplicitState: Boolean,
        callback: ErikCommandCallback,
    ) {
        if (applyExplicitState) {
            initialize(state, callback)
            return
        }
        if (state == ErikState() || attachmentStateSeeded) {
            callback.onSuccess()
            maybeAttach()
            return
        }
        initialize(state, callback)
    }

    fun getState(callback: ErikJsonCallback) {
        sendCommand(
            ErikIpcContract.COMMAND_GET_STATE,
            Bundle(),
            object : PendingResult {
                override fun onSuccess(result: String) {
                    runCatching { ErikState.fromJson(result) }
                        .onSuccess(::replaceDesiredState)
                    callback.onSuccess(result)
                }

                override fun onError(message: String) {
                    callback.onError(message)
                }
            },
        )
    }

    fun getAssetConfig(callback: ErikJsonCallback) {
        sendCommand(
            ErikIpcContract.COMMAND_GET_ASSET_CONFIG,
            Bundle(),
            callback.toRemoteResult(),
        )
    }

    fun getCapabilities(callback: ErikJsonCallback) {
        sendCommand(
            ErikIpcContract.COMMAND_GET_CAPABILITIES,
            Bundle(),
            callback.toRemoteResult(),
        )
    }

    fun openDoor(
        door: ErikDoor,
        callback: ErikCommandCallback,
    ) {
        rememberDoor(door, open = true)
        sendEnumCommand(ErikIpcContract.COMMAND_OPEN_DOOR, ErikIpcContract.ARG_DOOR, door, callback)
    }

    fun closeDoor(
        door: ErikDoor,
        callback: ErikCommandCallback,
    ) {
        rememberDoor(door, open = false)
        sendEnumCommand(ErikIpcContract.COMMAND_CLOSE_DOOR, ErikIpcContract.ARG_DOOR, door, callback)
    }

    fun setAllDoorsOpen(
        open: Boolean,
        callback: ErikCommandCallback,
    ) {
        rememberAllDoors(open)
        sendCommand(
            ErikIpcContract.COMMAND_SET_ALL_DOORS_OPEN,
            Bundle().apply { putBoolean(ErikIpcContract.ARG_OPEN, open) },
            callback.toRemoteResult(),
        )
    }

    fun play(
        name: String,
        direction: String,
        callback: ErikCommandCallback,
    ) {
        rememberDoorAnimation(name, direction)
        sendCommand(
            ErikIpcContract.COMMAND_PLAY,
            Bundle().apply {
                putString(ErikIpcContract.ARG_NAME, name)
                putString(ErikIpcContract.ARG_DIRECTION, direction)
            },
            callback.toRemoteResult(),
        )
    }

    fun allDoors(
        direction: String,
        callback: ErikCommandCallback,
    ) {
        rememberAllDoorsDirection(direction)
        sendCommand(
            ErikIpcContract.COMMAND_ALL_DOORS,
            Bundle().apply { putString(ErikIpcContract.ARG_DIRECTION, direction) },
            callback.toRemoteResult(),
        )
    }

    fun goInterior(callback: ErikCommandCallback) {
        showingInterior = true
        sendCommand(ErikIpcContract.COMMAND_GO_INTERIOR, Bundle(), callback.toRemoteResult())
    }

    fun goExterior(callback: ErikCommandCallback) {
        showingInterior = false
        sendCommand(ErikIpcContract.COMMAND_GO_EXTERIOR, Bundle(), callback.toRemoteResult())
    }

    fun toggleLights(
        lightsOn: Boolean,
        callback: ErikCommandCallback,
    ) {
        remember(ErikState(lightsOn = lightsOn))
        sendCommand(
            ErikIpcContract.COMMAND_TOGGLE_LIGHTS,
            Bundle().apply { putBoolean(ErikIpcContract.ARG_LIGHTS_ON, lightsOn) },
            callback.toRemoteResult(),
        )
    }

    fun setLightState(
        light: ErikLight,
        state: ErikLightState,
        callback: ErikCommandCallback,
    ) {
        remember(ErikState(lightStates = mapOf(light to state)))
        sendCommand(
            ErikIpcContract.COMMAND_SET_LIGHT_STATE,
            Bundle().apply {
                putString(ErikIpcContract.ARG_LIGHT, light.name)
                putString(ErikIpcContract.ARG_LIGHT_STATE, state.name)
            },
            callback.toRemoteResult(),
        )
    }

    fun setRotationSpeed(
        speed: Double,
        callback: ErikCommandCallback,
    ) {
        remember(ErikState(rotationSpeed = speed))
        sendCommand(
            ErikIpcContract.COMMAND_SET_ROTATION_SPEED,
            Bundle().apply { putDouble(ErikIpcContract.ARG_SPEED, speed) },
            callback.toRemoteResult(),
        )
    }

    fun setColor(
        colorName: String,
        callback: ErikCommandCallback,
    ) {
        remember(ErikState(carpaint = colorName))
        sendCommand(
            ErikIpcContract.COMMAND_SET_COLOR,
            Bundle().apply { putString(ErikIpcContract.ARG_COLOR, colorName) },
            callback.toRemoteResult(),
        )
    }

    fun setBGColor(
        hex: String,
        callback: ErikCommandCallback,
    ) {
        remember(ErikState(background = ErikBackgroundState(transparent = false, color = hex)))
        sendCommand(
            ErikIpcContract.COMMAND_SET_BG_COLOR,
            Bundle().apply { putString(ErikIpcContract.ARG_HEX, hex) },
            callback.toRemoteResult(),
        )
    }

    fun skipIntro(callback: ErikCommandCallback) {
        sendCommand(ErikIpcContract.COMMAND_SKIP_INTRO, Bundle(), callback.toRemoteResult())
    }

    fun doorStates(callback: ErikJsonCallback) {
        sendCommand(ErikIpcContract.COMMAND_DOOR_STATES, Bundle(), callback.toRemoteResult())
    }

    private fun bindRuntime() {
        if (bound) {
            return
        }
        val intent = endpoint.createIntent()
        val didBind =
            runCatching {
                applicationContext.bindService(
                    intent,
                    serviceConnection,
                    Context.BIND_AUTO_CREATE or Context.BIND_IMPORTANT,
                )
            }.getOrElse {
                failAllCommands(it.message ?: "Unable to bind to ${endpoint.description}.")
                false
            }
        bound = didBind
        if (!didBind) {
            val message = "${endpoint.description} is unavailable or cannot be accessed."
            failAllCommands(message)
            attachment?.onError?.invoke(message)
        }
    }

    @Suppress("DEPRECATION")
    private fun maybeAttach() {
        val connectedService = service ?: return
        val requestedAttachment = attachment ?: return
        if (
            requestedAttachment.attached ||
            creatingAttachmentGeneration != null
        ) {
            return
        }

        val requestedGeneration = requestedAttachment.generation
        val requestedStateVersion = desiredStateVersion
        val requestedState = JSONObject(desiredState.toJson()).apply {
            put(ErikDoorCommandOrder.STATE_TOKENS, JSONObject(doorCommandOrder.toJson()))
        }.toString()
        val requestedAssetDirectoryVersion = assetDirectoryVersion
        val requestedAssetDirectoryPath = assetDirectoryPath.orEmpty()
        creatingAttachmentGeneration = requestedGeneration
        ipcExecutor.execute {
            runCatching {
                val runtimeProtocol = connectedService.protocolVersion
                check(runtimeProtocol == ErikIpcContract.PROTOCOL_VERSION) {
                    "Incompatible Erik runtime protocol. Client=${ErikIpcContract.PROTOCOL_VERSION}, runtime=$runtimeProtocol."
                }
                connectedService.createSession(
                    sessionId,
                    requestedAttachment.hostToken,
                    requestedAttachment.displayId,
                    requestedAttachment.width,
                    requestedAttachment.height,
                    requestedState,
                    requestedAssetDirectoryPath,
                    clientCallback,
                )
            }.onSuccess { surfacePackage ->
                mainHandler.post {
                    if (assetDirectoryVersion != requestedAssetDirectoryVersion) {
                        surfacePackage?.release()
                        return@post
                    }
                    creatingAttachmentGeneration = null
                    val current = attachment
                    if (
                        current == null ||
                        current.generation != requestedGeneration ||
                        service !== connectedService
                    ) {
                        surfacePackage?.release()
                        maybeAttach()
                        return@post
                    }
                    if (surfacePackage == null) {
                        current.onError("Erik runtime returned no rendering surface.")
                        return@post
                    }

                    runtimeSessionExists = true
                    attachmentStateSeeded = true
                    this@RemoteErikSession.surfacePackage =
                        surfacePackage.copyForTransfer()
                    surfaceHostToken = current.hostToken
                    surfaceDisplayId = current.displayId
                    current.attached = true
                    current.onSurfacePackage(surfacePackage)
                    if (desiredStateVersion != requestedStateVersion) {
                        pendingCommands.addFirst(
                            PendingCommand(
                                command = ErikIpcContract.COMMAND_INIT,
                                arguments =
                                    Bundle().apply {
                                        putString(ErikIpcContract.ARG_STATE_JSON, desiredState.toJson())
                                    },
                                callback = PendingResult.NONE,
                            ),
                        )
                    }
                    if (current.resumed) {
                        runCatching { connectedService.resumeSession(sessionId) }
                    }
                    flushPendingCommands()
                }
            }.onFailure { error ->
                mainHandler.post {
                    if (assetDirectoryVersion != requestedAssetDirectoryVersion) {
                        return@post
                    }
                    creatingAttachmentGeneration = null
                    attachment
                        ?.takeIf { it.generation == requestedGeneration }
                        ?.onError
                        ?.invoke(error.message ?: "Unable to attach the Erik rendering session.")
                    failAllCommands(error.message ?: "Unable to create the Erik rendering session.")
                    maybeAttach()
                }
            }
        }
    }

    private fun sendEnumCommand(
        command: String,
        key: String,
        value: Enum<*>,
        callback: ErikCommandCallback,
    ) {
        sendCommand(
            command,
            Bundle().apply { putString(key, value.name) },
            callback.toRemoteResult(),
        )
    }

    private fun prepareDoorCommand(command: String, arguments: Bundle) {
        val doors = when (command) {
            ErikIpcContract.COMMAND_INIT -> ErikState.fromJson(
                arguments.getString(ErikIpcContract.ARG_STATE_JSON) ?: "{}",
            ).doorStates?.keys.orEmpty()
            ErikIpcContract.COMMAND_OPEN_DOOR, ErikIpcContract.COMMAND_CLOSE_DOOR ->
                ErikDoor.entries.filter { it.name == arguments.getString(ErikIpcContract.ARG_DOOR) }
            ErikIpcContract.COMMAND_PLAY ->
                ErikDoor.entries.filter { it.jsName == arguments.getString(ErikIpcContract.ARG_NAME) }
            ErikIpcContract.COMMAND_ALL_DOORS, ErikIpcContract.COMMAND_SET_ALL_DOORS_OPEN ->
                allDoorsState(true).doorStates.orEmpty().keys
            else -> emptyList()
        }
        if (doors.isEmpty()) return
        val token = arguments.getString(ErikDoorCommandOrder.ARG_TOKEN)
            ?: java.util.UUID.randomUUID().toString()
        doorCommandOrder.record(doors, token)
        arguments.putString(ErikDoorCommandOrder.ARG_TOKEN, token)
    }

    private fun sendCommand(
        command: String,
        arguments: Bundle,
        callback: PendingResult,
    ) {
        prepareDoorCommand(command, arguments)
        val pending = PendingCommand(command, arguments, callback)
        if (!runtimeSessionExists || service == null) {
            pendingCommands.addLast(pending)
            bindRuntime()
            maybeAttach()
            return
        }
        executePendingCommand(pending)
    }

    private fun flushPendingCommands() {
        while (pendingCommands.isNotEmpty() && runtimeSessionExists && service != null) {
            executePendingCommand(pendingCommands.removeFirst())
        }
    }

    private fun executePendingCommand(pending: PendingCommand) {
        prepareDoorCommand(pending.command, pending.arguments)
        val connectedService = service
        if (connectedService == null) {
            pendingCommands.addFirst(pending)
            return
        }
        val requestId = requestIds.getAndIncrement()
        val timeout =
            Runnable {
                val request = activeRequests.remove(requestId) ?: return@Runnable
                request.callback.onError("Erik command timed out.")
            }
        activeRequests[requestId] = ActiveRequest(pending.callback, timeout)
        mainHandler.postDelayed(timeout, COMMAND_TIMEOUT_MS)
        try {
            connectedService.execute(sessionId, requestId, pending.command, pending.arguments, clientCallback)
        } catch (error: Exception) {
            removeActiveRequest(requestId)
            pending.callback.onError(error.message ?: "Erik runtime connection failed.")
            handleServiceLoss("Erik runtime connection failed.")
        }
    }

    private fun handleServiceLoss(message: String) {
        unlinkServiceDeathRecipient()
        service = null
        runtimeSessionExists = false
        creatingAttachmentGeneration = null
        cachedState = ErikRuntimeState()
        releaseSurfacePackage()
        attachment?.let {
            it.attached = false
            it.onSurfaceLost()
        }
        listeners.values.toList().forEach { it(cachedState) }
        failActiveRequests(message)
        if (bound) {
            runCatching { applicationContext.unbindService(serviceConnection) }
            bound = false
        }
        if (attachment != null) {
            mainHandler.postDelayed(
                {
                    bindRuntime()
                    maybeAttach()
                },
                REBIND_DELAY_MS,
            )
        }
    }

    private fun unlinkServiceDeathRecipient() {
        val binder = serviceBinder
        val recipient = serviceDeathRecipient
        if (binder != null && recipient != null) {
            runCatching { binder.unlinkToDeath(recipient, 0) }
        }
        serviceBinder = null
        serviceDeathRecipient = null
    }

    private fun changeAssetDirectory(newAssetDirectoryPath: String?) {
        if (assetDirectoryPath == newAssetDirectoryPath) {
            return
        }
        assetDirectoryPath = newAssetDirectoryPath
        assetDirectoryVersion += 1
        desiredState = ErikState()
        doorCommandOrder.restore("{}")
        desiredStateVersion += 1
        attachmentStateSeeded = false
        showingInterior = false
        creatingAttachmentGeneration = null
        attachment?.let {
            it.attached = false
            it.onSurfaceLost()
        }
        releaseSurfacePackage()
        failAllCommands("The selected vehicle changed.")
        runtimeSessionExists = false
        cachedState = ErikRuntimeState()
        listeners.values.toList().forEach { it(cachedState) }
        maybeAttach()
    }

    private fun releaseSurfacePackage() {
        surfacePackage?.release()
        surfacePackage = null
        surfaceHostToken = null
        surfaceDisplayId = null
    }

    private fun SurfaceControlViewHost.SurfacePackage.copyForTransfer():
        SurfaceControlViewHost.SurfacePackage {
        val parcel = Parcel.obtain()
        return try {
            writeToParcel(parcel, 0)
            parcel.setDataPosition(0)
            SurfaceControlViewHost.SurfacePackage.CREATOR.createFromParcel(parcel)
        } finally {
            parcel.recycle()
        }
    }

    private fun failAllCommands(message: String) {
        while (pendingCommands.isNotEmpty()) {
            pendingCommands.removeFirst().callback.onError(message)
        }
        failActiveRequests(message)
    }

    private fun failActiveRequests(message: String) {
        val requests = activeRequests.values.toList()
        activeRequests.clear()
        requests.forEach { request ->
            mainHandler.removeCallbacks(request.timeout)
            request.callback.onError(message)
        }
    }

    private fun removeActiveRequest(requestId: Long): ActiveRequest? =
        activeRequests.remove(requestId)?.also { mainHandler.removeCallbacks(it.timeout) }

    private fun ErikCommandCallback.toRemoteResult(): PendingResult =
        object : PendingResult {
            override fun onSuccess(result: String) {
                this@toRemoteResult.onSuccess()
            }

            override fun onError(message: String) {
                this@toRemoteResult.onError(message)
            }
        }

    private fun ErikJsonCallback.toRemoteResult(): PendingResult =
        object : PendingResult {
            override fun onSuccess(result: String) {
                this@toRemoteResult.onSuccess(result)
            }

            override fun onError(message: String) {
                this@toRemoteResult.onError(message)
            }
        }

    private fun remember(state: ErikState): Boolean {
        val mergedState = desiredState.mergedWith(state)
        if (mergedState == desiredState) {
            return false
        }
        desiredState = mergedState
        desiredStateVersion += 1
        return true
    }

    private fun replaceDesiredState(state: ErikState) {
        if (state == desiredState) {
            return
        }
        desiredState = state
        desiredStateVersion += 1
    }

    private fun rememberDoor(
        door: ErikDoor,
        open: Boolean,
    ) {
        remember(ErikState(doorStates = mapOf(door to open)))
    }

    private fun rememberDoorAnimation(name: String, direction: String) {
        doorAnimationState(name, direction)?.let { remember(it) }
    }

    private fun rememberAllDoorsDirection(direction: String) {
        allDoorsAnimationState(direction)?.let { remember(it) }
    }

    private fun rememberAllDoors(open: Boolean) {
        remember(allDoorsState(open))
    }

    private data class PendingCommand(
        val command: String,
        val arguments: Bundle,
        val callback: PendingResult,
    )

    private data class ActiveRequest(
        val callback: PendingResult,
        val timeout: Runnable,
    )

    private data class Attachment(
        val owner: Any,
        val generation: Long,
        val hostToken: IBinder,
        val displayId: Int,
        var width: Int,
        var height: Int,
        var onSurfacePackage: (SurfaceControlViewHost.SurfacePackage) -> Unit,
        var onSurfaceLost: () -> Unit,
        var onError: (String) -> Unit,
        var attached: Boolean = false,
        var resumed: Boolean = false,
    )

    private interface PendingResult {
        fun onSuccess(result: String)

        fun onError(message: String)

        companion object {
            val NONE =
                object : PendingResult {
                    override fun onSuccess(result: String) = Unit

                    override fun onError(message: String) = Unit
                }
        }
    }

    companion object {
        private const val REBIND_DELAY_MS = 500L
        private const val COMMAND_TIMEOUT_MS = 30_000L
        private val secureRandom = SecureRandom()

        private val instances = mutableMapOf<String, RemoteErikSession>()

        fun get(
            context: Context,
            endpoint: ErikServiceEndpoint = ErikServiceEndpoint.external(),
            assetDirectory: File? = null,
        ): RemoteErikSession =
            synchronized(this) {
                val assetDirectoryPath = assetDirectory?.canonicalPath
                val existing = instances[endpoint.key]
                if (existing != null) {
                    existing.changeAssetDirectory(assetDirectoryPath)
                    return@synchronized existing
                }
                RemoteErikSession(
                    applicationContext = context.applicationContext ?: context,
                    endpoint = endpoint,
                    assetDirectoryPath = assetDirectoryPath,
                ).also { instances[endpoint.key] = it }
            }

        private fun nextSessionId(): Long {
            var candidate: Long
            do {
                candidate = secureRandom.nextLong() and Long.MAX_VALUE
            } while (candidate == 0L)
            return candidate
        }
    }

}

internal data class ErikServiceEndpoint(
    val componentName: ComponentName,
    val action: String?,
    val description: String,
) {
    val key: String = componentName.flattenToString()

    fun createIntent(): Intent =
        Intent(action).setComponent(componentName)

    companion object {
        fun external(): ErikServiceEndpoint =
            ErikServiceEndpoint(
                componentName =
                    ComponentName(
                        ErikIpcContract.RUNTIME_PACKAGE,
                        ErikIpcContract.RUNTIME_SERVICE,
                    ),
                action = ErikIpcContract.RUNTIME_ACTION,
                description = "Erik runtime app",
            )

        fun embedded(context: Context): ErikServiceEndpoint =
            ErikServiceEndpoint(
                componentName = ComponentName(context.packageName, ErikIpcContract.RUNTIME_SERVICE),
                action = null,
                description = "Embedded Erik runtime service",
            )
    }
}
