package com.eccentric.erik.android

import java.util.UUID
import org.json.JSONObject

/** Keeps completed hotspot actions from replacing later door commands. */
internal class ErikDoorCommandOrder {
    private val tokens = mutableMapOf<ErikDoor, String>()

    fun record(doors: Collection<ErikDoor>, token: String = UUID.randomUUID().toString()): String {
        doors.forEach { tokens[it] = token }
        return JSONObject(doors.associate { it.jsName to token }).toString()
    }

    fun accepts(result: ErikHotspotResult): Boolean =
        result.errorMessage != null || tokens[result.door] == result.commandToken

    fun toJson(): String = JSONObject(tokens.mapKeys { it.key.jsName }).toString()

    fun restore(json: String) {
        val value = JSONObject(json)
        tokens.clear()
        ErikDoor.entries.forEach { door ->
            (value.opt(door.jsName) as? String)?.let { tokens[door] = it }
        }
    }

    companion object {
        const val ARG_TOKEN = "doorCommandToken"
        const val STATE_TOKENS = "nativeDoorCommandTokens"

        fun stamp(json: String): String =
            "Object.assign(globalThis.__erikDoorCommandTokens ||= {}, $json);"
    }
}
