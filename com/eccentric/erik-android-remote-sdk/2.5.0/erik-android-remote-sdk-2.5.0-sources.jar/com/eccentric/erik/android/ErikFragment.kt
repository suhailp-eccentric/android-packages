package com.eccentric.erik.android

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment

/**
 * Drop-in remote implementation of the Erik Fragment API.
 *
 * This artifact is mutually exclusive with the local SDK artifact: applications
 * should depend on either :sdk or :remote-sdk, never both.
 */
class ErikFragment : Fragment() {
    interface Listener {
        fun onStateChanged(state: ErikRuntimeState)

        fun onHotspotResult(result: ErikHotspotResult) = Unit
    }

    private val pendingViewActions = mutableListOf<(RemoteErikView) -> Unit>()
    private var remoteView: RemoteErikView? = null
    private var listener: Listener? = null
    private var cachedState = ErikRuntimeState()
    private var desiredState = ErikState()
    private var hasPendingExplicitInit = false
    private var interior = false

    /**
     * True when the runtime session shows the interior, or will once it is ready. The session keeps
     * one view for every Fragment attached to it.
     */
    val isInterior: Boolean
        get() = remoteView?.isShowingInterior() ?: interior

    /**
     * True when the 3D view is drawn above this app's window and therefore covers app views that
     * overlap it, such as a navigation drawer or bottom sheet; hide the 3D view while they show.
     * Only the exterior with a transparent background needs this. Separate windows such as
     * dialogs are never covered.
     */
    val coversAppViews: Boolean
        get() = remoteView?.drawsOnTop() ?: false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        restoredDesiredState(savedInstanceState)?.let { desiredState = it }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putSerializable(KEY_DESIRED_STATE, desiredState)
        super.onSaveInstanceState(outState)
    }

    fun setListener(listener: Listener?) {
        this.listener = listener
        listener?.onStateChanged(cachedState)
    }

    fun currentState(): ErikRuntimeState = remoteView?.currentState() ?: cachedState

    fun getState(callback: ErikJsonCallback) {
        withRemoteView {
            it.getState(
                object : ErikJsonCallback {
                    override fun onSuccess(json: String) {
                        runCatching { ErikState.fromJson(json) }.onSuccess { state -> desiredState = state }
                        callback.onSuccess(json)
                    }

                    override fun onError(message: String) {
                        callback.onError(message)
                    }
                },
            )
        }
    }

    fun getState(callback: ErikStateCallback) {
        withRemoteView { view ->
            view.getState(
                object : ErikJsonCallback {
                    override fun onSuccess(json: String) {
                        runCatching { ErikState.fromJson(json) }
                            .onSuccess { state ->
                                desiredState = state
                                callback.onSuccess(state)
                            }
                            .onFailure { callback.onError(it.message ?: "Unable to parse Erik state.") }
                    }

                    override fun onError(message: String) {
                        callback.onError(message)
                    }
                },
            )
        }
    }

    fun getColors(callback: ErikColorsCallback) {
        withRemoteView {
            it.getAssetConfig(
                object : ErikJsonCallback {
                    override fun onSuccess(json: String) {
                        runCatching { ErikAssetConfig.fromJson(json).colors }
                            .onSuccess(callback::onSuccess)
                            .onFailure { error ->
                                callback.onError(error.message ?: "Unable to parse Erik asset colors.")
                            }
                    }

                    override fun onError(message: String) {
                        callback.onError(message)
                    }
                },
            )
        }
    }

    fun getCapabilities(callback: ErikVehicleCapabilitiesCallback) {
        withRemoteView {
            it.getCapabilities(
                object : ErikJsonCallback {
                    override fun onSuccess(json: String) {
                        runCatching { ErikVehicleCapabilities.fromJson(json) }
                            .onSuccess(callback::onSuccess)
                            .onFailure { error ->
                                callback.onError(
                                    error.message ?: "Unable to parse Erik vehicle capabilities.",
                                )
                            }
                    }

                    override fun onError(message: String) {
                        callback.onError(message)
                    }
                },
            )
        }
    }

    fun init(
        state: ErikState,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        remember(state)
        val currentView = remoteView
        if (currentView == null) {
            hasPendingExplicitInit = true
            callback.onSuccess()
        } else {
            currentView.initialize(state, callback)
        }
    }

    fun openDoor(
        door: ErikDoor,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        rememberDoor(door, open = true)
        withRemoteView { it.openDoor(door, callback) }
    }

    fun closeDoor(
        door: ErikDoor,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        rememberDoor(door, open = false)
        withRemoteView { it.closeDoor(door, callback) }
    }

    fun setAllDoorsOpen(
        open: Boolean,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        rememberAllDoors(open)
        withRemoteView { it.setAllDoorsOpen(open, callback) }
    }

    fun play(
        name: String,
        direction: String = "forward",
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        rememberDoorAnimation(name, direction)
        withRemoteView { it.play(name, direction, callback) }
    }

    fun allDoors(
        direction: String = "forward",
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        rememberAllDoorsDirection(direction)
        withRemoteView { it.allDoors(direction, callback) }
    }

    fun goInterior(callback: ErikCommandCallback = ErikCommandCallback.NONE) {
        interior = true
        withRemoteView { it.goInterior(callback) }
    }

    fun goExterior(callback: ErikCommandCallback = ErikCommandCallback.NONE) {
        interior = false
        withRemoteView { it.goExterior(callback) }
    }

    fun toggleLights(
        lightsOn: Boolean,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        remember(ErikState(lightsOn = lightsOn))
        withRemoteView { it.toggleLights(lightsOn, callback) }
    }

    fun setLightState(
        light: ErikLight,
        state: ErikLightState,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        remember(ErikState(lightStates = mapOf(light to state)))
        withRemoteView { it.setLightState(light, state, callback) }
    }

    fun setRotationSpeed(
        speed: Double,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        require(speed >= 0.0) { "Rotation speed must be non-negative." }
        remember(ErikState(rotationSpeed = speed))
        withRemoteView { it.setRotationSpeed(speed, callback) }
    }

    fun setColor(
        colorName: String,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        remember(ErikState(carpaint = colorName))
        withRemoteView { it.setColor(colorName, callback) }
    }

    fun setBGColor(
        hex: String,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        if (parseBackgroundColor(hex) == null) {
            callback.onError("Invalid background colour: $hex")
            return
        }
        remember(ErikState(background = ErikBackgroundState(transparent = false, color = hex)))
        withRemoteView { it.setBGColor(hex, callback) }
    }

    fun skipIntro(callback: ErikCommandCallback = ErikCommandCallback.NONE) {
        withRemoteView { it.skipIntro(callback) }
    }

    fun doorStates(callback: ErikJsonCallback) {
        withRemoteView { it.doorStates(callback) }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View =
        RemoteErikView(requireContext()).also { createdView ->
            remoteView = createdView
            val applyExplicitState = hasPendingExplicitInit
            hasPendingExplicitInit = false
            createdView.initializeForAttachment(
                desiredState,
                applyExplicitState,
                ErikCommandCallback.NONE,
            )
            createdView.setHotspotListener { result ->
                if (result.errorMessage == null) remember(ErikState(doorStates = mapOf(result.door to result.isOpen)))
                listener?.onHotspotResult(result)
            }
            createdView.setListener { state ->
                cachedState = state
                listener?.onStateChanged(state)
            }
            val actions = pendingViewActions.toList()
            pendingViewActions.clear()
            actions.forEach { it(createdView) }
            interior = createdView.isShowingInterior()
        }

    override fun onResume() {
        super.onResume()
        remoteView?.resume()
    }

    override fun onPause() {
        remoteView?.pause()
        super.onPause()
    }

    override fun onDestroyView() {
        remoteView?.destroy()
        remoteView = null
        super.onDestroyView()
    }

    private fun withRemoteView(action: (RemoteErikView) -> Unit) {
        val currentView = remoteView
        if (currentView == null) {
            pendingViewActions += action
        } else {
            action(currentView)
        }
    }

    private fun remember(state: ErikState) {
        desiredState = desiredState.mergedWith(state)
    }

    private fun rememberDoor(
        door: ErikDoor,
        open: Boolean,
    ) {
        remember(ErikState(doorStates = mapOf(door to open)))
    }

    private fun rememberDoorAnimation(name: String, direction: String) {
        doorAnimationState(name, direction)?.let { remember(it) }
    }

    private fun rememberAllDoorsDirection(direction: String) {
        allDoorsAnimationState(direction)?.let { remember(it) }
    }

    private fun rememberAllDoors(open: Boolean) {
        remember(allDoorsState(open))
    }

    @Suppress("DEPRECATION")
    private fun restoredDesiredState(savedInstanceState: Bundle?): ErikState? =
        savedInstanceState?.getSerializable(KEY_DESIRED_STATE) as? ErikState

    companion object {
        private const val KEY_DESIRED_STATE = "com.eccentric.erik.android.desiredState"
    }
}
