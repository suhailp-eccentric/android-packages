package com.eccentric.erik.runtime

import android.app.Service
import android.content.Intent
import android.hardware.display.DisplayManager
import android.os.Bundle
import android.os.Binder
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.RemoteException
import android.view.ContextThemeWrapper
import android.view.MotionEvent
import android.view.SurfaceControlViewHost
import android.webkit.WebView
import androidx.annotation.RequiresApi
import com.eccentric.erik.android.ErikCommandCallback
import com.eccentric.erik.android.ErikDoor
import com.eccentric.erik.android.ErikDoorCommandOrder
import org.json.JSONObject
import com.eccentric.erik.android.ErikJsonCallback
import com.eccentric.erik.android.ErikLight
import com.eccentric.erik.android.ErikLightState
import com.eccentric.erik.android.ErikRenderView
import com.eccentric.erik.android.ErikState
import com.eccentric.erik.ipc.ErikIpcContract
import com.eccentric.erik.ipc.IErikClient
import com.eccentric.erik.ipc.IErikRenderService
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.FutureTask
import java.util.concurrent.TimeUnit

@RequiresApi(android.os.Build.VERSION_CODES.R)
class ErikRenderService : Service() {
    private val mainHandler = Handler(Looper.getMainLooper())
    private val sessions = ConcurrentHashMap<SessionKey, RenderSession>()

    override fun onCreate() {
        super.onCreate()
        WebView.setDataDirectorySuffix("erik_runtime")
    }

    private val binder =
        object : IErikRenderService.Stub() {
            override fun getProtocolVersion(): Int {
                return ErikIpcContract.PROTOCOL_VERSION
            }

            override fun createSession(
                sessionId: Long,
                hostToken: IBinder,
                displayId: Int,
                width: Int,
                height: Int,
                initialStateJson: String,
                assetDirectoryPath: String,
                client: IErikClient,
            ): SurfaceControlViewHost.SurfacePackage {
                val ownerUid = Binder.getCallingUid()
                return callOnMainThread {
                    createRenderSession(
                        key = SessionKey(ownerUid, sessionId),
                        hostToken = hostToken,
                        displayId = displayId,
                        width = width,
                        height = height,
                        initialStateJson = initialStateJson,
                        assetDirectoryPath = assetDirectoryPath,
                        client = client,
                    )
                }
            }

            override fun execute(
                sessionId: Long,
                requestId: Long,
                command: String,
                arguments: Bundle,
                client: IErikClient,
            ) {
                val ownerUid = Binder.getCallingUid()
                mainHandler.post {
                    executeCommand(
                        key = SessionKey(ownerUid, sessionId),
                        requestId = requestId,
                        command = command,
                        arguments = arguments,
                        fallbackClient = client,
                    )
                }
            }

            override fun resize(
                sessionId: Long,
                width: Int,
                height: Int,
            ) {
                val key = callerSessionKey(sessionId)
                mainHandler.post {
                    sessions[key]?.viewHost?.relayout(width.coerceAtLeast(1), height.coerceAtLeast(1))
                }
            }

            override fun dispatchTouch(
                sessionId: Long,
                event: MotionEvent,
            ) {
                val key = callerSessionKey(sessionId)
                mainHandler.post {
                    try {
                        sessions[key]?.renderView?.dispatchTouchEvent(event)
                    } finally {
                        event.recycle()
                    }
                }
            }

            override fun resumeSession(sessionId: Long) {
                val key = callerSessionKey(sessionId)
                mainHandler.post { sessions[key]?.renderView?.resume() }
            }

            override fun pauseSession(sessionId: Long) {
                val key = callerSessionKey(sessionId)
                mainHandler.post { sessions[key]?.renderView?.pause() }
            }

            override fun closeSession(sessionId: Long) {
                val key = callerSessionKey(sessionId)
                mainHandler.post { destroySession(key) }
            }
        }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onUnbind(intent: Intent?): Boolean {
        mainHandler.post {
            sessions.keys.toList().forEach(::destroySession)
        }
        return false
    }

    override fun onDestroy() {
        sessions.keys.toList().forEach(::destroySession)
        super.onDestroy()
    }

    private fun createRenderSession(
        key: SessionKey,
        hostToken: IBinder,
        displayId: Int,
        width: Int,
        height: Int,
        initialStateJson: String,
        assetDirectoryPath: String,
        client: IErikClient,
    ): SurfaceControlViewHost.SurfacePackage {
        val selectedAssetDirectory =
            assetDirectoryPath
                .takeIf { packageName != ErikIpcContract.RUNTIME_PACKAGE }
                ?.takeIf(String::isNotBlank)
                ?.let(::File)
                ?.takeIf(File::isDirectory)
        val selectedAssetIdentity = selectedAssetDirectory?.canonicalPath
        var existingSession = sessions[key]
        if (existingSession != null) {
            check(existingSession.clientBinder === client.asBinder()) {
                "Erik session ID is already owned by another client."
            }
            if (existingSession.assetIdentity != selectedAssetIdentity) {
                destroySession(key)
                existingSession = null
            }
        }

        val display =
            getSystemService(DisplayManager::class.java).getDisplay(displayId)
                ?: error("Display $displayId is unavailable.")
        val displayContext = createDisplayContext(display)
        val themedContext =
            ContextThemeWrapper(
                displayContext,
                android.R.style.Theme_Material_Light_NoActionBar,
            )
        if (existingSession != null) {
            return runCatching {
                existingSession.rehost(
                    context = themedContext,
                    display = display,
                    hostToken = hostToken,
                    width = width,
                    height = height,
                )
            }.getOrElse { error ->
                destroySession(key)
                throw error
            }
        }
        val initialStates =
            if (initialStateJson.isBlank()) {
                emptyList()
            } else {
                listOf(ErikState.fromJson(initialStateJson))
            }
        val renderView =
            ErikRenderView(
                context = themedContext,
                initialStates = initialStates,
                assetDirectory = selectedAssetDirectory,
            )
        renderView.restoreDoorCommandTokens(
            if (initialStateJson.isBlank()) "{}" else JSONObject(initialStateJson)
                .optJSONObject(ErikDoorCommandOrder.STATE_TOKENS)?.toString() ?: "{}",
        )
        val viewHost = SurfaceControlViewHost(themedContext, display, hostToken)
        val deathRecipient = IBinder.DeathRecipient {
            mainHandler.post { destroySession(key) }
        }
        val session =
            RenderSession(
                client = client,
                clientBinder = client.asBinder(),
                deathRecipient = deathRecipient,
                viewHost = viewHost,
                renderView = renderView,
                assetIdentity = selectedAssetIdentity,
            )

        try {
            session.clientBinder.linkToDeath(deathRecipient, 0)
            sessions[key] = session
            renderView.setHotspotListener { result ->
                try {
                    client.onHotspotResult(key.sessionId, result.toJson())
                } catch (_: RemoteException) {
                    destroySession(key)
                }
            }
            renderView.setListener { state ->
                try {
                    client.onRuntimeStateChanged(
                        key.sessionId,
                        state.isIntroAnimationPlaying,
                        state.isInitializationComplete,
                    )
                } catch (_: RemoteException) {
                    destroySession(key)
                }
            }
            viewHost.setView(renderView, width.coerceAtLeast(1), height.coerceAtLeast(1))
            return requireNotNull(viewHost.surfacePackage) {
                "Unable to create an Erik SurfacePackage."
            }
        } catch (error: Throwable) {
            sessions.remove(key)
            session.destroy()
            throw error
        }
    }

    private fun executeCommand(
        key: SessionKey,
        requestId: Long,
        command: String,
        arguments: Bundle,
        fallbackClient: IErikClient,
    ) {
        val session = sessions[key]
        if (session == null) {
            sendCommandResult(
                client = fallbackClient,
                key = key,
                requestId = requestId,
                success = false,
                result = "",
                errorMessage = "Erik session is unavailable.",
            )
            return
        }
        if (session.clientBinder !== fallbackClient.asBinder()) {
            sendCommandResult(
                client = fallbackClient,
                key = key,
                requestId = requestId,
                success = false,
                result = "",
                errorMessage = "Erik session belongs to another client.",
            )
            return
        }

        val callback =
            object : ErikCommandCallback {
                override fun onSuccess() {
                    sendCommandResult(session.client, key, requestId, true, "", "")
                }

                override fun onError(message: String) {
                    sendCommandResult(session.client, key, requestId, false, "", message)
                }
            }
        val jsonCallback =
            object : ErikJsonCallback {
                override fun onSuccess(json: String) {
                    sendCommandResult(session.client, key, requestId, true, json, "")
                }

                override fun onError(message: String) {
                    sendCommandResult(session.client, key, requestId, false, "", message)
                }
            }

        runCatching {
            with(session.renderView) {
                val commandToken = arguments.getString(ErikDoorCommandOrder.ARG_TOKEN)
                when (command) {
                    ErikIpcContract.COMMAND_INIT ->
                        init(
                            ErikState.fromJson(arguments.requiredString(ErikIpcContract.ARG_STATE_JSON)),
                            callback,
                            commandToken,
                        )
                    ErikIpcContract.COMMAND_OPEN_DOOR ->
                        openDoor(arguments.requiredEnum(ErikIpcContract.ARG_DOOR), callback, commandToken)
                    ErikIpcContract.COMMAND_CLOSE_DOOR ->
                        closeDoor(arguments.requiredEnum(ErikIpcContract.ARG_DOOR), callback, commandToken)
                    ErikIpcContract.COMMAND_SET_ALL_DOORS_OPEN ->
                        setAllDoorsOpen(arguments.getBoolean(ErikIpcContract.ARG_OPEN), callback, commandToken)
                    ErikIpcContract.COMMAND_PLAY ->
                        play(
                            arguments.requiredString(ErikIpcContract.ARG_NAME),
                            arguments.requiredString(ErikIpcContract.ARG_DIRECTION),
                            callback,
                            commandToken,
                        )
                    ErikIpcContract.COMMAND_ALL_DOORS ->
                        allDoors(arguments.requiredString(ErikIpcContract.ARG_DIRECTION), callback, commandToken)
                    ErikIpcContract.COMMAND_GO_INTERIOR -> goInterior(callback)
                    ErikIpcContract.COMMAND_GO_EXTERIOR -> goExterior(callback)
                    ErikIpcContract.COMMAND_TOGGLE_LIGHTS ->
                        toggleLights(arguments.getBoolean(ErikIpcContract.ARG_LIGHTS_ON), callback)
                    ErikIpcContract.COMMAND_SET_LIGHT_STATE ->
                        setLightState(
                            arguments.requiredEnum<ErikLight>(ErikIpcContract.ARG_LIGHT),
                            arguments.requiredEnum<ErikLightState>(ErikIpcContract.ARG_LIGHT_STATE),
                            callback,
                        )
                    ErikIpcContract.COMMAND_SET_ROTATION_SPEED ->
                        setRotationSpeed(arguments.getDouble(ErikIpcContract.ARG_SPEED), callback)
                    ErikIpcContract.COMMAND_SET_COLOR ->
                        setColor(arguments.requiredString(ErikIpcContract.ARG_COLOR), callback)
                    ErikIpcContract.COMMAND_SET_BG_COLOR ->
                        setBGColor(arguments.requiredString(ErikIpcContract.ARG_HEX), callback)
                    ErikIpcContract.COMMAND_SKIP_INTRO -> skipIntro(callback)
                    ErikIpcContract.COMMAND_GET_STATE -> getState(jsonCallback)
                    ErikIpcContract.COMMAND_DOOR_STATES -> doorStates(jsonCallback)
                    ErikIpcContract.COMMAND_GET_ASSET_CONFIG -> getAssetConfig(jsonCallback)
                    ErikIpcContract.COMMAND_GET_CAPABILITIES -> getCapabilities(jsonCallback)
                    else -> error("Unsupported Erik command: $command")
                }
            }
        }.onFailure { error ->
            callback.onError(error.message ?: "Unable to execute Erik command.")
        }
    }

    private fun sendCommandResult(
        client: IErikClient?,
        key: SessionKey,
        requestId: Long,
        success: Boolean,
        result: String,
        errorMessage: String,
    ) {
        if (client == null) {
            return
        }
        try {
            client.onCommandResult(key.sessionId, requestId, success, result, errorMessage)
        } catch (_: RemoteException) {
            destroySession(key)
        }
    }

    private fun destroySession(key: SessionKey) {
        sessions.remove(key)?.destroy()
    }

    private fun callerSessionKey(sessionId: Long): SessionKey =
        SessionKey(Binder.getCallingUid(), sessionId)

    private fun <T> callOnMainThread(action: () -> T): T {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            return action()
        }
        val task = FutureTask(action)
        mainHandler.post(task)
        return task.get(MAIN_THREAD_CALL_TIMEOUT_SECONDS, TimeUnit.SECONDS)
    }

    private data class RenderSession(
        val client: IErikClient,
        val clientBinder: IBinder,
        val deathRecipient: IBinder.DeathRecipient,
        var viewHost: SurfaceControlViewHost,
        val renderView: ErikRenderView,
        val assetIdentity: String?,
    ) {
        fun rehost(
            context: android.content.Context,
            display: android.view.Display,
            hostToken: IBinder,
            width: Int,
            height: Int,
        ): SurfaceControlViewHost.SurfacePackage {
            viewHost.release()
            viewHost = SurfaceControlViewHost(context, display, hostToken)
            viewHost.setView(renderView, width.coerceAtLeast(1), height.coerceAtLeast(1))
            return requireNotNull(viewHost.surfacePackage) {
                "Unable to rehost the Erik SurfacePackage."
            }
        }

        fun destroy() {
            runCatching { clientBinder.unlinkToDeath(deathRecipient, 0) }
            renderView.destroy()
            viewHost.release()
        }
    }

    private data class SessionKey(
        val ownerUid: Int,
        val sessionId: Long,
    )

    private fun Bundle.requiredString(key: String): String =
        getString(key)?.takeIf(String::isNotBlank)
            ?: error("Missing command argument: $key")

    private inline fun <reified T : Enum<T>> Bundle.requiredEnum(key: String): T =
        enumValueOf<T>(requiredString(key))

    companion object {
        private const val MAIN_THREAD_CALL_TIMEOUT_SECONDS = 15L
    }
}
