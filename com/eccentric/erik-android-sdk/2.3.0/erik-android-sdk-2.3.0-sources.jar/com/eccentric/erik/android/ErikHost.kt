package com.eccentric.erik.android

import android.content.Context
import android.os.Build
import android.view.View
import androidx.annotation.RequiresApi

internal interface ErikHost {
    val view: View

    fun setHotspotListener(listener: ((ErikHotspotResult) -> Unit)?)

    fun setListener(listener: ((ErikRuntimeState) -> Unit)?)

    fun currentState(): ErikRuntimeState

    fun getState(callback: ErikJsonCallback)

    fun getState(callback: ErikStateCallback)

    fun getAssetConfig(callback: ErikJsonCallback)

    fun getCapabilities(callback: ErikJsonCallback)

    fun init(state: ErikState, callback: ErikCommandCallback)

    fun openDoor(door: ErikDoor, callback: ErikCommandCallback)

    fun closeDoor(door: ErikDoor, callback: ErikCommandCallback)

    fun setAllDoorsOpen(open: Boolean, callback: ErikCommandCallback)

    fun play(name: String, direction: String, callback: ErikCommandCallback)

    fun allDoors(direction: String, callback: ErikCommandCallback)

    fun goInterior(callback: ErikCommandCallback)

    fun goExterior(callback: ErikCommandCallback)

    fun toggleLights(lightsOn: Boolean, callback: ErikCommandCallback)

    fun setLightState(light: ErikLight, state: ErikLightState, callback: ErikCommandCallback)

    fun setRotationSpeed(speed: Double, callback: ErikCommandCallback)

    fun setColor(colorName: String, callback: ErikCommandCallback)

    fun setBGColor(hex: String, callback: ErikCommandCallback)

    fun skipIntro(callback: ErikCommandCallback)

    fun doorStates(callback: ErikJsonCallback)

    fun resume()

    fun pause()

    fun destroy()
}

internal class LocalErikHost(
    context: Context,
    initialState: ErikState,
) : ErikHost {
    private val renderView = ErikRenderView(context, listOf(initialState))

    override val view: View = renderView

    override fun setHotspotListener(listener: ((ErikHotspotResult) -> Unit)?) = renderView.setHotspotListener(listener)

    override fun setListener(listener: ((ErikRuntimeState) -> Unit)?) = renderView.setListener(listener)

    override fun currentState(): ErikRuntimeState = renderView.currentState()

    override fun getState(callback: ErikJsonCallback) = renderView.getState(callback)

    override fun getState(callback: ErikStateCallback) = renderView.getState(callback)

    override fun getAssetConfig(callback: ErikJsonCallback) = renderView.getAssetConfig(callback)

    override fun getCapabilities(callback: ErikJsonCallback) = renderView.getCapabilities(callback)

    override fun init(state: ErikState, callback: ErikCommandCallback) = renderView.init(state, callback)

    override fun openDoor(door: ErikDoor, callback: ErikCommandCallback) = renderView.openDoor(door, callback)

    override fun closeDoor(door: ErikDoor, callback: ErikCommandCallback) = renderView.closeDoor(door, callback)

    override fun setAllDoorsOpen(open: Boolean, callback: ErikCommandCallback) =
        renderView.setAllDoorsOpen(open, callback)

    override fun play(name: String, direction: String, callback: ErikCommandCallback) =
        renderView.play(name, direction, callback)

    override fun allDoors(direction: String, callback: ErikCommandCallback) =
        renderView.allDoors(direction, callback)

    override fun goInterior(callback: ErikCommandCallback) = renderView.goInterior(callback)

    override fun goExterior(callback: ErikCommandCallback) = renderView.goExterior(callback)

    override fun toggleLights(lightsOn: Boolean, callback: ErikCommandCallback) =
        renderView.toggleLights(lightsOn, callback)

    override fun setLightState(light: ErikLight, state: ErikLightState, callback: ErikCommandCallback) =
        renderView.setLightState(light, state, callback)

    override fun setRotationSpeed(speed: Double, callback: ErikCommandCallback) =
        renderView.setRotationSpeed(speed, callback)

    override fun setColor(colorName: String, callback: ErikCommandCallback) =
        renderView.setColor(colorName, callback)

    override fun setBGColor(hex: String, callback: ErikCommandCallback) =
        renderView.setBGColor(hex, callback)

    override fun skipIntro(callback: ErikCommandCallback) = renderView.skipIntro(callback)

    override fun doorStates(callback: ErikJsonCallback) = renderView.doorStates(callback)

    override fun resume() = renderView.resume()

    override fun pause() = renderView.pause()

    override fun destroy() = renderView.destroy()
}

@RequiresApi(Build.VERSION_CODES.R)
internal class ServiceErikHost(
    context: Context,
    initialState: ErikState,
    applyExplicitState: Boolean,
) : ErikHost {
    private val remoteView =
        RemoteErikView(
            context = context,
            endpoint = ErikServiceEndpoint.embedded(context),
            assetDirectory = ErikSdk.currentAssetDirectory(),
        ).also {
            it.initializeForAttachment(initialState, applyExplicitState, ErikCommandCallback.NONE)
        }

    override val view: View = remoteView

    override fun setHotspotListener(listener: ((ErikHotspotResult) -> Unit)?) = remoteView.setHotspotListener(listener)

    override fun setListener(listener: ((ErikRuntimeState) -> Unit)?) = remoteView.setListener(listener)

    override fun currentState(): ErikRuntimeState = remoteView.currentState()

    override fun getState(callback: ErikJsonCallback) = remoteView.getState(callback)

    override fun getState(callback: ErikStateCallback) {
        remoteView.getState(
            object : ErikJsonCallback {
                override fun onSuccess(json: String) {
                    runCatching { ErikState.fromJson(json) }
                        .onSuccess(callback::onSuccess)
                        .onFailure { callback.onError(it.message ?: "Unable to parse Erik state.") }
                }

                override fun onError(message: String) = callback.onError(message)
            },
        )
    }

    override fun getAssetConfig(callback: ErikJsonCallback) = remoteView.getAssetConfig(callback)

    override fun getCapabilities(callback: ErikJsonCallback) = remoteView.getCapabilities(callback)

    override fun init(state: ErikState, callback: ErikCommandCallback) = remoteView.initialize(state, callback)

    override fun openDoor(door: ErikDoor, callback: ErikCommandCallback) = remoteView.openDoor(door, callback)

    override fun closeDoor(door: ErikDoor, callback: ErikCommandCallback) = remoteView.closeDoor(door, callback)

    override fun setAllDoorsOpen(open: Boolean, callback: ErikCommandCallback) =
        remoteView.setAllDoorsOpen(open, callback)

    override fun play(name: String, direction: String, callback: ErikCommandCallback) =
        remoteView.play(name, direction, callback)

    override fun allDoors(direction: String, callback: ErikCommandCallback) =
        remoteView.allDoors(direction, callback)

    override fun goInterior(callback: ErikCommandCallback) = remoteView.goInterior(callback)

    override fun goExterior(callback: ErikCommandCallback) = remoteView.goExterior(callback)

    override fun toggleLights(lightsOn: Boolean, callback: ErikCommandCallback) =
        remoteView.toggleLights(lightsOn, callback)

    override fun setLightState(light: ErikLight, state: ErikLightState, callback: ErikCommandCallback) =
        remoteView.setLightState(light, state, callback)

    override fun setRotationSpeed(speed: Double, callback: ErikCommandCallback) =
        remoteView.setRotationSpeed(speed, callback)

    override fun setColor(colorName: String, callback: ErikCommandCallback) =
        remoteView.setColor(colorName, callback)

    override fun setBGColor(hex: String, callback: ErikCommandCallback) =
        remoteView.setBGColor(hex, callback)

    override fun skipIntro(callback: ErikCommandCallback) = remoteView.skipIntro(callback)

    override fun doorStates(callback: ErikJsonCallback) = remoteView.doorStates(callback)

    override fun resume() = remoteView.resume()

    override fun pause() = remoteView.pause()

    override fun destroy() = remoteView.destroy()
}

internal fun createErikHost(
    context: Context,
    initialState: ErikState,
    applyExplicitState: Boolean,
): ErikHost =
    when {
        ErikSdk.currentConfig().hostingMode == ErikHostingMode.LOCAL ->
            LocalErikHost(context, initialState)
        Build.VERSION.SDK_INT < Build.VERSION_CODES.R ->
            LocalErikHost(context, initialState)
        else ->
            ServiceErikHost(context, initialState, applyExplicitState)
    }
