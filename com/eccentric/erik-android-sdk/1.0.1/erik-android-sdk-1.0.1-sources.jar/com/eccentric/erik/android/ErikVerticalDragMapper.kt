package com.eccentric.erik.android

internal class ErikVerticalDragMapper {
    private var lastSourceY: Float? = null
    private var lastMappedY: Float? = null

    fun start(y: Float): Float {
        lastSourceY = y
        lastMappedY = y
        return y
    }

    fun mapMove(y: Float): Float {
        val previousSourceY = lastSourceY ?: return start(y)
        val previousMappedY = lastMappedY ?: return start(y)
        val mappedY = previousMappedY - (y - previousSourceY)
        lastSourceY = y
        lastMappedY = mappedY
        return mappedY
    }

    fun reset() {
        lastSourceY = null
        lastMappedY = null
    }
}
