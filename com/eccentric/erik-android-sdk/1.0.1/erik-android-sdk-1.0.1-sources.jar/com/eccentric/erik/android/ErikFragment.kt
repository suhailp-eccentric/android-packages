package com.eccentric.erik.android

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.FrameLayout
import androidx.core.view.doOnLayout
import androidx.fragment.app.Fragment
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.panoramagl.PLImage
import com.panoramagl.PLManager
import com.panoramagl.PLSphericalPanorama
import java.io.ByteArrayInputStream

class ErikFragment : Fragment() {
    interface Listener {
        fun onStateChanged(state: ErikRuntimeState)
    }

    private val pendingCommands = mutableListOf<PendingCommand>()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val microInteractionsConfig = ErikMicroInteractionsConfig()

    private var listener: Listener? = null
    private var webView: WebView? = null
    private var assetLoader: WebViewAssetLoader? = null
    private var panoramaManager: PLManager? = null
    private var panoramaContainer: FrameLayout? = null
    private var webViewContainer: FrameLayout? = null
    private var isReady = false
    private var isPageFinished = false
    private var isIntroAnimationPlaying = false
    private var isInitializing = false
    private var isInitializationComplete = false
    private var isRefreshingLights = false
    private var lightRefreshGeneration = 0
    private var didRefreshLightsAfterInitialization = false
    private var didRefreshLightsAfterIntroAnimation = false
    private var startupCameraAnimationRequested: Boolean? = null
    private var activeSurface = ActiveSurface.EXTERIOR

    fun setListener(listener: Listener?) {
        this.listener = listener
        dispatchState()
    }

    fun currentState(): ErikRuntimeState =
        ErikRuntimeState(
            isReady = isReady,
            isIntroAnimationPlaying = isIntroAnimationPlaying,
            isInitializing = isInitializing,
            isInitializationComplete = isInitializationComplete,
        )

    fun getState(callback: ErikJsonCallback) {
        runExpression(ErikBrowserCommand.getState(), callback)
    }

    fun getState(callback: ErikStateCallback) {
        getState(
            object : ErikJsonCallback {
                override fun onSuccess(json: String) {
                    runCatching { ErikState.fromJson(json) }
                        .onSuccess(callback::onSuccess)
                        .onFailure { error ->
                            callback.onError(error.message ?: "Unable to parse Erik state.")
                        }
                }

                override fun onError(message: String) {
                    callback.onError(message)
                }
            },
        )
    }

    fun init(
        state: ErikState,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        runOnMainThread {
            state.startupCameraAnimation?.let { startupCameraAnimationRequested = it }
            microInteractionsConfig.apply(state)
            reloadWebViewWithCurrentConfig()
            callback.onSuccess()
        }
    }

    fun openDoor(
        door: ErikDoor,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        play(door.jsName, callback = callback)
    }

    fun closeDoor(
        door: ErikDoor,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        play(door.jsName, direction = "reverse", callback = callback)
    }

    fun setAllDoorsOpen(
        open: Boolean,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        val direction = if (open) "forward" else "reverse"
        allDoors(direction, callback)
    }

    fun play(
        name: String,
        direction: String = "forward",
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        runCommand(ErikBrowserCommand.play(name, direction), callback)
    }

    fun allDoors(
        direction: String = "forward",
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        runCommand(ErikBrowserCommand.allDoors(direction), callback)
    }

    fun goInterior(callback: ErikCommandCallback = ErikCommandCallback.NONE) {
        runOnMainThread {
            resetInteriorView()
            activeSurface = ActiveSurface.INTERIOR
            updateSurfaceVisibility()
            callback.onSuccess()
        }
    }

    fun goExterior(callback: ErikCommandCallback = ErikCommandCallback.NONE) {
        runCommand(ErikBrowserCommand.goExterior(), surfaceCallback(ActiveSurface.EXTERIOR, callback))
    }

    fun toggleLights(
        lightsOn: Boolean,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        runCommand(ErikBrowserCommand.toggleLights(lightsOn), callback)
    }

    fun setColor(
        colorName: String,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        runCommand(ErikBrowserCommand.setColor(colorName), callback)
    }

    fun setBGColor(
        hex: String,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        runCommand(ErikBrowserCommand.setBGColor(hex), callback)
    }

    fun skipIntro(callback: ErikCommandCallback = ErikCommandCallback.NONE) {
        runCommand(ErikBrowserCommand.skipIntro(), callback)
    }

    fun doorStates(callback: ErikJsonCallback) {
        runExpression(ErikBrowserCommand.doorStates(), callback)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.e(LOG_TAG, "onCreate")
        assetLoader =
            WebViewAssetLoader.Builder()
                .addPathHandler("/", ErikAssetPathHandler(requireContext(), microInteractionsConfig::render))
                .build()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        Log.e(LOG_TAG, "onCreateView")
        val context = requireContext()
        val root = inflater.inflate(R.layout.fragment_erik, container, false) as FrameLayout
        val panoramaHost = root.findViewById<FrameLayout>(R.id.panorama_container)
        val webViewHost = root.findViewById<FrameLayout>(R.id.webview_container)

        panoramaContainer = panoramaHost
        webViewContainer = webViewHost
        configurePanorama(panoramaHost)

        val createdWebView =
            ErikWebView(context).apply {
                layoutParams =
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT,
                    )
                setBackgroundColor(Color.TRANSPARENT)
                overScrollMode = View.OVER_SCROLL_NEVER

                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    mediaPlaybackRequiresUserGesture = false
                    cacheMode = WebSettings.LOAD_DEFAULT
                    mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                }

                installAndroidWebViewRenderingShim(this)
                addJavascriptInterface(ErikJavascriptBridge(::handleJavascriptMessage), JS_BRIDGE_NAME)
                webChromeClient = createWebChromeClient()
                webViewClient = createWebViewClient()
                setOnTouchListener(createTouchInterceptor())
            }

        webView = createdWebView
        webViewHost.addView(createdWebView)
        updateSurfaceVisibility()
        createdWebView.doOnLayout {
            createdWebView.loadUrl(ENTRYPOINT_URL)
            createdWebView.postDelayed({ logJavascriptState(createdWebView) }, 4000)
        }
        return root
    }

    private fun installAndroidWebViewRenderingShim(target: WebView) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            Log.w(LOG_TAG, "Document-start JavaScript is not supported by this WebView")
            return
        }

        WebViewCompat.addDocumentStartJavaScript(
            target,
            """
            (() => {
              window.__erikAndroidWebView = true;
              try {
                Object.defineProperty(Navigator.prototype, 'gpu', {
                  configurable: true,
                  get: () => undefined
                });
              } catch (_) {}
              try {
                Object.defineProperty(navigator, 'gpu', {
                  configurable: true,
                  get: () => undefined
                });
              } catch (_) {}
              console.log('[ErikAndroid] WebGPU disabled for transparent WebView composition');
            })();
            """.trimIndent(),
            setOf("https://appassets.androidplatform.net"),
        )
    }

    override fun onResume() {
        super.onResume()
        panoramaManager?.onResume()
    }

    override fun onPause() {
        panoramaManager?.onPause()
        super.onPause()
    }

    override fun onDestroyView() {
        failPendingCommands("Erik view was destroyed before the command completed.")
        panoramaManager?.onDestroy()
        panoramaManager = null
        panoramaContainer?.removeAllViews()
        panoramaContainer = null
        webViewContainer?.removeAllViews()
        webViewContainer = null
        webView?.removeJavascriptInterface(JS_BRIDGE_NAME)
        webView?.apply {
            stopLoading()
            webChromeClient = null
            destroy()
        }
        webView = null
        super.onDestroyView()
    }

    private fun configurePanorama(container: FrameLayout) {
        val manager =
            PLManager(requireContext()).apply {
                setContentView(container)
                onCreate()
                isScrollingEnabled = true
                isInertiaEnabled = true
                isZoomEnabled = true
                isAccelerometerEnabled = false
                isAcceleratedTouchScrollingEnabled = false
            }

        val panoramaBitmap =
            requireContext().assets.open(INTERIOR_PANORAMA_ASSET_PATH).use { stream ->
                BitmapFactory.decodeStream(stream)
            }
        val panorama =
            PLSphericalPanorama().apply {
                setImage(PLImage(panoramaBitmap, false))
                camera.lookAtAndZoomFactor(0f, 0f, 0f, false)
                camera.rotationSensitivity = 270f
            }

        manager.panorama = panorama
        val panoramaTouchView = manager.getGLSurfaceView() ?: container
        panoramaTouchView.setOnTouchListener(createTouchInterceptor { event ->
            manager.onTouchEvent(event)
        })
        panoramaManager = manager
    }

    private fun createTouchInterceptor(
        onTouch: ((MotionEvent) -> Boolean)? = null,
    ): View.OnTouchListener =
        View.OnTouchListener { view, event ->
            if (isRefreshingLights) {
                return@OnTouchListener true
            }

            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN,
                MotionEvent.ACTION_MOVE -> {
                    view.parent?.requestDisallowInterceptTouchEvent(true)
                }

                MotionEvent.ACTION_UP,
                MotionEvent.ACTION_CANCEL -> {
                    view.parent?.requestDisallowInterceptTouchEvent(false)
                }
            }
            onTouch?.invoke(event) ?: false
        }

    private fun surfaceCallback(
        surface: ActiveSurface,
        callback: ErikCommandCallback,
    ): ErikCommandCallback =
        object : ErikCommandCallback {
            override fun onSuccess() {
                activeSurface = surface
                updateSurfaceVisibility()
                callback.onSuccess()
            }

            override fun onError(message: String) {
                callback.onError(message)
            }
        }

    private fun updateSurfaceVisibility() {
        val showingInterior = activeSurface == ActiveSurface.INTERIOR
        panoramaContainer?.visibility = if (showingInterior) View.VISIBLE else View.INVISIBLE
        webViewContainer?.visibility = if (showingInterior) View.INVISIBLE else View.VISIBLE
        panoramaContainer?.alpha = if (isRefreshingLights) 0f else 1f
        webViewContainer?.alpha = if (isRefreshingLights) 0f else 1f
    }

    private fun reloadWebViewWithCurrentConfig() {
        val currentWebView = webView ?: return
        isPageFinished = false
        isRefreshingLights = false
        lightRefreshGeneration += 1
        didRefreshLightsAfterInitialization = false
        didRefreshLightsAfterIntroAnimation = false
        updateSurfaceVisibility()
        setReady(false)
        setInitializationState(initializing = false, complete = false)
        currentWebView.loadUrl(ENTRYPOINT_URL)
    }

    private fun resetInteriorView() {
        panoramaManager?.reset()
    }

    private fun createWebChromeClient(): WebChromeClient =
        object : WebChromeClient() {
            override fun onConsoleMessage(consoleMessage: ConsoleMessage): Boolean {
                val message = consoleMessage.message()
                Log.d(LOG_TAG, "console: ${consoleMessage.messageLevel()} ${consoleMessage.sourceId()}:${consoleMessage.lineNumber()} $message")
                when {
                    message.contains("[ErikPlayer] initialization started") ->
                        setInitializationState(initializing = true, complete = false)
                    message.contains("[ErikPlayer] initialization complete") ->
                        setInitializationState(initializing = false, complete = true)
                    message.contains("Starting trailer camera") -> {
                        setInitializationState(initializing = false, complete = true)
                        setIntroAnimationPlaying(true)
                    }
                    message.contains("Trailer camera sequence finished") -> setIntroAnimationPlaying(false)
                    message.contains("Trailer camera sequence skipped") -> setIntroAnimationPlaying(false)
                }
                return super.onConsoleMessage(consoleMessage)
            }
        }

    private fun createWebViewClient(): WebViewClientCompat =
        object : WebViewClientCompat() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest,
            ): WebResourceResponse? = assetLoader?.shouldInterceptRequest(request.url)

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: androidx.webkit.WebResourceErrorCompat,
            ) {
                Log.e(
                    LOG_TAG,
                    "request error: ${request.url} code=${error.errorCode} description=${error.description}",
                )
                super.onReceivedError(view, request, error)
            }

            override fun onReceivedHttpError(
                view: WebView,
                request: WebResourceRequest,
                errorResponse: WebResourceResponse,
            ) {
                Log.e(
                    LOG_TAG,
                    "http error: ${request.url} status=${errorResponse.statusCode} reason=${errorResponse.reasonPhrase}",
                )
                super.onReceivedHttpError(view, request, errorResponse)
            }

            override fun onPageStarted(
                view: WebView,
                url: String?,
                favicon: android.graphics.Bitmap?,
            ) {
                Log.e(LOG_TAG, "page started: $url")
                isPageFinished = false
                isRefreshingLights = false
                lightRefreshGeneration += 1
                didRefreshLightsAfterInitialization = false
                didRefreshLightsAfterIntroAnimation = false
                updateSurfaceVisibility()
                setReady(false)
                setInitializationState(initializing = false, complete = false)
                isIntroAnimationPlaying = false
                super.onPageStarted(view, url, favicon)
            }

            override fun onPageFinished(
                view: WebView,
                url: String?,
            ) {
                Log.d(LOG_TAG, "page finished: $url")
                isPageFinished = true
                flushPendingCommands()
                injectBootstrapScript(view)
                super.onPageFinished(view, url)
            }
        }

    private fun handleJavascriptMessage(message: String) {
        Log.e(LOG_TAG, "bridge message: $message")
        if (message == "ready") {
            setReady(true)
            flushPendingCommands()
        }
    }


    private fun injectBootstrapScript(target: WebView) {
        target.evaluateJavascript(
            """
            (function bootstrapErikNativeBridge() {
              let attempts = 0;
              function hasLiveErikApi() {
                if (typeof window.__erik === 'undefined' ||
                    typeof window.__erik.getState !== 'function' ||
                    typeof window.__erik.doorStates !== 'function' ||
                    typeof window.__erik.play !== 'function') {
                  return false;
                }

                try {
                  return window.__erik.getState() !== null;
                } catch (error) {
                  return false;
                }
              }

              (function tick() {
                if (hasLiveErikApi() &&
                    window.$JS_BRIDGE_NAME &&
                    typeof window.$JS_BRIDGE_NAME.postMessage === 'function') {
                  window.$JS_BRIDGE_NAME.postMessage('ready');
                  return;
                }
                if (attempts++ < 60) {
                  setTimeout(tick, 250);
                }
              })();
            })();
            """.trimIndent(),
            null,
        )
    }

    private fun runCommand(
        command: String,
        callback: ErikCommandCallback,
        requiresReady: Boolean = true,
    ) {
        runJavascript(command, returnsValue = false, requiresReady = requiresReady, callback = callback.toPendingCallback())
    }

    private fun runExpression(
        expression: String,
        callback: ErikJsonCallback,
    ) {
        runJavascript(expression, returnsValue = true, requiresReady = true, callback = callback.toPendingCallback())
    }

    private fun runJavascript(
        script: String,
        returnsValue: Boolean,
        requiresReady: Boolean,
        callback: ErikPendingCallback,
    ) {
        val currentWebView = webView
        if (currentWebView == null) {
            pendingCommands += PendingCommand(script, returnsValue, requiresReady, callback)
            return
        }

        if (!canEvaluate(requiresReady)) {
            pendingCommands += PendingCommand(script, returnsValue, requiresReady, callback)
            return
        }

        evaluateCommand(currentWebView, PendingCommand(script, returnsValue, requiresReady, callback))
    }

    private fun flushPendingCommands() {
        val currentWebView = webView ?: return
        if (pendingCommands.isEmpty()) {
            return
        }

        val queuedCommands = pendingCommands.filter { canEvaluate(it.requiresReady) }
        if (queuedCommands.isEmpty()) {
            return
        }

        val waitingCommands = pendingCommands.filterNot { canEvaluate(it.requiresReady) }
        pendingCommands.clear()
        pendingCommands.addAll(waitingCommands)
        queuedCommands.forEach { pending ->
            evaluateCommand(currentWebView, pending)
        }
    }

    private fun evaluateCommand(
        target: WebView,
        pending: PendingCommand,
    ) {
        val successBody =
            if (pending.returnsValue) {
                "return 'ok:' + (${pending.script});"
            } else {
                """
                ${pending.script};
                return 'ok';
                """.trimIndent()
            }
        val wrappedCommand =
            """
            (function() {
              try {
                $successBody
              } catch (error) {
                return 'error:' + (error && error.message ? error.message : String(error));
              }
            })();
            """.trimIndent()

        target.post {
            target.evaluateJavascript(wrappedCommand) { rawResult ->
                val normalizedResult = normalizeJavascriptResult(rawResult)
                if (normalizedResult.startsWith("error:")) {
                    pending.callback.onError(normalizedResult.removePrefix("error:"))
                } else if (pending.returnsValue) {
                    pending.callback.onSuccess(normalizedResult.removePrefix("ok:"))
                } else {
                    pending.callback.onSuccess("")
                }
            }
        }
    }

    private fun canEvaluate(requiresReady: Boolean): Boolean = if (requiresReady) isReady else isPageFinished

    private fun normalizeJavascriptResult(rawResult: String?): String {
        if (rawResult == null || rawResult == "null") {
            return ""
        }

        return rawResult
            .removeSurrounding("\"")
            .replace("\\\\", "\\")
            .replace("\\n", "\n")
            .replace("\\\"", "\"")
    }

    private fun failPendingCommands(message: String) {
        runOnMainThread {
            if (pendingCommands.isEmpty()) {
                return@runOnMainThread
            }

            val commandsToFail = pendingCommands.toList()
            pendingCommands.clear()
            commandsToFail.forEach { pending ->
                pending.callback.onError(message)
            }
        }
    }

    private fun setReady(ready: Boolean) {
        if (!isMainThread()) {
            runOnMainThread { setReady(ready) }
            return
        }

        if (isReady == ready) {
            return
        }

        isReady = ready
        if (ready) {
            scheduleLightRefreshAfterInitialization()
        }
        dispatchState()
    }

    private fun setIntroAnimationPlaying(playing: Boolean) {
        if (!isMainThread()) {
            runOnMainThread { setIntroAnimationPlaying(playing) }
            return
        }

        if (isIntroAnimationPlaying == playing) {
            if (!playing && startupCameraAnimationRequested == true) {
                startupCameraAnimationRequested = false
                refreshLightsAfterIntroAnimation()
                dispatchState()
            }
            return
        }

        isIntroAnimationPlaying = playing
        if (playing) {
            startupCameraAnimationRequested = true
        }
        if (!playing) {
            startupCameraAnimationRequested = false
            refreshLightsAfterIntroAnimation()
        }
        dispatchState()
    }

    private fun setInitializationState(
        initializing: Boolean,
        complete: Boolean,
    ) {
        if (!isMainThread()) {
            runOnMainThread { setInitializationState(initializing, complete) }
            return
        }

        if (isInitializing == initializing && isInitializationComplete == complete) {
            return
        }

        isInitializing = initializing
        isInitializationComplete = complete
        if (complete) {
            scheduleLightRefreshAfterInitialization()
        }
        dispatchState()
    }

    private fun scheduleLightRefreshAfterInitialization() {
        if (
            didRefreshLightsAfterInitialization ||
            didRefreshLightsAfterIntroAnimation ||
            !isInitializationComplete ||
            !isReady ||
            startupCameraAnimationRequested == true
        ) {
            return
        }

        val refreshGeneration = lightRefreshGeneration
        val delayMs =
            if (startupCameraAnimationRequested == false) {
                0L
            } else {
                INITIALIZATION_LIGHT_REFRESH_DELAY_MS
            }
        mainHandler.postDelayed(
            {
                if (lightRefreshGeneration == refreshGeneration) {
                    refreshLightsAfterInitialization()
                }
            },
            delayMs,
        )
    }

    private fun refreshLightsAfterInitialization() {
        if (
            didRefreshLightsAfterInitialization ||
            didRefreshLightsAfterIntroAnimation ||
            !isInitializationComplete ||
            !isReady ||
            isIntroAnimationPlaying ||
            startupCameraAnimationRequested == true
        ) {
            return
        }

        didRefreshLightsAfterInitialization = true
        runLightRefreshCommand()
    }

    private fun refreshLightsAfterIntroAnimation() {
        if (!isInitializationComplete || !isReady || didRefreshLightsAfterIntroAnimation) {
            return
        }

        didRefreshLightsAfterIntroAnimation = true
        runLightRefreshCommand()
    }

    private fun runLightRefreshCommand() {
        val refreshGeneration = ++lightRefreshGeneration
        setRefreshingLights(true)
        runCommand(
            ErikBrowserCommand.refreshLightsAfterInitialization(),
            object : ErikCommandCallback {
                override fun onSuccess() {
                    mainHandler.postDelayed(
                        {
                            if (lightRefreshGeneration == refreshGeneration) {
                                setRefreshingLights(false)
                            }
                        },
                        LIGHT_REFRESH_SETTLE_MS,
                    )
                }

                override fun onError(message: String) {
                    Log.e(LOG_TAG, "light refresh failed: $message")
                    if (lightRefreshGeneration == refreshGeneration) {
                        setRefreshingLights(false)
                    }
                }
            },
        )
    }

    private fun setRefreshingLights(refreshing: Boolean) {
        if (!isMainThread()) {
            runOnMainThread { setRefreshingLights(refreshing) }
            return
        }

        if (isRefreshingLights == refreshing) {
            return
        }

        isRefreshingLights = refreshing
        updateSurfaceVisibility()
        dispatchState()
    }

    private fun dispatchState() {
        runOnMainThread {
            Log.e(
                LOG_TAG,
                "state ready=$isReady intro=$isIntroAnimationPlaying initializing=$isInitializing initializationComplete=$isInitializationComplete",
            )
            listener?.onStateChanged(currentState())
        }
    }

    private fun logJavascriptState(target: WebView) {
        target.evaluateJavascript(
            """
            JSON.stringify({
              readyState: document.readyState,
              href: window.location.href,
              title: document.title,
              hasErik: typeof window.__erik !== 'undefined',
              hasCanvas: !!document.querySelector('canvas'),
              bodyText: document.body ? document.body.innerText.slice(0, 200) : null
            })
            """.trimIndent(),
        ) { result ->
            Log.e(LOG_TAG, "js state: $result")
        }
    }

    private data class PendingCommand(
        val script: String,
        val returnsValue: Boolean,
        val requiresReady: Boolean,
        val callback: ErikPendingCallback,
    )

    private enum class ActiveSurface {
        EXTERIOR,
        INTERIOR,
    }

    private class ErikJavascriptBridge(
        private val onMessage: (String) -> Unit,
    ) {
        @JavascriptInterface
        fun postMessage(message: String) {
            onMessage(message)
        }
    }

    private class ErikWebView(context: Context) : WebView(context) {
        private val verticalDragMapper = ErikVerticalDragMapper()

        override fun dispatchTouchEvent(event: MotionEvent): Boolean {
            val transformedEvent = event.toAndroidDragEvent()
            return if (transformedEvent === event) {
                super.dispatchTouchEvent(event)
            } else {
                try {
                    super.dispatchTouchEvent(transformedEvent)
                } finally {
                    transformedEvent.recycle()
                }
            }
        }

        private fun MotionEvent.toAndroidDragEvent(): MotionEvent {
            if (pointerCount != 1) {
                verticalDragMapper.reset()
                return this
            }

            return when (actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    verticalDragMapper.start(y)
                    this
                }

                MotionEvent.ACTION_MOVE -> {
                    MotionEvent.obtain(this).apply {
                        setLocation(x, verticalDragMapper.mapMove(y))
                    }
                }

                MotionEvent.ACTION_UP,
                MotionEvent.ACTION_CANCEL -> {
                    verticalDragMapper.reset()
                    this
                }

                else -> this
            }
        }
    }

    private fun runOnMainThread(action: () -> Unit) {
        if (isMainThread()) {
            action()
        } else {
            mainHandler.post(action)
        }
    }

    private fun isMainThread(): Boolean = Looper.myLooper() == Looper.getMainLooper()

    private class ErikAssetPathHandler(
        context: android.content.Context,
        private val renderMicroInteractions: (String) -> String,
    ) : WebViewAssetLoader.PathHandler {
        private val assetManager = context.assets

        override fun handle(path: String): WebResourceResponse? {
            val normalizedPath =
                path
                    .trimStart('/')
                    .removePrefix("$ASSET_PATH/")
                    .ifEmpty { "index.html" }

            val assetPath = "$ASSET_PATH/$normalizedPath"
            val mimeType = normalizedPath.toMimeType()

            return try {
                if (normalizedPath == MICRO_INTERACTIONS_ASSET_PATH) {
                    val baseJson =
                        assetManager.open(assetPath).use { stream ->
                            stream.bufferedReader().use { it.readText() }
                        }
                    val renderedJson = renderMicroInteractions(baseJson)
                    WebResourceResponse(
                        mimeType,
                        Charsets.UTF_8.name(),
                        ByteArrayInputStream(renderedJson.toByteArray(Charsets.UTF_8)),
                    )
                } else if (normalizedPath == PROJECT_CONFIG_ASSET_PATH) {
                    val baseJson =
                        assetManager.open(assetPath).use { stream ->
                            stream.bufferedReader().use { it.readText() }
                        }
                    val renderedJson = ErikProjectConfig.renderForAndroidWebView(baseJson)
                    WebResourceResponse(
                        mimeType,
                        Charsets.UTF_8.name(),
                        ByteArrayInputStream(renderedJson.toByteArray(Charsets.UTF_8)),
                    )
                } else {
                    val inputStream = assetManager.open(assetPath)
                    WebResourceResponse(mimeType, null, inputStream)
                }
            } catch (_: java.io.FileNotFoundException) {
                null
            }
        }

        private fun String.toMimeType(): String =
            when (substringAfterLast('.', "").lowercase()) {
                "html" -> "text/html"
                "css" -> "text/css"
                "js" -> "application/javascript"
                "json" -> "application/json"
                "wasm" -> "application/wasm"
                "png" -> "image/png"
                "jpg", "jpeg" -> "image/jpeg"
                "ico" -> "image/x-icon"
                "svg" -> "image/svg+xml"
                "ttf" -> "font/ttf"
                "woff" -> "font/woff"
                "woff2" -> "font/woff2"
                "mp4" -> "video/mp4"
                else -> "application/octet-stream"
            }
    }

    companion object {
        private const val ASSET_PATH = "erik_resources"
        private const val MICRO_INTERACTIONS_ASSET_PATH = "erik/resources/micro-interactions.json"
        private const val PROJECT_CONFIG_ASSET_PATH = "erik/resources/project.json"
        private const val INTERIOR_PANORAMA_ASSET_PATH = "interior/panorama_interior_v2.webp"
        private const val JS_BRIDGE_NAME = "ErikNativeBridge"
        private const val ENTRYPOINT_URL = "https://appassets.androidplatform.net/index.html"
        private const val LOG_TAG = "ErikFragment"
        private const val INITIALIZATION_LIGHT_REFRESH_DELAY_MS = 250L
        private const val LIGHT_REFRESH_SETTLE_MS = 150L
    }
}
