package com.eccentric.erik.android

internal object ErikBrowserCommand {
    fun setColor(colorName: String): String = "__erik.setColor('${colorName.escapeJsString()}')"

    fun setBGColor(hex: String): String = "__erik.setBGColor('${hex.escapeJsString()}')"

    fun toggleLights(lightsOn: Boolean): String = "__erik.toggleLights($lightsOn)"

    fun refreshLightsAfterInitialization(): String =
        """
        (function() {
          const api = window.__erik;
          if (!api ||
              typeof api.getState !== 'function' ||
              typeof api.toggleLights !== 'function') {
            return;
          }
          const state = api.getState() || {};
          const lightsOn = state.lightsOn === true;
          api.toggleLights(!lightsOn);
          setTimeout(function() {
            api.toggleLights(lightsOn);
          }, 100);
        })()
        """.trimIndent()

    fun goExterior(): String = "__erik.goExterior()"

    fun play(
        name: String,
        direction: String = "forward",
    ): String = "__erik.play('${name.escapeJsString()}', '${direction.escapeJsString()}')"

    fun allDoors(direction: String = "forward"): String = "__erik.allDoors('${direction.escapeJsString()}')"

    fun skipIntro(): String = "__erik.skipIntro()"

    fun getState(): String = "JSON.stringify(__erik.getState())"

    fun doorStates(): String = "JSON.stringify(__erik.doorStates())"

    private fun String.escapeJsString(): String =
        buildString {
            this@escapeJsString.forEach { char ->
                when (char) {
                    '\\' -> append("\\\\")
                    '\'' -> append("\\'")
                    '\n' -> append("\\n")
                    '\r' -> append("\\r")
                    else -> append(char)
                }
            }
        }
}
