package com.eccentric.erik.android

import org.json.JSONObject

/**
 * Parses a background colour as an ARGB int. Accepts #RGB, #RRGGBB and #AARRGGBB; returns null for
 * anything else so a bad value is rejected instead of drawn as black.
 */
internal fun parseBackgroundColor(hex: String): Int? {
    val value = hex.trim()
    if (!value.startsWith("#")) return null
    val digits = value.drop(1)
    if (!digits.all { it in '0'..'9' || it.lowercaseChar() in 'a'..'f' }) return null
    val argb =
        when (digits.length) {
            3 -> "FF" + digits.map { "$it$it" }.joinToString("")
            6 -> "FF$digits"
            8 -> digits
            else -> return null
        }
    return argb.toLong(16).toInt()
}

/** True when this background asks for an opaque colour that can actually be drawn. */
internal fun ErikBackgroundState?.isOpaqueBackground(): Boolean {
    val background = this ?: return false
    if (background.transparent != false) return false
    // No colour means the default black; an unparseable colour counts as transparent.
    val requestedColor = background.color ?: return true
    return parseBackgroundColor(requestedColor) != null
}

/**
 * The scene in the WebView is always transparent; the background is drawn natively. Replaces the
 * scene's background in a getState() result with [background], unless the app never set one.
 */
internal fun withReportedBackground(
    stateJson: String,
    background: ErikBackgroundState,
): String {
    if (background == ErikBackgroundState()) return stateJson
    return runCatching {
        JSONObject(stateJson)
            .put(
                "background",
                JSONObject().apply {
                    put("transparent", !background.isOpaqueBackground())
                    background.color?.let { put("color", it) }
                },
            ).toString()
    }.getOrDefault(stateJson)
}
