package com.eccentric.erik.android

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment

/**
 * Backwards-compatible Fragment façade for the Erik renderer.
 *
 * [ErikSdk] selects local or private-service hosting before this Fragment's
 * view is created. Local hosting remains the compatibility default.
 */
class ErikFragment : Fragment() {
    interface Listener {
        fun onStateChanged(state: ErikRuntimeState)

        fun onHotspotResult(result: ErikHotspotResult) = Unit
    }

    private val pendingViewActions = mutableListOf<(ErikHost) -> Unit>()
    private var host: ErikHost? = null
    private var listener: Listener? = null
    private var cachedState = ErikRuntimeState()
    private var desiredState = ErikState()
    private var hasPendingExplicitInit = false
    private var interior = false

    /**
     * True when this Fragment shows the interior, or will once its renderer is ready. It survives
     * view recreation; a shared service session keeps one view for every Fragment attached to it.
     */
    val isInterior: Boolean
        get() = host?.isShowingInterior ?: interior

    /**
     * True when the 3D view is drawn above this app's window and therefore covers app views that
     * overlap it, such as a navigation drawer or bottom sheet; hide the 3D view while they show.
     * Only the exterior with a transparent background needs this. Separate windows such as
     * dialogs are never covered.
     */
    val coversAppViews: Boolean
        get() = host?.coversAppViews ?: false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        restoredDesiredState(savedInstanceState)?.let { desiredState = it }
        interior = savedInstanceState?.getBoolean(KEY_INTERIOR) ?: false
    }

    override fun onSaveInstanceState(outState: Bundle) {
        outState.putSerializable(KEY_DESIRED_STATE, desiredState)
        outState.putBoolean(KEY_INTERIOR, isInterior)
        super.onSaveInstanceState(outState)
    }

    fun setListener(listener: Listener?) {
        this.listener = listener
        listener?.onStateChanged(cachedState)
    }

    fun currentState(): ErikRuntimeState = host?.currentState() ?: cachedState

    fun getState(callback: ErikJsonCallback) {
        withHost {
            it.getState(
                object : ErikJsonCallback {
                    override fun onSuccess(json: String) {
                        runCatching { ErikState.fromJson(json) }.onSuccess { state -> desiredState = state }
                        callback.onSuccess(json)
                    }

                    override fun onError(message: String) {
                        callback.onError(message)
                    }
                },
            )
        }
    }

    fun getState(callback: ErikStateCallback) {
        withHost {
            it.getState(
                object : ErikStateCallback {
                    override fun onSuccess(state: ErikState) {
                        desiredState = state
                        callback.onSuccess(state)
                    }

                    override fun onError(message: String) {
                        callback.onError(message)
                    }
                },
            )
        }
    }

    fun getColors(callback: ErikColorsCallback) {
        withHost {
            it.getAssetConfig(
                object : ErikJsonCallback {
                    override fun onSuccess(json: String) {
                        runCatching { ErikAssetConfig.fromJson(json).colors }
                            .onSuccess(callback::onSuccess)
                            .onFailure { error ->
                                callback.onError(error.message ?: "Unable to parse Erik asset colors.")
                            }
                    }

                    override fun onError(message: String) {
                        callback.onError(message)
                    }
                },
            )
        }
    }

    fun getCapabilities(callback: ErikVehicleCapabilitiesCallback) {
        withHost {
            it.getCapabilities(
                object : ErikJsonCallback {
                    override fun onSuccess(json: String) {
                        runCatching { ErikVehicleCapabilities.fromJson(json) }
                            .onSuccess(callback::onSuccess)
                            .onFailure { error ->
                                callback.onError(
                                    error.message ?: "Unable to parse Erik vehicle capabilities.",
                                )
                            }
                    }

                    override fun onError(message: String) {
                        callback.onError(message)
                    }
                },
            )
        }
    }

    fun init(
        state: ErikState,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        remember(state)
        val currentHost = host
        if (currentHost == null) {
            hasPendingExplicitInit = true
            callback.onSuccess()
        } else {
            currentHost.init(state, callback)
        }
    }

    fun openDoor(
        door: ErikDoor,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        rememberDoor(door, open = true)
        withHost { it.openDoor(door, callback) }
    }

    fun closeDoor(
        door: ErikDoor,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        rememberDoor(door, open = false)
        withHost { it.closeDoor(door, callback) }
    }

    fun setAllDoorsOpen(
        open: Boolean,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        rememberAllDoors(open)
        withHost { it.setAllDoorsOpen(open, callback) }
    }

    fun play(
        name: String,
        direction: String = "forward",
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        rememberDoorAnimation(name, direction)
        withHost { it.play(name, direction, callback) }
    }

    fun allDoors(
        direction: String = "forward",
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        rememberAllDoorsDirection(direction)
        withHost { it.allDoors(direction, callback) }
    }

    fun goInterior(callback: ErikCommandCallback = ErikCommandCallback.NONE) {
        interior = true
        withHost { it.goInterior(callback) }
    }

    fun goExterior(callback: ErikCommandCallback = ErikCommandCallback.NONE) {
        interior = false
        withHost { it.goExterior(callback) }
    }

    fun toggleLights(
        lightsOn: Boolean,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        remember(ErikState(lightsOn = lightsOn))
        withHost { it.toggleLights(lightsOn, callback) }
    }

    fun setLightState(
        light: ErikLight,
        state: ErikLightState,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        remember(ErikState(lightStates = mapOf(light to state)))
        withHost { it.setLightState(light, state, callback) }
    }

    fun setRotationSpeed(
        speed: Double,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        require(speed >= 0.0) { "Rotation speed must be non-negative." }
        remember(ErikState(rotationSpeed = speed))
        withHost { it.setRotationSpeed(speed, callback) }
    }

    fun setColor(
        colorName: String,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        remember(ErikState(carpaint = colorName))
        withHost { it.setColor(colorName, callback) }
    }

    fun setBGColor(
        hex: String,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        if (parseBackgroundColor(hex) == null) {
            callback.onError("Invalid background colour: $hex")
            return
        }
        remember(ErikState(background = ErikBackgroundState(transparent = false, color = hex)))
        withHost { it.setBGColor(hex, callback) }
    }

    fun skipIntro(callback: ErikCommandCallback = ErikCommandCallback.NONE) {
        withHost { it.skipIntro(callback) }
    }

    fun doorStates(callback: ErikJsonCallback) {
        withHost { it.doorStates(callback) }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View {
        val applyExplicitState = hasPendingExplicitInit
        hasPendingExplicitInit = false
        val createdHost =
            createErikHost(
                context = requireContext(),
                initialState = desiredState,
                applyExplicitState = applyExplicitState,
            )
        host = createdHost
        createdHost.setHotspotListener { result ->
            if (result.errorMessage == null) {
                remember(ErikState(doorStates = mapOf(result.door to result.isOpen)))
            }
            listener?.onHotspotResult(result)
        }
        createdHost.setListener { state ->
            cachedState = state
            listener?.onStateChanged(state)
        }
        val actions = pendingViewActions.toList()
        pendingViewActions.clear()
        actions.forEach { it(createdHost) }
        if (createdHost is LocalErikHost) {
            // A new local renderer starts outside; restore the view this Fragment had.
            if (interior && !createdHost.isShowingInterior) createdHost.goInterior(ErikCommandCallback.NONE)
        } else {
            // A shared service session keeps its own view across Fragments.
            interior = createdHost.isShowingInterior
        }
        return createdHost.view
    }

    override fun onResume() {
        super.onResume()
        host?.resume()
    }

    override fun onPause() {
        host?.pause()
        super.onPause()
    }

    override fun onDestroyView() {
        host?.destroy()
        host = null
        super.onDestroyView()
    }

    private fun withHost(action: (ErikHost) -> Unit) {
        val currentHost = host
        if (currentHost == null) {
            pendingViewActions += action
        } else {
            action(currentHost)
        }
    }

    private fun remember(state: ErikState) {
        desiredState = desiredState.mergedWith(state)
    }

    private fun rememberDoor(
        door: ErikDoor,
        open: Boolean,
    ) {
        remember(ErikState(doorStates = mapOf(door to open)))
    }

    private fun rememberDoorAnimation(name: String, direction: String) {
        doorAnimationState(name, direction)?.let { remember(it) }
    }

    private fun rememberAllDoorsDirection(direction: String) {
        allDoorsAnimationState(direction)?.let { remember(it) }
    }

    private fun rememberAllDoors(open: Boolean) {
        remember(allDoorsState(open))
    }

    @Suppress("DEPRECATION")
    private fun restoredDesiredState(savedInstanceState: Bundle?): ErikState? =
        savedInstanceState?.getSerializable(KEY_DESIRED_STATE) as? ErikState

    companion object {
        private const val KEY_DESIRED_STATE = "com.eccentric.erik.android.desiredState"
        private const val KEY_INTERIOR = "com.eccentric.erik.android.interior"
    }
}
