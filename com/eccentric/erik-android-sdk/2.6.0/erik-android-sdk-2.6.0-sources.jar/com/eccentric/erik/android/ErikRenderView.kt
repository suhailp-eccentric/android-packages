package com.eccentric.erik.android

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.FrameLayout
import androidx.core.view.doOnLayout
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewClientCompat
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.panoramagl.PLImage
import com.panoramagl.PLManager
import com.panoramagl.PLSphericalPanorama
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.InputStream

class ErikRenderView internal constructor(
    context: Context,
    initialStates: List<ErikState>,
    assetDirectory: File?,
) : FrameLayout(context) {
    @JvmOverloads
    constructor(
        context: Context,
        initialStates: List<ErikState> = emptyList(),
    ) : this(context, initialStates, ErikSdk.currentAssetDirectory())

    private val pendingCommands = mutableListOf<PendingCommand>()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val doorCommandOrder = ErikDoorCommandOrder()
    private val microInteractionsConfig = ErikMicroInteractionsConfig()
    private val assetSource = ErikAssetSource(context, assetDirectory)
    private var hotspotListener: ((ErikHotspotResult) -> Unit)? = null
    private var listener: ((ErikRuntimeState) -> Unit)? = null
    private var webView: WebView? = null
    private var assetLoader: WebViewAssetLoader? = null
    private var panoramaManager: PLManager? = null
    private var panoramaContainer: FrameLayout? = null
    private var webViewContainer: FrameLayout? = null
    private var isReady = false
    private var isPageFinished = false
    private var isIntroAnimationPlaying = false
    private var isInitializationComplete = false
    private var activeSurface = ActiveSurface.EXTERIOR
    private var resumed = false
    private var detachedFromWindow = false

    // The background the app asked for. It is drawn natively behind the always-transparent scene,
    // so the colour is exact and also fills the space around the car when this view is shown
    // through a surface below the host window.
    private var background = ErikBackgroundState()

    init {
        initialStates.forEach { state ->
            microInteractionsConfig.apply(takeBackground(state))
        }
        assetLoader =
            WebViewAssetLoader.Builder()
                .addPathHandler("/", ErikAssetPathHandler(assetSource, microInteractionsConfig::render))
                .build()
        createRendererHierarchy()
    }

    fun setHotspotListener(listener: ((ErikHotspotResult) -> Unit)?) {
        hotspotListener = listener
    }

    fun setListener(listener: ((ErikRuntimeState) -> Unit)?) {
        this.listener = listener
        dispatchState()
    }

    fun currentState(): ErikRuntimeState =
        ErikRuntimeState(
            isIntroAnimationPlaying = isIntroAnimationPlaying,
            isInitializationComplete = isInitializationComplete,
        )

    fun getState(callback: ErikJsonCallback) {
        runExpression(
            ErikBrowserCommand.getState(),
            object : ErikJsonCallback {
                override fun onSuccess(json: String) = callback.onSuccess(withReportedBackground(json, background))

                override fun onError(message: String) = callback.onError(message)
            },
        )
    }

    fun getState(callback: ErikStateCallback) {
        getState(
            object : ErikJsonCallback {
                override fun onSuccess(json: String) {
                    runCatching { ErikState.fromJson(json) }
                        .onSuccess(callback::onSuccess)
                        .onFailure { error ->
                            callback.onError(error.message ?: "Unable to parse Erik state.")
                        }
                }

                override fun onError(message: String) {
                    callback.onError(message)
                }
            },
        )
    }

    fun getAssetConfig(callback: ErikJsonCallback) {
        runOnMainThread {
            runCatching {
                assetSource.open(ASSET_CONFIG_ASSET_PATH).use { stream ->
                    stream.bufferedReader().use { it.readText() }
                }
            }.onSuccess(callback::onSuccess)
                .onFailure { error ->
                    callback.onError(error.message ?: "Unable to read Erik asset config.")
                }
        }
    }

    fun getCapabilities(callback: ErikJsonCallback) {
        runOnMainThread {
            runCatching {
                assetSource.open("$ASSET_PATH/$MICRO_INTERACTIONS_ASSET_PATH").use { stream ->
                    val json = stream.bufferedReader().use { it.readText() }
                    ErikVehicleCapabilities.detectFromMicroInteractions(json).toJson()
                }
            }.onSuccess(callback::onSuccess)
                .onFailure { error ->
                    callback.onError(error.message ?: "Unable to read Erik vehicle capabilities.")
                }
        }
    }

    fun init(
        state: ErikState,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
        commandToken: String? = null,
    ) {
        runOnMainThread {
            val tokens = recordDoorCommand(state.doorStates?.keys.orEmpty(), commandToken)
            val sceneState = takeBackground(state)
            microInteractionsConfig.apply(sceneState)
            if (isReady && webView != null) {
                runCommand(ErikDoorCommandOrder.stamp(tokens) + ErikBrowserCommand.init(sceneState.toJson()), callback)
            } else {
                reloadWebViewWithCurrentConfig()
                callback.onSuccess()
            }
        }
    }

    fun openDoor(
        door: ErikDoor,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
        commandToken: String? = null,
    ) {
        play(door.jsName, direction = door.openDirection, callback = callback, commandToken = commandToken)
    }

    fun closeDoor(
        door: ErikDoor,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
        commandToken: String? = null,
    ) {
        play(door.jsName, direction = door.closeDirection, callback = callback, commandToken = commandToken)
    }

    fun setAllDoorsOpen(
        open: Boolean,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
        commandToken: String? = null,
    ) {
        val direction = if (open) "forward" else "reverse"
        allDoors(direction, callback, commandToken)
    }

    fun play(
        name: String,
        direction: String = "forward",
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
        commandToken: String? = null,
    ) {
        runOnMainThread {
            val tokens = recordDoorCommand(ErikDoor.entries.filter { it.jsName == name }, commandToken)
            doorAnimationState(name, direction)?.let(microInteractionsConfig::apply)
            runCommand(ErikDoorCommandOrder.stamp(tokens) + ErikBrowserCommand.play(name, direction), callback)
        }
    }

    fun allDoors(
        direction: String = "forward",
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
        commandToken: String? = null,
    ) {
        runOnMainThread {
            val tokens = recordDoorCommand(allDoorsState(true).doorStates.orEmpty().keys, commandToken)
            allDoorsAnimationState(direction)?.let(microInteractionsConfig::apply)
            runCommand(ErikDoorCommandOrder.stamp(tokens) + ErikBrowserCommand.allDoors(direction), callback)
        }
    }

    fun goInterior(callback: ErikCommandCallback = ErikCommandCallback.NONE) {
        runOnMainThread {
            resetInteriorView()
            activeSurface = ActiveSurface.INTERIOR
            updateSurfaceVisibility()
            callback.onSuccess()
        }
    }

    internal val isShowingInterior: Boolean
        get() = activeSurface == ActiveSurface.INTERIOR

    fun goExterior(callback: ErikCommandCallback = ErikCommandCallback.NONE) {
        runOnMainThread {
            activeSurface = ActiveSurface.EXTERIOR
            updateSurfaceVisibility()
            callback.onSuccess()
        }
    }

    fun toggleLights(
        lightsOn: Boolean,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        runCommand(ErikBrowserCommand.toggleLights(lightsOn), callback)
    }

    fun setLightState(
        light: ErikLight,
        state: ErikLightState,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        runCommand(ErikBrowserCommand.setLightState(light, state), callback)
    }

    fun setRotationSpeed(
        speed: Double,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        require(speed >= 0.0) { "Rotation speed must be non-negative." }
        runCommand(ErikBrowserCommand.setRotationSpeed(speed), callback)
    }

    fun setColor(
        colorName: String,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        runCommand(ErikBrowserCommand.setColor(colorName), callback)
    }

    fun setBGColor(
        hex: String,
        callback: ErikCommandCallback = ErikCommandCallback.NONE,
    ) {
        runOnMainThread {
            if (parseBackgroundColor(hex) == null) {
                callback.onError("Invalid background colour: $hex")
                return@runOnMainThread
            }
            takeBackground(ErikState(background = ErikBackgroundState(transparent = false, color = hex)))
            callback.onSuccess()
        }
    }

    /**
     * Applies [state]'s background natively and returns the state without it, so the scene in the
     * WebView keeps the vehicle pack's transparent background.
     */
    private fun takeBackground(state: ErikState): ErikState {
        val requested = state.background ?: return state
        background = checkNotNull(ErikState(background = background).mergedWith(ErikState(background = requested)).background)
        setBackgroundColor(
            if (background.isOpaqueBackground()) {
                background.color?.let(::parseBackgroundColor) ?: Color.BLACK
            } else {
                Color.TRANSPARENT
            },
        )
        return state.copy(background = null)
    }

    fun skipIntro(callback: ErikCommandCallback = ErikCommandCallback.NONE) {
        runCommand(ErikBrowserCommand.skipIntro(), callback)
    }

    fun doorStates(callback: ErikJsonCallback) {
        runExpression(ErikBrowserCommand.doorStates(), callback)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createRendererHierarchy() {
        LayoutInflater.from(context).inflate(R.layout.fragment_erik, this, true)
        val panoramaHost = findViewById<FrameLayout>(R.id.panorama_container)
        val webViewHost = findViewById<FrameLayout>(R.id.webview_container)

        panoramaContainer = panoramaHost
        webViewContainer = webViewHost
        configurePanorama(panoramaHost)

        val createdWebView =
            ErikWebView(context).apply {
                layoutParams =
                    FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT,
                    )
                setBackgroundColor(Color.TRANSPARENT)
                overScrollMode = View.OVER_SCROLL_NEVER
                isLongClickable = false
                isHapticFeedbackEnabled = false

                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    mediaPlaybackRequiresUserGesture = false
                    cacheMode = WebSettings.LOAD_DEFAULT
                    mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                }

                installAndroidWebViewRenderingShim(this)
                addJavascriptInterface(ErikJavascriptBridge(::handleJavascriptMessage), JS_BRIDGE_NAME)
                webChromeClient = createWebChromeClient()
                webViewClient = createWebViewClient()
                setOnTouchListener(
                    createTouchInterceptor { event ->
                        if (activeSurface == ActiveSurface.INTERIOR) {
                            panoramaManager?.onTouchEvent(event) == true
                        } else {
                            false
                        }
                    },
                )
            }

        webView = createdWebView
        webViewHost.addView(createdWebView)
        updateSurfaceVisibility()
        createdWebView.doOnLayout {
            createdWebView.loadUrl(ENTRYPOINT_URL)
        }
    }

    private fun installAndroidWebViewRenderingShim(target: WebView) {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            Log.w(LOG_TAG, "Document-start JavaScript is not supported by this WebView")
            return
        }

        WebViewCompat.addDocumentStartJavaScript(
            target,
            """
            (() => {
              window.__erikAndroidWebView = true;
              try {
                localStorage.clear();
              } catch (_) {}
              const disableSelection = () => {
                const style = document.createElement('style');
                style.textContent = `
                  *, *::before, *::after {
                    -webkit-user-select: none !important;
                    user-select: none !important;
                    -webkit-touch-callout: none !important;
                  }
                `;
                (document.head || document.documentElement).appendChild(style);
              };
              if (document.documentElement) {
                disableSelection();
              } else {
                document.addEventListener('DOMContentLoaded', disableSelection, { once: true });
              }
              try {
                Object.defineProperty(Navigator.prototype, 'gpu', {
                  configurable: true,
                  get: () => undefined
                });
              } catch (_) {}
              try {
                Object.defineProperty(navigator, 'gpu', {
                  configurable: true,
                  get: () => undefined
                });
              } catch (_) {}
              console.log('[ErikAndroid] WebGPU disabled for transparent WebView composition');
            })();
            """.trimIndent(),
            setOf("https://appassets.androidplatform.net"),
        )
    }

    override fun onDetachedFromWindow() {
        detachedFromWindow = true
        super.onDetachedFromWindow()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        // A detached GLSurfaceView loses its GL context and the panorama texture with it (an
        // off-screen ViewPager2 page, a service rehost), so the interior would come back black.
        // Rebuild now, before the children re-attach: PanoramaGL's onDestroy busy-waits while a
        // panorama renders, so a later rebuild can hang the main thread.
        if (detachedFromWindow) {
            detachedFromWindow = false
            rebuildPanorama()
        }
    }

    fun resume() {
        resumed = true
        webView?.onResume()
        panoramaManager?.onResume()
    }

    fun pause() {
        resumed = false
        panoramaManager?.onPause()
        webView?.onPause()
    }

    /** Re-creates the interior panorama, whose GL texture does not survive leaving the window. */
    private fun rebuildPanorama() {
        runOnMainThread {
            val container = panoramaContainer ?: return@runOnMainThread
            panoramaManager?.onDestroy()
            panoramaManager = null
            container.removeAllViews()
            configurePanorama(container)
            if (resumed) panoramaManager?.onResume()
            updateSurfaceVisibility()
        }
    }

    fun destroy() {
        failPendingCommands("Erik view was destroyed before the command completed.")
        mainHandler.removeCallbacksAndMessages(null)
        panoramaManager?.onDestroy()
        panoramaManager = null
        panoramaContainer?.removeAllViews()
        panoramaContainer = null
        webViewContainer?.removeAllViews()
        webViewContainer = null
        webView?.removeJavascriptInterface(JS_BRIDGE_NAME)
        webView?.apply {
            stopLoading()
            webChromeClient = null
            destroy()
        }
        webView = null
        assetLoader = null
        listener = null
        hotspotListener = null
        removeAllViews()
    }

    private fun configurePanorama(container: FrameLayout) {
        val manager =
            PLManager(context).apply {
                setContentView(container)
                onCreate()
                isScrollingEnabled = true
                isInertiaEnabled = true
                isZoomEnabled = true
                isAccelerometerEnabled = false
            }

        val panoramaBitmap =
            assetSource.open(INTERIOR_PANORAMA_ASSET_PATH).use { stream ->
                BitmapFactory.decodeStream(stream)
            }
        val panorama =
            PLSphericalPanorama().apply {
                setImage(PLImage(panoramaBitmap, false))
                camera.lookAtAndZoomFactor(0f, 0f, 0f, false)
                camera.rotationSensitivity = 20f
            }

        manager.panorama = panorama
        val panoramaTouchView = manager.getGLSurfaceView() ?: container
        panoramaTouchView.setOnTouchListener(createTouchInterceptor { event ->
            manager.onTouchEvent(event)
        })
        panoramaManager = manager
    }

    private fun createTouchInterceptor(
        onTouch: ((MotionEvent) -> Boolean)? = null,
    ): View.OnTouchListener =
        View.OnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN,
                MotionEvent.ACTION_MOVE -> {
                    view.parent?.requestDisallowInterceptTouchEvent(true)
                }

                MotionEvent.ACTION_UP,
                MotionEvent.ACTION_CANCEL -> {
                    view.parent?.requestDisallowInterceptTouchEvent(false)
                }
            }
            onTouch?.invoke(event) ?: false
        }

    private fun updateSurfaceVisibility() {
        val showingInterior = activeSurface == ActiveSurface.INTERIOR
        panoramaContainer?.visibility = if (showingInterior) View.VISIBLE else View.INVISIBLE
        // Keep the WebView visible in the Android view hierarchy. Removing it
        // with INVISIBLE can discard WebGL's presentation surface, leaving a
        // white canvas when returning from the panorama.
        webViewContainer?.visibility = View.VISIBLE
        webViewContainer?.alpha = if (showingInterior) 0f else 1f
    }

    private fun reloadWebViewWithCurrentConfig() {
        val currentWebView = webView ?: return
        isPageFinished = false
        updateSurfaceVisibility()
        setReady(false)
        setInitializationComplete(false)
        currentWebView.loadUrl(ENTRYPOINT_URL)
    }

    private fun resetInteriorView() {
        panoramaManager?.reset()
    }

    private fun createWebChromeClient(): WebChromeClient =
        object : WebChromeClient() {
            override fun onConsoleMessage(consoleMessage: ConsoleMessage): Boolean {
                val message = consoleMessage.message()
                when {
                    message.contains("[ErikPlayer] initialization started") ->
                        setInitializationComplete(false)
                    message.contains("[ERIK] revealed:") ->
                        setInitializationComplete(true)
                    message.contains("Starting trailer camera") -> {
                        setIntroAnimationPlaying(true)
                    }
                    message.contains("Trailer camera sequence finished") -> setIntroAnimationPlaying(false)
                    message.contains("Trailer camera sequence skipped") -> setIntroAnimationPlaying(false)
                }
                return true
            }
        }

    private fun createWebViewClient(): WebViewClientCompat =
        object : WebViewClientCompat() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest,
            ): WebResourceResponse? = assetLoader?.shouldInterceptRequest(request.url)

            override fun onReceivedError(
                view: WebView,
                request: WebResourceRequest,
                error: androidx.webkit.WebResourceErrorCompat,
            ) {
                Log.e(
                    LOG_TAG,
                    "request error: ${request.url} code=${error.errorCode} description=${error.description}",
                )
                super.onReceivedError(view, request, error)
            }

            override fun onReceivedHttpError(
                view: WebView,
                request: WebResourceRequest,
                errorResponse: WebResourceResponse,
            ) {
                Log.e(
                    LOG_TAG,
                    "http error: ${request.url} status=${errorResponse.statusCode} reason=${errorResponse.reasonPhrase}",
                )
                super.onReceivedHttpError(view, request, errorResponse)
            }

            override fun onPageStarted(
                view: WebView,
                url: String?,
                favicon: android.graphics.Bitmap?,
            ) {
                isPageFinished = false
                updateSurfaceVisibility()
                setReady(false)
                setInitializationComplete(false)
                isIntroAnimationPlaying = false
                super.onPageStarted(view, url, favicon)
            }

            override fun onPageFinished(
                view: WebView,
                url: String?,
            ) {
                isPageFinished = true
                flushPendingCommands()
                injectBootstrapScript(view)
                super.onPageFinished(view, url)
            }
        }

    internal fun restoreDoorCommandTokens(json: String) = doorCommandOrder.restore(json)

    private fun recordDoorCommand(doors: Collection<ErikDoor>, token: String?): String =
        if (token == null) doorCommandOrder.record(doors) else doorCommandOrder.record(doors, token)

    private fun handleJavascriptMessage(message: String) {
        runOnMainThread {
            if (message == "ready") {
                setReady(true)
                flushPendingCommands()
            } else {
                val result = ErikHotspotResult.fromJson(message) ?: return@runOnMainThread
                if (!doorCommandOrder.accepts(result)) return@runOnMainThread
                if (result.errorMessage == null) {
                    microInteractionsConfig.apply(ErikState(doorStates = mapOf(result.door to result.isOpen)))
                }
                hotspotListener?.invoke(result)
            }
        }
    }


    private fun injectBootstrapScript(target: WebView) {
        target.evaluateJavascript(
            ErikDoorCommandOrder.stamp(doorCommandOrder.toJson()) + """
            (function bootstrapErikNativeBridge() {
              let attempts = 0;
              function hasLiveErikApi() {
                if (typeof window.__erik === 'undefined' ||
                    typeof window.__erik.getState !== 'function' ||
                    typeof window.__erik.doorStates !== 'function' ||
                    typeof window.__erik.play !== 'function') {
                  return false;
                }

                try {
                  return window.__erik.getState() !== null;
                } catch (error) {
                  return false;
                }
              }

              (function tick() {
                if (hasLiveErikApi() &&
                    window.$JS_BRIDGE_NAME &&
                    typeof window.$JS_BRIDGE_NAME.postMessage === 'function') {
                  window.$JS_BRIDGE_NAME.postMessage('ready');
                  return;
                }
                if (attempts++ < 60) {
                  setTimeout(tick, 250);
                }
              })();
            })();
            """.trimIndent(),
            null,
        )
    }

    private fun runCommand(
        command: String,
        callback: ErikCommandCallback,
        requiresReady: Boolean = true,
    ) {
        runJavascript(command, returnsValue = false, requiresReady = requiresReady, callback = callback.toPendingCallback())
    }

    private fun runExpression(
        expression: String,
        callback: ErikJsonCallback,
    ) {
        runJavascript(expression, returnsValue = true, requiresReady = true, callback = callback.toPendingCallback())
    }

    private fun runJavascript(
        script: String,
        returnsValue: Boolean,
        requiresReady: Boolean,
        callback: ErikPendingCallback,
    ) {
        val currentWebView = webView
        if (currentWebView == null) {
            pendingCommands += PendingCommand(script, returnsValue, requiresReady, callback)
            return
        }

        if (!canEvaluate(requiresReady)) {
            pendingCommands += PendingCommand(script, returnsValue, requiresReady, callback)
            return
        }

        evaluateCommand(currentWebView, PendingCommand(script, returnsValue, requiresReady, callback))
    }

    private fun flushPendingCommands() {
        val currentWebView = webView ?: return
        if (pendingCommands.isEmpty()) {
            return
        }

        val queuedCommands = pendingCommands.filter { canEvaluate(it.requiresReady) }
        if (queuedCommands.isEmpty()) {
            return
        }

        val waitingCommands = pendingCommands.filterNot { canEvaluate(it.requiresReady) }
        pendingCommands.clear()
        pendingCommands.addAll(waitingCommands)
        queuedCommands.forEach { pending ->
            evaluateCommand(currentWebView, pending)
        }
    }

    private fun evaluateCommand(
        target: WebView,
        pending: PendingCommand,
    ) {
        val successBody =
            if (pending.returnsValue) {
                "return 'ok:' + (${pending.script});"
            } else {
                """
                ${pending.script};
                return 'ok';
                """.trimIndent()
            }
        val wrappedCommand =
            """
            (function() {
              try {
                $successBody
              } catch (error) {
                return 'error:' + (error && error.message ? error.message : String(error));
              }
            })();
            """.trimIndent()

        target.post {
            target.evaluateJavascript(wrappedCommand) { rawResult ->
                val normalizedResult = normalizeJavascriptResult(rawResult)
                if (normalizedResult.startsWith("error:")) {
                    pending.callback.onError(normalizedResult.removePrefix("error:"))
                } else if (pending.returnsValue) {
                    pending.callback.onSuccess(normalizedResult.removePrefix("ok:"))
                } else {
                    pending.callback.onSuccess("")
                }
            }
        }
    }

    private fun canEvaluate(requiresReady: Boolean): Boolean = if (requiresReady) isReady else isPageFinished

    private fun normalizeJavascriptResult(rawResult: String?): String {
        if (rawResult == null || rawResult == "null") {
            return ""
        }

        return rawResult
            .removeSurrounding("\"")
            .replace("\\\\", "\\")
            .replace("\\n", "\n")
            .replace("\\\"", "\"")
    }

    private fun failPendingCommands(message: String) {
        runOnMainThread {
            if (pendingCommands.isEmpty()) {
                return@runOnMainThread
            }

            val commandsToFail = pendingCommands.toList()
            pendingCommands.clear()
            commandsToFail.forEach { pending ->
                pending.callback.onError(message)
            }
        }
    }

    private fun setReady(ready: Boolean) {
        if (!isMainThread()) {
            runOnMainThread { setReady(ready) }
            return
        }

        if (isReady == ready) {
            return
        }

        isReady = ready
        dispatchState()
    }

    private fun setIntroAnimationPlaying(playing: Boolean) {
        if (!isMainThread()) {
            runOnMainThread { setIntroAnimationPlaying(playing) }
            return
        }

        if (isIntroAnimationPlaying == playing) return

        isIntroAnimationPlaying = playing
        dispatchState()
    }

    private fun setInitializationComplete(complete: Boolean) {
        if (!isMainThread()) {
            runOnMainThread { setInitializationComplete(complete) }
            return
        }

        if (isInitializationComplete == complete) {
            return
        }

        isInitializationComplete = complete
        dispatchState()
    }

    private fun dispatchState() {
        runOnMainThread {
            listener?.invoke(currentState())
        }
    }

    private data class PendingCommand(
        val script: String,
        val returnsValue: Boolean,
        val requiresReady: Boolean,
        val callback: ErikPendingCallback,
    )

    private enum class ActiveSurface {
        EXTERIOR,
        INTERIOR,
    }

    private class ErikJavascriptBridge(
        private val onMessage: (String) -> Unit,
    ) {
        @JavascriptInterface
        fun postMessage(message: String) {
            onMessage(message)
        }
    }

    private class ErikWebView(context: Context) : WebView(context) {
        override fun performLongClick(): Boolean = true
    }

    private fun runOnMainThread(action: () -> Unit) {
        if (isMainThread()) {
            action()
        } else {
            mainHandler.post(action)
        }
    }

    private fun isMainThread(): Boolean = Looper.myLooper() == Looper.getMainLooper()

    private class ErikAssetPathHandler(
        private val assetSource: ErikAssetSource,
        private val renderMicroInteractions: (String) -> String,
    ) : WebViewAssetLoader.PathHandler {
        override fun handle(path: String): WebResourceResponse? {
            val normalizedPath =
                path
                    .trimStart('/')
                    .removePrefix("$ASSET_PATH/")
                    .ifEmpty { "index.html" }

            val assetPath = "$ASSET_PATH/$normalizedPath"
            val mimeType = normalizedPath.toMimeType()

            return try {
                if (normalizedPath == MICRO_INTERACTIONS_ASSET_PATH) {
                    val baseJson =
                        assetSource.open(assetPath).use { stream ->
                            stream.bufferedReader().use { it.readText() }
                        }
                    val renderedJson = renderMicroInteractions(baseJson)
                    WebResourceResponse(
                        mimeType,
                        Charsets.UTF_8.name(),
                        ByteArrayInputStream(renderedJson.toByteArray(Charsets.UTF_8)),
                    )
                } else {
                    val inputStream = assetSource.open(assetPath)
                    WebResourceResponse(mimeType, null, inputStream)
                }
            } catch (_: FileNotFoundException) {
                null
            }
        }

        private fun String.toMimeType(): String =
            when (substringAfterLast('.', "").lowercase()) {
                "html" -> "text/html"
                "css" -> "text/css"
                "js" -> "application/javascript"
                "json" -> "application/json"
                "wasm" -> "application/wasm"
                "png" -> "image/png"
                "jpg", "jpeg" -> "image/jpeg"
                "ico" -> "image/x-icon"
                "svg" -> "image/svg+xml"
                "ttf" -> "font/ttf"
                "woff" -> "font/woff"
                "woff2" -> "font/woff2"
                "mp4" -> "video/mp4"
                "wgsl" -> "text/plain"
                else -> "application/octet-stream"
            }
    }

    private class ErikAssetSource(
        context: Context,
        directory: File?,
    ) {
        private val assetManager = context.assets
        private val rootDirectory = directory?.canonicalFile

        init {
            if (rootDirectory != null) {
                require(rootDirectory.isDirectory) {
                    "Erik asset directory does not exist: ${rootDirectory.absolutePath}"
                }
            }
        }

        fun open(relativePath: String): InputStream {
            val root = rootDirectory ?: return assetManager.open(relativePath)
            val file = File(root, relativePath).canonicalFile
            val rootPrefix = root.path + File.separator
            if (file.path != root.path && !file.path.startsWith(rootPrefix)) {
                throw FileNotFoundException("Invalid Erik asset path: $relativePath")
            }
            return FileInputStream(file)
        }
    }

    companion object {
        private const val ASSET_PATH = "erik_resources"
        private const val MICRO_INTERACTIONS_ASSET_PATH = "assets/micro-interactions.json"
        private const val ASSET_CONFIG_ASSET_PATH = "asset-config.json"
        private const val INTERIOR_PANORAMA_ASSET_PATH = "interior/panorama_interior_v2.webp"
        private const val JS_BRIDGE_NAME = "ErikNativeBridge"
        private const val ENTRYPOINT_URL = "https://appassets.androidplatform.net/index.html"
        private const val LOG_TAG = "ErikRenderView"
    }
}
