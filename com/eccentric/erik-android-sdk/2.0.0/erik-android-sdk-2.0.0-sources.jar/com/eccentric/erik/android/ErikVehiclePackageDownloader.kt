package com.eccentric.erik.android

import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import java.util.zip.ZipFile

internal val ErikVehiclePackage.cacheKey: String
    get() = downloadUrl

internal class ErikVehiclePackageDownloader(
    private val transport: ErikVehiclePackageTransport = HttpErikVehiclePackageTransport(),
    private val maximumAttempts: Int = 3,
    private val retryDelay: (attempt: Int) -> Unit = { attempt -> Thread.sleep(attempt * 1_000L) },
) {
    fun prepare(
        vehicle: ErikVehiclePackage,
        storageDirectory: File,
        protectedDirectory: File? = null,
        reuseLocalPackage: Boolean = true,
        onState: (ErikVehicleDownloadState) -> Unit,
    ): File {
        require(maximumAttempts > 0) { "Maximum attempts must be greater than zero." }
        validateDescriptor(vehicle)
        storageDirectory.mkdirsOrThrow()
        cleanupPendingArchives(storageDirectory)
        onState(ErikVehicleDownloadState.Checking(vehicle))

        val cachedDirectory =
            if (reuseLocalPackage) {
                findReadyDirectory(storageDirectory, vehicle, protectedDirectory)
            } else {
                null
            }
        val vehicleDirectory =
            cachedDirectory
                ?: if (reuseLocalPackage) {
                    packageDirectory(storageDirectory, vehicle)
                } else {
                    freshPackageDirectory(storageDirectory, vehicle)
                }
        if (reuseLocalPackage) migrateLegacyPackage(storageDirectory, vehicle, vehicleDirectory)
        if (reuseLocalPackage && isReady(vehicleDirectory, vehicle)) {
            cleanupCompletedArchive(storageDirectory, vehicle)
            cleanupInactiveVersions(storageDirectory, vehicle.id, vehicleDirectory, protectedDirectory)
            onState(
                ErikVehicleDownloadState.Ready(
                    vehicle = vehicle,
                    fromCache = true,
                    capabilities = readCapabilities(vehicleDirectory),
                ),
            )
            return vehicleDirectory
        }

        val downloadsDirectory = File(storageDirectory, DOWNLOADS_DIRECTORY).apply { mkdirsOrThrow() }
        val zipFile = File(downloadsDirectory, "${vehicle.id}.zip")
        val zipMetadataFile = zipFile.completedMetadataFile()
        if (zipFile.isFile) {
            if (completedArchiveIsCurrent(zipMetadataFile, vehicle)) {
                try {
                    val directory = extract(vehicle, zipFile, vehicleDirectory, onState)
                    cleanupInactiveVersions(
                        storageDirectory,
                        vehicle.id,
                        directory,
                        protectedDirectory,
                    )
                    return directory
                } catch (error: InterruptedException) {
                    Thread.currentThread().interrupt()
                    throw error
                } catch (_: Exception) {
                    zipFile.delete()
                    zipMetadataFile.delete()
                }
            } else {
                zipFile.delete()
                zipMetadataFile.delete()
            }
        } else {
            zipMetadataFile.delete()
        }

        var lastError: Throwable? = null
        for (attempt in 1..maximumAttempts) {
            try {
                download(vehicle, downloadsDirectory, attempt, onState)
                val directory = extract(vehicle, zipFile, vehicleDirectory, onState)
                cleanupInactiveVersions(
                    storageDirectory,
                    vehicle.id,
                    directory,
                    protectedDirectory,
                )
                return directory
            } catch (error: InterruptedException) {
                Thread.currentThread().interrupt()
                throw error
            } catch (error: Throwable) {
                lastError = error
                if (attempt < maximumAttempts) {
                    onState(
                        ErikVehicleDownloadState.Retrying(
                            vehicle = vehicle,
                            nextAttempt = attempt + 1,
                            maximumAttempts = maximumAttempts,
                            message = error.userMessage(),
                        ),
                    )
                    retryDelay(attempt)
                }
            }
        }

        val failure = IOException(lastError?.userMessage() ?: "Vehicle download failed.", lastError)
        onState(ErikVehicleDownloadState.Failed(vehicle, failure.message.orEmpty()))
        throw failure
    }

    fun isAvailable(
        vehicle: ErikVehiclePackage,
        storageDirectory: File,
    ): Boolean {
        validateDescriptor(vehicle)
        return findReadyDirectory(storageDirectory, vehicle, preferredDirectory = null) != null
    }

    fun isAvailable(
        vehicleId: String,
        storageDirectory: File,
    ): Boolean {
        require(VEHICLE_ID.matches(vehicleId)) { "Vehicle ID contains invalid characters." }
        val vehicleRoot = File(File(storageDirectory, PACKAGES_DIRECTORY), vehicleId)
        return vehicleRoot
            .listFiles()
            .orEmpty()
            .filter(File::isDirectory)
            .any { directory ->
                runCatching {
                    validateExtractedDirectory(directory)
                    check(File(directory, READY_MARKER).readText().isNotBlank())
                    val config =
                        ErikAssetConfig.fromJson(File(directory, ASSET_CONFIG_FILE).readText())
                    config.id == null || config.id == vehicleId
                }.getOrDefault(false)
            }
    }

    private fun download(
        vehicle: ErikVehiclePackage,
        downloadsDirectory: File,
        attempt: Int,
        onState: (ErikVehicleDownloadState) -> Unit,
    ) {
        val partFile = File(downloadsDirectory, "${vehicle.id}.zip.part")
        val metadataFile = File(downloadsDirectory, "${vehicle.id}.zip.part.meta")
        val requestMetadataFile = File(downloadsDirectory, "${vehicle.id}.zip.part.request")
        if (requestMetadataFile.readTextOrNull() != vehicle.cacheKey) {
            partFile.delete()
            metadataFile.delete()
            requestMetadataFile.delete()
        }
        requestMetadataFile.writeText(vehicle.cacheKey)
        var offset = partFile.length().coerceAtLeast(0)
        if (offset > MAX_DOWNLOAD_BYTES) {
            partFile.delete()
            metadataFile.delete()
            requestMetadataFile.delete()
            throw IOException("Saved vehicle ZIP is larger than the allowed download size.")
        }
        val validator = metadataFile.takeIf(File::isFile)?.readText()?.ifBlank { null }
        val response = transport.open(vehicle.downloadUrl, offset, validator)

        response.use {
            val append = response.statusCode == HTTP_PARTIAL
            when {
                response.statusCode == HTTP_RANGE_NOT_SATISFIABLE && response.totalBytes == offset -> Unit
                response.statusCode == HTTP_RANGE_NOT_SATISFIABLE -> {
                    partFile.delete()
                    metadataFile.delete()
                    throw IOException("Saved download offset is no longer valid.")
                }
                response.statusCode == HTTP_OK -> {
                    offset = 0
                    metadataFile.delete()
                }
                response.statusCode == HTTP_PARTIAL && response.rangeStart == offset -> Unit
                response.statusCode == HTTP_PARTIAL -> {
                    partFile.delete()
                    metadataFile.delete()
                    throw IOException("Download server returned an unexpected byte range.")
                }
                else -> throw IOException("Download server returned HTTP ${response.statusCode}.")
            }

            response.validator?.let { metadataFile.writeText(it) } ?: metadataFile.delete()
            val totalBytes = response.totalBytes
            if (totalBytes != null && totalBytes > MAX_DOWNLOAD_BYTES) {
                throw IOException("Vehicle ZIP is larger than the allowed download size.")
            }
            if (response.statusCode != HTTP_RANGE_NOT_SATISFIABLE) {
                FileOutputStream(partFile, append).buffered().use { output ->
                    val buffer = ByteArray(BUFFER_SIZE)
                    var downloaded = offset
                    onState(ErikVehicleDownloadState.Downloading(vehicle, downloaded, totalBytes, attempt))
                    while (true) {
                        if (Thread.currentThread().isInterrupted) throw InterruptedException()
                        val count = response.input.read(buffer)
                        if (count == -1) break
                        output.write(buffer, 0, count)
                        downloaded += count
                        if (downloaded > MAX_DOWNLOAD_BYTES) {
                            throw IOException("Vehicle ZIP is larger than the allowed download size.")
                        }
                        onState(ErikVehicleDownloadState.Downloading(vehicle, downloaded, totalBytes, attempt))
                    }
                }
            }

            if (totalBytes != null && partFile.length() != totalBytes) {
                throw IOException("Download stopped at ${partFile.length()} of $totalBytes bytes.")
            }
        }

        val completedZip = File(downloadsDirectory, "${vehicle.id}.zip")
        val completedMetadata = completedZip.completedMetadataFile()
        if (completedZip.exists() && !completedZip.delete()) {
            throw IOException("Unable to replace the previous vehicle ZIP.")
        }
        completedMetadata.delete()
        if (!partFile.renameTo(completedZip)) {
            throw IOException("Unable to finalize the vehicle ZIP.")
        }
        try {
            completedMetadata.writeText(vehicle.cacheKey)
        } catch (error: Throwable) {
            completedZip.delete()
            throw error
        }
        metadataFile.delete()
        requestMetadataFile.delete()
    }

    private fun extract(
        vehicle: ErikVehiclePackage,
        zipFile: File,
        finalDirectory: File,
        onState: (ErikVehicleDownloadState) -> Unit,
    ): File {
        onState(ErikVehicleDownloadState.Extracting(vehicle))
        finalDirectory.parentFile?.mkdirsOrThrow()
        val stagingDirectory = File(finalDirectory.parentFile, ".${finalDirectory.name}.extracting")
        stagingDirectory.deleteRecursively()
        stagingDirectory.mkdirsOrThrow()

        try {
            var entryCount = 0
            var extractedBytes = 0L
            ZipFile(zipFile).use { archive ->
                val entries = archive.entries()
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    entryCount += 1
                    if (entryCount > MAX_ZIP_ENTRIES) throw IOException("Vehicle ZIP has too many files.")

                    val normalizedName = entry.name.replace('\\', '/')
                    val prefix = "${vehicle.id}/"
                    if (normalizedName == vehicle.id || normalizedName == prefix) continue
                    if (!normalizedName.startsWith(prefix)) {
                        throw IOException("Vehicle ZIP has an unexpected root folder.")
                    }
                    val relativeName = normalizedName.removePrefix(prefix)
                    if (relativeName.isBlank()) continue
                    val target = File(stagingDirectory, relativeName).canonicalFile
                    val stagingPrefix = stagingDirectory.canonicalPath + File.separator
                    if (!target.path.startsWith(stagingPrefix)) {
                        throw IOException("Vehicle ZIP contains an invalid path.")
                    }
                    if (entry.isDirectory) {
                        target.mkdirsOrThrow()
                    } else {
                        target.parentFile?.mkdirsOrThrow()
                        archive.getInputStream(entry).use { input ->
                            target.outputStream().buffered().use { output ->
                                val buffer = ByteArray(BUFFER_SIZE)
                                while (true) {
                                    if (Thread.currentThread().isInterrupted) throw InterruptedException()
                                    val count = input.read(buffer)
                                    if (count == -1) break
                                    output.write(buffer, 0, count)
                                    extractedBytes += count
                                    if (extractedBytes > MAX_EXTRACTED_BYTES) {
                                        throw IOException("Vehicle ZIP is too large after extraction.")
                                    }
                                }
                            }
                        }
                    }
                }
            }

            applyCompatibilityUpdates(vehicle, stagingDirectory)
            validateExtractedDirectory(stagingDirectory)
            File(stagingDirectory, READY_MARKER).writeText(vehicle.cacheKey)
            if (finalDirectory.exists() && !finalDirectory.deleteRecursively()) {
                throw IOException("Unable to replace the incomplete vehicle package revision.")
            }
            if (!stagingDirectory.renameTo(finalDirectory)) {
                throw IOException("Unable to activate the downloaded vehicle.")
            }
            deleteCompletedArchive(zipFile)
            onState(
                ErikVehicleDownloadState.Ready(
                    vehicle = vehicle,
                    fromCache = false,
                    capabilities = readCapabilities(finalDirectory),
                ),
            )
            return finalDirectory
        } catch (error: Throwable) {
            stagingDirectory.deleteRecursively()
            throw error
        }
    }

    private fun isReady(
        directory: File,
        vehicle: ErikVehiclePackage,
    ): Boolean =
        runCatching {
            validateExtractedDirectory(directory)
            val marker = File(directory, READY_MARKER).readText()
            val sourceMatches = marker == vehicle.downloadUrl || marker.startsWith("${vehicle.downloadUrl}#version=")
            sourceMatches
        }.getOrDefault(false)

    private fun completedArchiveIsCurrent(
        metadataFile: File,
        vehicle: ErikVehiclePackage,
    ): Boolean =
        runCatching {
            metadataFile.isFile && metadataFile.readText() == vehicle.cacheKey
        }.getOrDefault(false)

    private fun cleanupCompletedArchive(
        storageDirectory: File,
        vehicle: ErikVehiclePackage,
    ) {
        val zipFile = File(File(storageDirectory, DOWNLOADS_DIRECTORY), "${vehicle.id}.zip")
        deleteCompletedArchive(zipFile)
    }

    private fun File.completedMetadataFile(): File = File(parentFile, "$name.meta")

    private fun File.cleanupMarkerFile(): File = File(parentFile, "$name.cleanup")

    private fun packageDirectory(
        storageDirectory: File,
        vehicle: ErikVehiclePackage,
    ): File {
        val packageKey = cacheFingerprint(vehicle.cacheKey)
        return File(File(File(storageDirectory, PACKAGES_DIRECTORY), vehicle.id), packageKey)
    }

    private fun freshPackageDirectory(
        storageDirectory: File,
        vehicle: ErikVehiclePackage,
    ): File {
        val vehicleRoot = File(File(storageDirectory, PACKAGES_DIRECTORY), vehicle.id)
        val packageKey = "${cacheFingerprint(vehicle.cacheKey)}-${UUID.randomUUID()}"
        return File(vehicleRoot, packageKey)
    }

    private fun cacheFingerprint(value: String): String {
        var fingerprint = FNV_OFFSET_BASIS
        value.toByteArray(Charsets.UTF_8).forEach { byte ->
            fingerprint = fingerprint xor (byte.toLong() and 0xff)
            fingerprint *= FNV_PRIME
        }
        return java.lang.Long.toUnsignedString(fingerprint, 16).padStart(16, '0')
    }

    private fun findReadyDirectory(
        storageDirectory: File,
        vehicle: ErikVehiclePackage,
        preferredDirectory: File?,
    ): File? {
        if (preferredDirectory != null && isReady(preferredDirectory, vehicle)) return preferredDirectory
        val vehicleRoot = File(File(storageDirectory, PACKAGES_DIRECTORY), vehicle.id)
        return vehicleRoot
            .listFiles()
            .orEmpty()
            .filter(File::isDirectory)
            .sortedByDescending(File::lastModified)
            .firstOrNull { isReady(it, vehicle) }
    }

    private fun migrateLegacyPackage(
        storageDirectory: File,
        vehicle: ErikVehiclePackage,
        targetDirectory: File,
    ) {
        val legacyDirectory = File(storageDirectory, vehicle.id)
        val backupDirectory = File(storageDirectory, ".${vehicle.id}.previous")
        if (!isReady(legacyDirectory, vehicle) && isReady(backupDirectory, vehicle)) {
            legacyDirectory.deleteRecursively()
            if (!backupDirectory.renameTo(legacyDirectory)) {
                throw IOException("Unable to restore the previous vehicle package.")
            }
        }
        if (!isReady(legacyDirectory, vehicle)) return
        targetDirectory.parentFile?.mkdirsOrThrow()
        if (isReady(targetDirectory, vehicle)) {
            legacyDirectory.deleteRecursively()
            backupDirectory.deleteRecursively()
            return
        }
        targetDirectory.deleteRecursively()
        if (!legacyDirectory.renameTo(targetDirectory)) {
            throw IOException("Unable to migrate the saved vehicle package.")
        }
        backupDirectory.deleteRecursively()
    }

    private fun cleanupInactiveVersions(
        storageDirectory: File,
        vehicleId: String,
        currentDirectory: File,
        protectedDirectory: File?,
    ) {
        val vehicleRoot = File(File(storageDirectory, PACKAGES_DIRECTORY), vehicleId)
        val protectedPath = protectedDirectory?.canonicalPath
        vehicleRoot.listFiles().orEmpty().forEach { directory ->
            if (
                directory.canonicalPath != currentDirectory.canonicalPath &&
                directory.canonicalPath != protectedPath
            ) {
                directory.deleteRecursively()
            }
        }
    }

    private fun deleteCompletedArchive(zipFile: File) {
        val metadataFile = zipFile.completedMetadataFile()
        val markerFile = zipFile.cleanupMarkerFile()
        if ((zipFile.exists() || metadataFile.exists()) && !markerFile.exists()) {
            markerFile.writeText("pending")
        }
        val zipDeleted = !zipFile.exists() || zipFile.delete()
        val metadataDeleted = !metadataFile.exists() || metadataFile.delete()
        if (zipDeleted && metadataDeleted) {
            markerFile.delete()
        }
    }

    private fun cleanupPendingArchives(storageDirectory: File) {
        val downloadsDirectory = File(storageDirectory, DOWNLOADS_DIRECTORY)
        downloadsDirectory.listFiles { file -> file.name.endsWith(".zip.cleanup") }.orEmpty().forEach { marker ->
            val zipFile = File(marker.parentFile, marker.name.removeSuffix(".cleanup"))
            deleteCompletedArchive(zipFile)
        }
    }

    private fun File.readTextOrNull(): String? =
        runCatching { takeIf(File::isFile)?.readText() }.getOrNull()

    private fun validateDescriptor(vehicle: ErikVehiclePackage) {
        require(VEHICLE_ID.matches(vehicle.id)) { "Vehicle ID contains invalid characters." }
        val protocol = runCatching { URL(vehicle.downloadUrl).protocol }.getOrNull()
        require(protocol == "https") { "Vehicle download URL must use HTTPS." }
    }

    private fun applyCompatibilityUpdates(
        vehicle: ErikVehiclePackage,
        directory: File,
    ) {
        if (vehicle.id != TATA_PUNCH_ID) return

        val projectFile = File(directory, "erik_resources/assets/project.json")
        val controllerFile = File(directory, "erik_resources/erik-controller.js")
        if (!projectFile.readText().contains("\"$PUNCH_INTRO_CLIP\"")) {
            throw IOException("Punch package is missing its intro camera clip.")
        }
        val controller = controllerFile.readText()
        val updatedController =
            EMPTY_STARTUP_CLIPS.replace(controller) {
                "const STARTUP_CAMERA_CLIPS = [\n    \"$PUNCH_INTRO_CLIP\",\n];"
            }
        if (updatedController == controller && !controller.contains("\"$PUNCH_INTRO_CLIP\"")) {
            throw IOException("Punch package startup camera configuration is invalid.")
        }
        if (updatedController != controller) controllerFile.writeText(updatedController)
    }

    private fun validateExtractedDirectory(directory: File) {
        REQUIRED_FILES.forEach { relativePath ->
            if (!File(directory, relativePath).isFile) {
                throw IOException("Vehicle package is missing $relativePath.")
            }
        }
    }

    private fun readCapabilities(directory: File): ErikVehicleCapabilities {
        val interactions = File(directory, MICRO_INTERACTIONS_PATH).readText()
        return ErikVehicleCapabilities.detectFromMicroInteractions(interactions)
    }

    private fun File.mkdirsOrThrow() {
        if (!isDirectory && !mkdirs()) throw IOException("Unable to create $absolutePath.")
    }

    private fun Throwable.userMessage(): String = message?.takeIf(String::isNotBlank) ?: "Vehicle download failed."

    companion object {
        private const val FNV_OFFSET_BASIS = -3750763034362895579L
        private const val FNV_PRIME = 1099511628211L
        private const val DOWNLOADS_DIRECTORY = "downloads"
        private const val PACKAGES_DIRECTORY = "packages"
        private const val ASSET_CONFIG_FILE = "asset-config.json"
        private const val READY_MARKER = ".ready"
        private const val BUFFER_SIZE = 64 * 1024
        private const val MAX_ZIP_ENTRIES = 10_000
        private const val MAX_EXTRACTED_BYTES = 1_000_000_000L
        private const val MAX_DOWNLOAD_BYTES = 1_000_000_000L
        private const val HTTP_OK = 200
        private const val HTTP_PARTIAL = 206
        private const val HTTP_RANGE_NOT_SATISFIABLE = 416
        private const val PUNCH_INTRO_CLIP = "camera_fade_out_in"
        private const val TATA_PUNCH_ID = "tata-punch"
        private const val MICRO_INTERACTIONS_PATH = "erik_resources/assets/micro-interactions.json"
        private val VEHICLE_ID = Regex("[a-z0-9][a-z0-9-]*")
        private val EMPTY_STARTUP_CLIPS =
            Regex("const\\s+STARTUP_CAMERA_CLIPS\\s*=\\s*\\[\\s*];")
        private val REQUIRED_FILES =
            listOf(
                "asset-config.json",
                "erik_resources/index.html",
                "erik_resources/erik-controller.js",
                "erik_resources/erik_player.js",
                "erik_resources/erik_player.wasm",
                "erik_resources/assets/project.json",
                "erik_resources/assets/micro-interactions.json",
                "interior/panorama_interior_v2.webp",
            )
    }
}

internal interface ErikVehiclePackageTransport {
    fun open(
        url: String,
        offset: Long,
        validator: String?,
    ): ErikVehiclePackageResponse
}

internal class ErikVehiclePackageResponse(
    val statusCode: Int,
    val totalBytes: Long?,
    val rangeStart: Long? = null,
    val validator: String?,
    val input: InputStream,
    private val closeAction: () -> Unit = {},
) : AutoCloseable {
    override fun close() {
        runCatching { input.close() }
        closeAction()
    }
}

private class HttpErikVehiclePackageTransport : ErikVehiclePackageTransport {
    override fun open(
        url: String,
        offset: Long,
        validator: String?,
    ): ErikVehiclePackageResponse {
        val connection = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = CONNECT_TIMEOUT_MS
            readTimeout = READ_TIMEOUT_MS
            instanceFollowRedirects = true
            setRequestProperty("Accept-Encoding", "identity")
            if (offset > 0) {
                setRequestProperty("Range", "bytes=$offset-")
                validator?.let { setRequestProperty("If-Range", it) }
            }
        }
        val status = connection.responseCode
        if (connection.url.protocol != "https") {
            connection.disconnect()
            throw IOException("Vehicle download redirected to an insecure URL.")
        }
        val contentRange = connection.getHeaderField("Content-Range")
        val totalBytes =
            contentRange
                ?.substringAfterLast('/')
                ?.toLongOrNull()
                ?: connection.contentLengthLong.takeIf { it >= 0 }
        val rangeStart =
            contentRange
                ?.substringAfter(' ')
                ?.substringBefore('-')
                ?.toLongOrNull()
        val input =
            if (status == HttpURLConnection.HTTP_OK || status == HttpURLConnection.HTTP_PARTIAL) {
                connection.inputStream
            } else {
                ByteArrayInputStream(ByteArray(0))
            }
        return ErikVehiclePackageResponse(
            statusCode = status,
            totalBytes = totalBytes,
            rangeStart = rangeStart,
            validator = connection.getHeaderField("ETag") ?: connection.getHeaderField("Last-Modified"),
            input = input,
            closeAction = connection::disconnect,
        )
    }

    companion object {
        private const val CONNECT_TIMEOUT_MS = 15_000
        private const val READ_TIMEOUT_MS = 30_000
    }
}
