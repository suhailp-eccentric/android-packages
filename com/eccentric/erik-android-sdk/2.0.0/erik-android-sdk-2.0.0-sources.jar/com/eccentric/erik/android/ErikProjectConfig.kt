package com.eccentric.erik.android

internal object ErikProjectConfig {
    private val taaEnabledPattern =
        Regex("""("taa"\s*:\s*\{\s*"on"\s*:\s*)true""")
    private val fxaaDisabledPattern =
        Regex("""("fxaa"\s*:\s*\{\s*"on"\s*:\s*)false""")

    fun renderForAndroidWebView(baseJson: String): String =

        baseJson
            .replaceFirst(taaEnabledPattern, "$1false")
            .replaceFirst(fxaaDisabledPattern, "$1true")
//            .replaceNumber("scale", "0.2")
//            .replaceNumber("threshold", "0.85")
//            .replaceNumber("num_layers", "2")
//            .replaceNumber("num_samples", "8")
//            .replaceNumber("radius_layer_0", "0.008")
//            .replaceNumber("radius_layer_1", "0.03")
//            .replaceNumber("radius_layer_2", "0")
//            .replaceNumber("intensity_layer_0", "0.005")
//            .replaceNumber("intensity_layer_1", "0.012")
//            .replaceNumber("intensity_layer_2", "0")

    private fun String.replaceNumber(
        key: String,
        value: String,
    ): String {
        val pattern = Regex("""("${Regex.escape(key)}"\s*:\s*)-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?""")
        val matchResult = pattern.find(this) ?: return this
        return replaceRange(matchResult.range, "${matchResult.groupValues[1]}$value")
    }
}
