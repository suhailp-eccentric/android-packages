package com.eccentric.erik.android

internal interface ErikPendingCallback {
    fun onSuccess(value: String)

    fun onError(message: String)
}

internal fun ErikCommandCallback.toPendingCallback(): ErikPendingCallback =
    object : ErikPendingCallback {
        override fun onSuccess(value: String) {
            this@toPendingCallback.onSuccess()
        }

        override fun onError(message: String) {
            this@toPendingCallback.onError(message)
        }
    }

internal fun ErikJsonCallback.toPendingCallback(): ErikPendingCallback =
    object : ErikPendingCallback {
        override fun onSuccess(value: String) {
            this@toPendingCallback.onSuccess(value)
        }

        override fun onError(message: String) {
            this@toPendingCallback.onError(message)
        }
    }
