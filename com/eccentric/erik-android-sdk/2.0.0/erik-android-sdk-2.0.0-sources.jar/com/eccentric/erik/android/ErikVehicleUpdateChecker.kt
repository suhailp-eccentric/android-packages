package com.eccentric.erik.android

import java.io.File
import java.net.HttpURLConnection
import java.net.URI
import org.json.JSONObject

internal class ErikVehicleUpdateChecker(
    private val catalogTransport: ErikVehicleCatalogTransport = HttpErikVehicleCatalogTransport(),
    private val catalogUrl: String,
) {
    fun check(
        storageDirectory: File,
        vehicleId: String,
    ): ErikVehicleUpdateInfo {
        require(VEHICLE_ID.matches(vehicleId)) { "Vehicle ID contains invalid characters." }
        val catalog = JSONObject(catalogTransport.load(catalogUrl))
        require(catalog.optInt("schemaVersion", -1) == CATALOG_SCHEMA_VERSION) {
            "Unsupported vehicle catalog schema version."
        }
        val latestVersion =
            catalog
                .optJSONObject("vehicles")
                ?.optJSONObject(vehicleId)
                ?.optString("version")
                ?.takeIf(String::isNotBlank)
            ?: error("Vehicle '$vehicleId' was not found in the catalog.")
        val latest = SemanticVersion.parse(latestVersion)
        val installedVersion = installedVersion(storageDirectory, vehicleId)
        val installed = installedVersion?.let(SemanticVersion::parse)
        return ErikVehicleUpdateInfo(
            vehicleId = vehicleId,
            installedVersion = installedVersion,
            latestVersion = latestVersion,
            updateAvailable = installed == null || latest > installed,
            latestPackage =
                ErikVehiclePackage(
                    id = vehicleId,
                    downloadUrl = URI(catalogUrl).resolve("$vehicleId.zip").toString(),
                ),
        )
    }

    private fun installedVersion(
        storageDirectory: File,
        vehicleId: String,
    ): String? {
        val vehicleRoot = File(File(storageDirectory, PACKAGES_DIRECTORY), vehicleId)
        return vehicleRoot
            .listFiles()
            .orEmpty()
            .asSequence()
            .filter(File::isDirectory)
            .filter { directory -> File(directory, READY_MARKER).isFile }
            .mapNotNull { directory ->
                runCatching {
                    val config =
                        ErikAssetConfig.fromJson(
                            File(directory, ASSET_CONFIG_FILE).readText(),
                        )
                    config.version?.takeIf { config.id == null || config.id == vehicleId }
                }.getOrNull()
            }
            .maxWithOrNull { first, second ->
                SemanticVersion.parse(first).compareTo(SemanticVersion.parse(second))
            }
    }

    companion object {
        private const val CATALOG_SCHEMA_VERSION = 1
        private const val PACKAGES_DIRECTORY = "packages"
        private const val ASSET_CONFIG_FILE = "asset-config.json"
        private const val READY_MARKER = ".ready"
        private val VEHICLE_ID = Regex("[a-z0-9][a-z0-9-]*")
    }
}

internal fun interface ErikVehicleCatalogTransport {
    fun load(url: String): String
}

private class HttpErikVehicleCatalogTransport : ErikVehicleCatalogTransport {
    override fun load(url: String): String {
        val uri = URI(url)
        require(uri.scheme.equals("https", ignoreCase = true)) {
            "Vehicle catalog URL must use HTTPS."
        }
        val connection = uri.toURL().openConnection() as HttpURLConnection
        connection.connectTimeout = TIMEOUT_MS
        connection.readTimeout = TIMEOUT_MS
        connection.instanceFollowRedirects = false
        connection.requestMethod = "GET"
        return try {
            require(connection.responseCode == HttpURLConnection.HTTP_OK) {
                "Vehicle catalog request failed with HTTP ${connection.responseCode}."
            }
            connection.inputStream.bufferedReader().use { reader ->
                val catalog = reader.readText()
                require(catalog.toByteArray().size <= MAX_CATALOG_BYTES) {
                    "Vehicle catalog is too large."
                }
                catalog
            }
        } finally {
            connection.disconnect()
        }
    }

    companion object {
        private const val TIMEOUT_MS = 15_000
        private const val MAX_CATALOG_BYTES = 1_000_000
    }
}

private data class SemanticVersion(
    val major: Int,
    val minor: Int,
    val patch: Int,
) : Comparable<SemanticVersion> {
    override fun compareTo(other: SemanticVersion): Int =
        compareValuesBy(this, other, SemanticVersion::major, SemanticVersion::minor, SemanticVersion::patch)

    companion object {
        fun parse(value: String): SemanticVersion {
            val match = VERSION.matchEntire(value)
                ?: error("Vehicle version '$value' must use major.minor.patch format.")
            return SemanticVersion(
                major = match.groupValues[1].toInt(),
                minor = match.groupValues[2].toInt(),
                patch = match.groupValues[3].toInt(),
            )
        }

        private val VERSION = Regex("(0|[1-9]\\d*)\\.(0|[1-9]\\d*)\\.(0|[1-9]\\d*)")
    }
}
