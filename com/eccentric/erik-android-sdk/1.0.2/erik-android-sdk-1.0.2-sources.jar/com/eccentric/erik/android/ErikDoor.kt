package com.eccentric.erik.android

enum class ErikDoor(
    val jsName: String,
) {
    FRONT_LEFT("FL_DOOR"),
    FRONT_RIGHT("FR_DOOR"),
    REAR_LEFT("RL_DOOR"),
    REAR_RIGHT("RR_DOOR"),
    BOOT("TAILGATE"),
    SUNROOF("SUNROOF"),
    FRONT_LEFT_ORVM("FL_DOOR_ORVM"),
    FRONT_RIGHT_ORVM("FR_DOOR_ORVM"),
    ;

    internal val openDirection: String
        get() =
            when (this) {
                FRONT_LEFT_ORVM,
                FRONT_RIGHT_ORVM,
                -> "reverse"

                else -> "forward"
            }

    internal val closeDirection: String
        get() = if (openDirection == "forward") "reverse" else "forward"
}
