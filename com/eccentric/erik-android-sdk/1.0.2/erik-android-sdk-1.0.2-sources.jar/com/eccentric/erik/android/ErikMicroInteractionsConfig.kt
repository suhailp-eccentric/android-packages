package com.eccentric.erik.android

internal class ErikMicroInteractionsConfig {
    private var overrides = ErikState()

    @Synchronized
    fun apply(next: ErikState) {
        overrides = overrides.merge(next)
    }

    @Synchronized
    fun render(baseJson: String): String {
        val base = MicroInteractions.from(baseJson)
        val applied = base.apply(overrides)
        return applied.toJson()
    }

    private fun ErikState.merge(next: ErikState): ErikState =
        ErikState(
            startupCameraAnimation = next.startupCameraAnimation ?: startupCameraAnimation,
            background =
                when {
                    background == null -> next.background
                    next.background == null -> background
                    else ->
                        ErikBackgroundState(
                            transparent = next.background.transparent ?: background.transparent,
                            color = next.background.color ?: background.color,
                        )
                },
            carpaint = next.carpaint ?: carpaint,
            lightsOn = next.lightsOn ?: lightsOn,
            doorStates = mergeDoorStates(doorStates, next.doorStates),
            lightStates = mergeLightStates(lightStates, next.lightStates),
            lightBlinkInterval = next.lightBlinkInterval ?: lightBlinkInterval,
            cameraAngle = next.cameraAngle ?: cameraAngle,
            rotationSpeed = next.rotationSpeed ?: rotationSpeed,
        )

    private fun mergeDoorStates(
        current: Map<ErikDoor, Boolean>?,
        next: Map<ErikDoor, Boolean>?,
    ): Map<ErikDoor, Boolean>? {
        if (current == null) {
            return next
        }
        if (next == null) {
            return current
        }
        return current + next
    }

    private fun mergeLightStates(
        current: Map<ErikLight, ErikLightState>?,
        next: Map<ErikLight, ErikLightState>?,
    ): Map<ErikLight, ErikLightState>? {
        if (current == null) return next
        if (next == null) return current
        return current + next
    }

    private data class MicroInteractions(
        val initLoad: Boolean,
        val showLoader: Boolean,
        val startupCameraAnimation: Boolean,
        val background: Background,
        val carpaint: String,
        val lightsOn: Boolean,
        val doorStates: Map<ErikDoor, Boolean>,
        val lightStates: Map<ErikLight, ErikLightState>,
        val lightBlinkInterval: Double,
        val cameraAngle: CameraAngle?,
        val rotationSpeed: Double,
    ) {
        fun apply(overrides: ErikState): MicroInteractions =
            copy(
                startupCameraAnimation = overrides.startupCameraAnimation ?: startupCameraAnimation,
                background =
                    background.copy(
                        transparent = overrides.background?.transparent ?: background.transparent,
                        color = overrides.background?.color ?: background.color,
                    ),
                carpaint = overrides.carpaint ?: carpaint,
                lightsOn = overrides.lightsOn ?: lightsOn,
                doorStates = doorStates + overrides.doorStates.orEmpty(),
                lightStates = lightStates + overrides.lightStates.orEmpty(),
                lightBlinkInterval = overrides.lightBlinkInterval ?: lightBlinkInterval,
                cameraAngle = cameraAngle.withOverride(overrides.cameraAngle),
                rotationSpeed = overrides.rotationSpeed ?: rotationSpeed,
            )

        fun toJson(): String =
            buildJsonObject {
                put("initLoad", initLoad)
                put("showLoader", showLoader)
                put("startupCameraAnimation", startupCameraAnimation)
                putRaw(
                    "background",
                    buildJsonObject {
                        put("transparent", background.transparent)
                        put("color", background.color)
                    },
                )
                put("carpaint", carpaint)
                put("lightsOn", lightsOn)
                putRaw(
                    "doorStates",
                    buildJsonObject {
                        DOOR_ORDER.forEach { door ->
                            put(door.jsName, doorStates[door] ?: false)
                        }
                    },
                )
                putRaw(
                    "lightStates",
                    buildJsonObject {
                        LIGHT_ORDER.forEach { light ->
                            putRaw(light.jsName, (lightStates[light] ?: ErikLightState.OFF).jsValue)
                        }
                    },
                )
                putNumber("lightBlinkInterval", lightBlinkInterval)
                putNumber("rotationSpeed", rotationSpeed)
                putRaw("cameraAngle", cameraAngle?.toJson() ?: "null")
            }

        companion object {
            fun from(json: String): MicroInteractions {
                val backgroundJson = json.extractObject("background")
                val doorStatesJson = json.extractObject("doorStates")
                val lightStatesJson = json.extractObject("lightStates")
                val cameraJson = json.extractObject("cameraAngle")

                return MicroInteractions(
                    initLoad = json.booleanValue("initLoad", true),
                    showLoader = json.booleanValue("showLoader", false),
                    startupCameraAnimation = json.booleanValue("startupCameraAnimation", false),
                    background =
                        Background(
                            transparent = backgroundJson.booleanValue("transparent", false),
                            color = backgroundJson.stringValue("color", "#1a2b3c"),
                        ),
                    carpaint = json.stringValue("carpaint", "Andaman_Adventure"),
                    lightsOn = json.booleanValue("lightsOn", false),
                    doorStates =
                        DOOR_ORDER.associateWith { door ->
                            doorStatesJson.booleanValue(door.jsName, false)
                        },
                    lightStates =
                        LIGHT_ORDER.associateWith { light ->
                            lightStatesJson.lightStateValue(light.jsName, ErikLightState.OFF)
                        },
                    lightBlinkInterval = json.numberValue("lightBlinkInterval") ?: 0.25,
                    cameraAngle =
                        CameraAngle(
                            azimuth = cameraJson.numberValue("azimuth"),
                            elevation = cameraJson.numberValue("elevation"),
                            radius = cameraJson.numberValue("radius"),
                            focalLength = cameraJson.numberValue("focalLength"),
                        ).takeIf { it.hasCompleteOrbit() },
                    rotationSpeed = json.numberValue("rotationSpeed") ?: 2.0,
                )
            }
        }
    }

    private data class Background(
        val transparent: Boolean,
        val color: String,
    )

    private data class CameraAngle(
        val azimuth: Double?,
        val elevation: Double?,
        val radius: Double?,
        val focalLength: Double?,
    ) {
        fun hasCompleteOrbit(): Boolean = azimuth != null && elevation != null && radius != null

        fun toJson(): String =
            buildJsonObject {
                putNumberOrNull("azimuth", azimuth)
                putNumberOrNull("elevation", elevation)
                putNumberOrNull("radius", radius)
                putNumberOrNull("focalLength", focalLength)
            }
    }

    private class JsonObjectBuilder {
        private val entries = mutableListOf<String>()

        fun put(
            key: String,
            value: Boolean,
        ) {
            putRaw(key, value.toString())
        }

        fun put(
            key: String,
            value: String,
        ) {
            putRaw(key, "\"${value.escapeJsonString()}\"")
        }

        fun putNumberOrNull(
            key: String,
            value: Double?,
        ) {
            putRaw(key, value?.toString() ?: "null")
        }

        fun putNumber(
            key: String,
            value: Double,
        ) {
            putRaw(key, value.toString())
        }

        fun putRaw(
            key: String,
            value: String,
        ) {
            entries += "\"${key.escapeJsonString()}\":$value"
        }

        fun build(): String = entries.joinToString(separator = ",", prefix = "{", postfix = "}")
    }

    private companion object {
        private val DOOR_ORDER =
            listOf(
                ErikDoor.FRONT_LEFT,
                ErikDoor.FRONT_RIGHT,
                ErikDoor.REAR_LEFT,
                ErikDoor.REAR_RIGHT,
                ErikDoor.BOOT,
                ErikDoor.SUNROOF,
                ErikDoor.FRONT_LEFT_ORVM,
                ErikDoor.FRONT_RIGHT_ORVM,
            )

        private val LIGHT_ORDER = ErikLight.entries

        private fun buildJsonObject(block: JsonObjectBuilder.() -> Unit): String =
            JsonObjectBuilder().apply(block).build()

        private fun CameraAngle?.withOverride(override: ErikCameraAngle?): CameraAngle? {
            if (override == null) {
                return this
            }

            return CameraAngle(
                azimuth = override.azimuth ?: this?.azimuth,
                elevation = override.elevation ?: this?.elevation,
                radius = override.radius ?: this?.radius,
                focalLength = override.focalLength ?: this?.focalLength,
            ).takeIf { it.hasCompleteOrbit() }
        }

        private fun String.extractObject(key: String): String {
            val keyIndex = indexOf("\"$key\"")
            if (keyIndex == -1) {
                return "{}"
            }

            val start = indexOf('{', keyIndex)
            if (start == -1) {
                return "{}"
            }

            var depth = 0
            for (index in start until length) {
                when (this[index]) {
                    '{' -> depth += 1
                    '}' -> {
                        depth -= 1
                        if (depth == 0) {
                            return substring(start, index + 1)
                        }
                    }
                }
            }
            return "{}"
        }

        private fun String.booleanValue(
            key: String,
            fallback: Boolean,
        ): Boolean =
            Regex("\"${Regex.escape(key)}\"\\s*:\\s*(true|false)")
                .find(this)
                ?.groupValues
                ?.get(1)
                ?.toBooleanStrictOrNull()
                ?: fallback

        private fun String.stringValue(
            key: String,
            fallback: String,
        ): String =
            Regex("\"${Regex.escape(key)}\"\\s*:\\s*\"((?:\\\\.|[^\"])*)\"")
                .find(this)
                ?.groupValues
                ?.get(1)
                ?.unescapeJsonString()
                ?: fallback

        private fun String.numberValue(key: String): Double? {
            val value =
                Regex("\"${Regex.escape(key)}\"\\s*:\\s*(-?\\d+(?:\\.\\d+)?|null)")
                    .find(this)
                    ?.groupValues
                    ?.get(1)
                    ?: return null
            return if (value == "null") null else value.toDoubleOrNull()
        }

        private fun String.lightStateValue(
            key: String,
            fallback: ErikLightState,
        ): ErikLightState {
            val value =
                Regex("\"${Regex.escape(key)}\"\\s*:\\s*(true|false|\"blink\")")
                    .find(this)
                    ?.groupValues
                    ?.get(1)
                    ?: return fallback
            return when (value) {
                "true" -> ErikLightState.ON
                "false" -> ErikLightState.OFF
                "\"blink\"" -> ErikLightState.BLINK
                else -> fallback
            }
        }

        private fun String.escapeJsonString(): String =
            buildString {
                this@escapeJsonString.forEach { char ->
                    when (char) {
                        '\\' -> append("\\\\")
                        '"' -> append("\\\"")
                        '\n' -> append("\\n")
                        '\r' -> append("\\r")
                        else -> append(char)
                    }
                }
            }

        private fun String.unescapeJsonString(): String =
            replace("\\\"", "\"")
                .replace("\\\\", "\\")
                .replace("\\n", "\n")
                .replace("\\r", "\r")
    }
}
