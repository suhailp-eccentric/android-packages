package com.eccentric.erik.android

import android.content.Context
import android.os.Handler
import android.os.Looper
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.atomic.AtomicBoolean

/** Selects where the Erik renderer is hosted by the full SDK. */
enum class ErikHostingMode {
    /** Renders directly in the client process for compatibility. */
    LOCAL,

    /** Keeps one renderer session in the SDK's private `:erik_runtime` process. */
    SERVICE,
}

data class ErikSdkConfig @JvmOverloads constructor(
    val hostingMode: ErikHostingMode = ErikHostingMode.LOCAL,
)

/** Application-wide configuration for the full Erik SDK. */
object ErikSdk {
    @Volatile
    private var config = ErikSdkConfig()

    @Volatile
    private var assetDirectory: File? = null

    private val vehicleExecutor = Executors.newSingleThreadExecutor()
    private val vehicleLock = Any()
    private var activeVehicleOperation: VehicleDownloadOperationImpl? = null
    private val mainHandler by lazy { Handler(Looper.getMainLooper()) }

    /**
     * Configures fragments created after this call.
     *
     * Call this from `Application.onCreate()` before creating an [ErikFragment].
     */
    @JvmStatic
    fun configure(config: ErikSdkConfig) {
        this.config = config
    }

    @JvmStatic
    fun currentConfig(): ErikSdkConfig = config

    /** Downloads, validates, and activates one vehicle package. */
    @JvmStatic
    fun prepareVehicle(
        context: Context,
        vehicle: ErikVehiclePackage,
        listener: ErikVehicleDownloadListener,
    ): ErikVehicleDownloadOperation =
        startVehiclePreparation(
            context = context,
            vehicle = vehicle,
            listener = listener,
            reuseLocalPackage = true,
        )

    /** Downloads a fresh copy and activates it, even when this vehicle exists locally. */
    @JvmStatic
    fun downloadVehicle(
        context: Context,
        vehicle: ErikVehiclePackage,
        listener: ErikVehicleDownloadListener,
    ): ErikVehicleDownloadOperation =
        startVehiclePreparation(
            context = context,
            vehicle = vehicle,
            listener = listener,
            reuseLocalPackage = false,
        )

    /** Returns true when a valid package for this vehicle ID and URL exists locally. */
    @JvmStatic
    fun isVehicleAvailableLocally(
        context: Context,
        vehicle: ErikVehiclePackage,
    ): Boolean =
        runCatching {
            ErikVehiclePackageDownloader().isAvailable(
                vehicle = vehicle,
                storageDirectory = packageStorageDirectory(context.applicationContext),
            )
        }.getOrDefault(false)

    /** Returns true when a valid package for this vehicle ID exists locally. */
    @JvmStatic
    fun isVehicleAvailableLocally(
        context: Context,
        vehicleId: String,
    ): Boolean =
        runCatching {
            ErikVehiclePackageDownloader().isAvailable(
                vehicleId = vehicleId,
                storageDirectory = packageStorageDirectory(context.applicationContext),
            )
        }.getOrDefault(false)

    /** Checks a client-hosted vehicle catalog for a newer package version. */
    @JvmStatic
    fun checkForVehicleUpdate(
        context: Context,
        vehicleId: String,
        catalogUrl: String,
        callback: ErikVehicleUpdateCallback,
    ) {
        val applicationContext = context.applicationContext
        vehicleExecutor.execute {
            runCatching {
                ErikVehicleUpdateChecker(catalogUrl = catalogUrl).check(
                    storageDirectory = packageStorageDirectory(applicationContext),
                    vehicleId = vehicleId,
                )
            }.onSuccess { update ->
                mainHandler.post { callback.onSuccess(update) }
            }.onFailure { error ->
                val message =
                    error.message?.takeIf(String::isNotBlank)
                        ?: "Unable to check for a vehicle update."
                mainHandler.post { callback.onError(message) }
            }
        }
    }

    private fun startVehiclePreparation(
        context: Context,
        vehicle: ErikVehiclePackage,
        listener: ErikVehicleDownloadListener,
        reuseLocalPackage: Boolean,
    ): ErikVehicleDownloadOperation {
        val operation = VehicleDownloadOperationImpl()
        operation.setCancelAction {
            clearVehicleOperation(operation)
            dispatchVehicleState(listener, ErikVehicleDownloadState.Cancelled(vehicle))
        }
        synchronized(vehicleLock) {
            if (activeVehicleOperation != null) {
                operation.complete()
                dispatchVehicleState(
                    listener,
                    ErikVehicleDownloadState.Failed(vehicle, "Another vehicle download is active."),
                )
                return operation
            }
            activeVehicleOperation = operation
        }

        val applicationContext = context.applicationContext
        operation.setFuture(
            vehicleExecutor.submit {
                var terminalStateSent = false
                var readyState: ErikVehicleDownloadState.Ready? = null
                try {
                    val directory =
                        ErikVehiclePackageDownloader().prepare(
                            vehicle = vehicle,
                            storageDirectory = packageStorageDirectory(applicationContext),
                            onState = { state ->
                                if (!operation.isCancelled) {
                                    when (state) {
                                        is ErikVehicleDownloadState.Ready -> readyState = state
                                        is ErikVehicleDownloadState.Failed -> {
                                            terminalStateSent = true
                                            operation.complete()
                                            clearVehicleOperation(operation)
                                            dispatchVehicleState(listener, state)
                                        }
                                        else -> dispatchVehicleState(listener, state)
                                    }
                                }
                            },
                            protectedDirectory = assetDirectory,
                            reuseLocalPackage = reuseLocalPackage,
                        )
                    if (!operation.isCancelled) {
                        assetDirectory = directory
                        operation.complete()
                        clearVehicleOperation(operation)
                        dispatchVehicleState(listener, checkNotNull(readyState))
                    }
                } catch (_: InterruptedException) {
                    Thread.currentThread().interrupt()
                } catch (error: Throwable) {
                    if (!terminalStateSent && !operation.isCancelled) {
                        operation.complete()
                        clearVehicleOperation(operation)
                        dispatchVehicleState(
                            listener,
                            ErikVehicleDownloadState.Failed(
                                vehicle,
                                error.message?.takeIf(String::isNotBlank) ?: "Vehicle download failed.",
                            ),
                        )
                    }
                } finally {
                    clearVehicleOperation(operation)
                }
            },
        )
        return operation
    }

    internal fun currentAssetDirectory(): File? = assetDirectory

    private fun packageStorageDirectory(context: Context): File =
        context.applicationContext.filesDir.resolve(ASSET_DIRECTORY)

    private fun dispatchVehicleState(
        listener: ErikVehicleDownloadListener,
        state: ErikVehicleDownloadState,
    ) {
        mainHandler.post { listener.onStateChanged(state) }
    }

    private fun clearVehicleOperation(operation: VehicleDownloadOperationImpl) {
        synchronized(vehicleLock) {
            if (activeVehicleOperation === operation) activeVehicleOperation = null
        }
    }

    private const val ASSET_DIRECTORY = "ecc-erik"

    private class VehicleDownloadOperationImpl : ErikVehicleDownloadOperation {
        @Volatile
        private var future: Future<*>? = null

        private val finished = AtomicBoolean(false)

        @Volatile
        private var cancelAction: (() -> Unit)? = null

        @Volatile
        var isCancelled = false
            private set

        fun setFuture(future: Future<*>) {
            this.future = future
            if (isCancelled) future.cancel(true)
        }

        fun setCancelAction(action: () -> Unit) {
            cancelAction = action
            if (isCancelled) action()
        }

        fun complete() {
            finished.compareAndSet(false, true)
        }

        override fun cancel() {
            if (!finished.compareAndSet(false, true)) return
            isCancelled = true
            future?.cancel(true)
            cancelAction?.invoke()
        }
    }
}
