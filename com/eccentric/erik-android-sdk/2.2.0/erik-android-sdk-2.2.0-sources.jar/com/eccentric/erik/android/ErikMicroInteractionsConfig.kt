package com.eccentric.erik.android

import org.json.JSONObject

internal class ErikMicroInteractionsConfig {
    private var overrides = ErikState()

    @Synchronized
    fun apply(next: ErikState) {
        overrides = overrides.mergedWith(next)
    }

    @Synchronized
    fun render(baseJson: String): String =
        JSONObject(baseJson).apply {
            put("initLoad", booleanValue("initLoad") ?: true)
            put("showLoader", booleanValue("showLoader") ?: false)
            put(
                "startupCameraAnimation",
                overrides.startupCameraAnimation ?: booleanValue("startupCameraAnimation") ?: false,
            )
            put("carpaint", overrides.carpaint ?: stringValue("carpaint") ?: "Andaman_Adventure")
            put("lightsOn", overrides.lightsOn ?: booleanValue("lightsOn") ?: false)
            put(
                "lightBlinkInterval",
                overrides.lightBlinkInterval ?: numberValue("lightBlinkInterval") ?: 0.25,
            )
            put("rotationSpeed", overrides.rotationSpeed ?: numberValue("rotationSpeed") ?: 2.0)
            applyBackground()
            applyDoors()
            applyLights()
            applyCamera()
        }.toString()

    private fun JSONObject.applyBackground() {
        val background = optJSONObject("background") ?: JSONObject()
        background.put(
            "transparent",
            overrides.background?.transparent ?: background.booleanValue("transparent") ?: false,
        )
        background.put(
            "color",
            overrides.background?.color ?: background.stringValue("color") ?: "#1a2b3c",
        )
        put("background", background)
    }

    private fun JSONObject.applyDoors() {
        val doors = optJSONObject("doorStates") ?: JSONObject()
        ErikDoor.entries.forEach { door ->
            doors.put(
                door.jsName,
                overrides.doorStates?.get(door) ?: doors.booleanValue(door.jsName) ?: false,
            )
        }
        put("doorStates", doors)
    }

    private fun JSONObject.applyLights() {
        val lights = optJSONObject("lightStates") ?: JSONObject()
        ErikLight.entries.forEach { light ->
            val state =
                overrides.lightStates?.get(light)
                    ?: lights.lightStateValue(light.jsName)
                    ?: ErikLightState.OFF
            lights.put(light.jsName, state.toJsonValue())
        }
        put("lightStates", lights)
    }

    private fun JSONObject.applyCamera() {
        val camera = optJSONObject("cameraAngle")
        val merged =
            ErikCameraAngle(
                azimuth = overrides.cameraAngle?.azimuth ?: camera?.numberValue("azimuth"),
                elevation = overrides.cameraAngle?.elevation ?: camera?.numberValue("elevation"),
                radius = overrides.cameraAngle?.radius ?: camera?.numberValue("radius"),
                focalLength = overrides.cameraAngle?.focalLength ?: camera?.numberValue("focalLength"),
            ).takeIf(ErikCameraAngle::hasCompleteOrbit)
        put("cameraAngle", merged?.toJsonObject() ?: JSONObject.NULL)
    }

    private fun JSONObject.lightStateValue(key: String): ErikLightState? =
        when (opt(key)) {
            true -> ErikLightState.ON
            false -> ErikLightState.OFF
            "blink" -> ErikLightState.BLINK
            else -> null
        }

    private fun JSONObject.stringValue(key: String): String? = opt(key) as? String

    private fun JSONObject.booleanValue(key: String): Boolean? = opt(key) as? Boolean

    private fun JSONObject.numberValue(key: String): Double? = (opt(key) as? Number)?.toDouble()

    private fun ErikCameraAngle.toJsonObject(): JSONObject =
        JSONObject()
            .put("azimuth", azimuth ?: JSONObject.NULL)
            .put("elevation", elevation ?: JSONObject.NULL)
            .put("radius", radius ?: JSONObject.NULL)
            .put("focalLength", focalLength ?: JSONObject.NULL)

    private fun ErikLightState.toJsonValue(): Any =
        when (this) {
            ErikLightState.OFF -> false
            ErikLightState.ON -> true
            ErikLightState.BLINK -> "blink"
        }
}
