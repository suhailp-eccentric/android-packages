package com.eccentric.erik.android

internal object ErikBrowserCommand {
    fun init(stateJson: String): String = "__erik.init($stateJson)"

    fun setColor(colorName: String): String = "__erik.setColor('${colorName.escapeJsString()}')"

    fun setBGColor(hex: String): String = "__erik.setBGColor('${hex.escapeJsString()}')"

    fun toggleLights(lightsOn: Boolean): String = "__erik.toggleLights($lightsOn)"

    fun setLightState(
        light: ErikLight,
        state: ErikLightState,
    ): String = "__erik.setLightState('${light.jsName.escapeJsString()}', ${state.jsValue})"

    fun setRotationSpeed(speed: Double): String = "__erik.setRotationSpeed($speed)"

    fun goExterior(): String = "__erik.goExterior()"

    fun play(
        name: String,
        direction: String = "forward",
    ): String = "__erik.play('${name.escapeJsString()}', '${direction.escapeJsString()}')"

    fun allDoors(direction: String = "forward"): String = "__erik.allDoors('${direction.escapeJsString()}')"

    fun skipIntro(): String = "__erik.skipIntro()"

    fun getState(): String = "JSON.stringify(__erik.getState())"

    fun doorStates(): String = "JSON.stringify(__erik.doorStates())"

    private fun String.escapeJsString(): String =
        buildString {
            this@escapeJsString.forEach { char ->
                when (char) {
                    '\\' -> append("\\\\")
                    '\'' -> append("\\'")
                    '\n' -> append("\\n")
                    '\r' -> append("\\r")
                    else -> append(char)
                }
            }
        }
}
