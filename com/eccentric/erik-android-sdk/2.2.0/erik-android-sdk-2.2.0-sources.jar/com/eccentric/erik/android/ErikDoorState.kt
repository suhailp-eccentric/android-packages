package com.eccentric.erik.android

internal fun doorAnimationState(name: String, direction: String): ErikState? {
    val door = ErikDoor.entries.firstOrNull { it.jsName == name } ?: return null
    val open = when (direction) {
        door.openDirection -> true
        door.closeDirection -> false
        else -> return null
    }
    return ErikState(doorStates = mapOf(door to open))
}

internal fun allDoorsState(open: Boolean): ErikState =
    ErikState(doorStates = allDoorAnimationDoors.associateWith { open })

private val allDoorAnimationDoors = listOf(
    ErikDoor.FRONT_LEFT, ErikDoor.FRONT_RIGHT, ErikDoor.REAR_LEFT,
    ErikDoor.REAR_RIGHT, ErikDoor.BOOT, ErikDoor.SUNROOF,
)

internal fun allDoorsAnimationState(direction: String): ErikState? =
    when (direction) {
        "forward" -> allDoorsState(open = true)
        "reverse" -> allDoorsState(open = false)
        else -> null
    }
