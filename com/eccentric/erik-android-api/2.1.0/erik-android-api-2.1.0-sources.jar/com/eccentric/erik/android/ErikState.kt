package com.eccentric.erik.android

import java.io.Serializable
import org.json.JSONObject

data class ErikState(
    val startupCameraAnimation: Boolean? = null,
    val background: ErikBackgroundState? = null,
    val carpaint: String? = null,
    val lightsOn: Boolean? = null,
    val doorStates: Map<ErikDoor, Boolean>? = null,
    val lightStates: Map<ErikLight, ErikLightState>? = null,
    val lightBlinkInterval: Double? = null,
    val cameraAngle: ErikCameraAngle? = null,
    val rotationSpeed: Double? = null,
) : Serializable {
    /** Applies the non-null values from [next] on top of this state. */
    fun mergedWith(next: ErikState): ErikState =
        ErikState(
            startupCameraAnimation = next.startupCameraAnimation ?: startupCameraAnimation,
            background = background?.mergedWith(next.background) ?: next.background,
            carpaint = next.carpaint ?: carpaint,
            lightsOn = next.lightsOn ?: lightsOn,
            doorStates = mergeMaps(doorStates, next.doorStates),
            lightStates = mergeMaps(lightStates, next.lightStates),
            lightBlinkInterval = next.lightBlinkInterval ?: lightBlinkInterval,
            cameraAngle = next.cameraAngle ?: cameraAngle,
            rotationSpeed = next.rotationSpeed ?: rotationSpeed,
        )

    fun toJson(): String =
        JSONObject().apply {
            putIfNotNull("startupCameraAnimation", startupCameraAnimation)
            background?.let { put("background", it.toJsonObject()) }
            putIfNotNull("carpaint", carpaint)
            putIfNotNull("lightsOn", lightsOn)
            doorStates?.let { states ->
                put(
                    "doorStates",
                    JSONObject().apply {
                        ErikDoor.entries.forEach { door -> putIfNotNull(door.jsName, states[door]) }
                    },
                )
            }
            lightStates?.let { states ->
                put(
                    "lightStates",
                    JSONObject().apply {
                        ErikLight.entries.forEach { light ->
                            states[light]?.let { put(light.jsName, it.toJsonValue()) }
                        }
                    },
                )
            }
            putIfNotNull("lightBlinkInterval", lightBlinkInterval)
            cameraAngle?.let { put("cameraAngle", it.toJsonObject()) }
            putIfNotNull("rotationSpeed", rotationSpeed)
        }.toString()

    companion object {
        fun fromJson(json: String): ErikState {
            val value = JSONObject(json)
            val background = value.objectValue("background")
            val doors = value.objectValue("doorStates")
            val lights = value.objectValue("lightStates")
            val camera = value.objectValue("cameraAngle")
            return ErikState(
                startupCameraAnimation = value.booleanValue("startupCameraAnimation"),
                background =
                    if (value.has("background")) {
                        ErikBackgroundState(
                            transparent = background.booleanValue("transparent"),
                            color = background.stringValue("color"),
                        )
                    } else {
                        null
                    },
                carpaint = value.stringValue("carpaint"),
                lightsOn = value.booleanValue("lightsOn"),
                doorStates =
                    value.takeIf { it.has("doorStates") }?.let {
                        ErikDoor.entries.mapNotNull { door ->
                            doors.booleanValue(door.jsName)?.let { door to it }
                        }.toMap()
                    },
                lightStates =
                    value.takeIf { it.has("lightStates") }?.let {
                        ErikLight.entries.mapNotNull { light ->
                            lights.lightStateValue(light.jsName)?.let { light to it }
                        }.toMap()
                    },
                lightBlinkInterval = value.numberValue("lightBlinkInterval"),
                cameraAngle =
                    value.takeIf { it.has("cameraAngle") }?.let {
                        ErikCameraAngle(
                            azimuth = camera.numberValue("azimuth"),
                            elevation = camera.numberValue("elevation"),
                            radius = camera.numberValue("radius"),
                            focalLength = camera.numberValue("focalLength"),
                        ).takeIf(ErikCameraAngle::hasCompleteOrbit)
                    },
                rotationSpeed = value.numberValue("rotationSpeed"),
            )
        }
    }
}

private fun <K, V> mergeMaps(
    current: Map<K, V>?,
    next: Map<K, V>?,
): Map<K, V>? =
    when {
        current == null -> next
        next == null -> current
        else -> current + next
    }

data class ErikBackgroundState(
    val transparent: Boolean? = null,
    val color: String? = null,
) : Serializable

private fun ErikBackgroundState.toJsonObject(): JSONObject =
    JSONObject().apply {
        putIfNotNull("transparent", transparent)
        putIfNotNull("color", color)
    }

private fun ErikBackgroundState.mergedWith(next: ErikBackgroundState?): ErikBackgroundState =
    if (next == null) this else copy(
        transparent = next.transparent ?: transparent,
        color = next.color ?: color,
    )

data class ErikCameraAngle(
    val azimuth: Double? = null,
    val elevation: Double? = null,
    val radius: Double? = null,
    val focalLength: Double? = null,
) : Serializable {
    fun hasCompleteOrbit(): Boolean = azimuth != null && elevation != null && radius != null
}

private fun ErikCameraAngle.toJsonObject(): JSONObject =
    JSONObject().apply {
        put("azimuth", azimuth ?: JSONObject.NULL)
        put("elevation", elevation ?: JSONObject.NULL)
        put("radius", radius ?: JSONObject.NULL)
        put("focalLength", focalLength ?: JSONObject.NULL)
    }

interface ErikStateCallback {
    fun onSuccess(state: ErikState)

    fun onError(message: String)
}

private fun JSONObject.putIfNotNull(
    key: String,
    value: Any?,
) {
    if (value != null) put(key, value)
}

private fun JSONObject.stringValue(key: String): String? = opt(key) as? String

private fun JSONObject.booleanValue(key: String): Boolean? = opt(key) as? Boolean

private fun JSONObject.numberValue(key: String): Double? = (opt(key) as? Number)?.toDouble()

private fun JSONObject.objectValue(key: String): JSONObject = optJSONObject(key) ?: JSONObject()

private fun JSONObject.lightStateValue(key: String): ErikLightState? =
    when (opt(key)) {
        true -> ErikLightState.ON
        false -> ErikLightState.OFF
        "blink" -> ErikLightState.BLINK
        else -> null
    }

private fun ErikLightState.toJsonValue(): Any =
    when (this) {
        ErikLightState.OFF -> false
        ErikLightState.ON -> true
        ErikLightState.BLINK -> "blink"
    }
