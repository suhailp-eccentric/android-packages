package com.eccentric.erik.android

import org.json.JSONArray
import org.json.JSONObject

data class ErikColor(
    val name: String,
    val displayName: String,
)

data class ErikAssetConfig(
    val colors: List<ErikColor>,
    val id: String? = null,
    val version: String? = null,
) {
    fun toJson(): String =
        JSONObject().apply {
            putIfNotNull("id", id)
            putIfNotNull("version", version)
            put(
                "colors",
                JSONArray().apply {
                    colors.forEach { color ->
                        put(
                            JSONObject()
                                .put("name", color.name)
                                .put("displayName", color.displayName),
                        )
                    }
                },
            )
        }.toString()

    companion object {
        @JvmStatic
        fun fromJson(json: String): ErikAssetConfig {
            val value = JSONObject(json)
            val colorValues = requireNotNull(value.optJSONArray("colors")) {
                "Asset config is missing 'colors'."
            }
            val colors =
                (0 until colorValues.length()).map { index ->
                    val colorValue = colorValues.getJSONObject(index)
                    val color =
                        ErikColor(
                            name = requireNotNull(colorValue.stringValue("name")) {
                                "Color name is required."
                            },
                            displayName = requireNotNull(colorValue.stringValue("displayName")) {
                                "Color displayName is required."
                            },
                        )
                    require(color.name.isNotBlank()) { "Color name must not be blank." }
                    require(color.displayName.isNotBlank()) { "Color displayName must not be blank." }
                    color
                }
            require(colors.isNotEmpty()) { "Asset config must define at least one color." }
            require(colors.distinctBy(ErikColor::name).size == colors.size) {
                "Asset config contains duplicate color names."
            }
            return ErikAssetConfig(
                colors = colors,
                id = value.stringValue("id"),
                version = value.stringValue("version"),
            )
        }
    }
}

interface ErikColorsCallback {
    fun onSuccess(colors: List<ErikColor>)

    fun onError(message: String)
}

private fun JSONObject.putIfNotNull(
    key: String,
    value: Any?,
) {
    if (value != null) put(key, value)
}

private fun JSONObject.stringValue(key: String): String? = opt(key) as? String
