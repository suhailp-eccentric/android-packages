package com.eccentric.erik.android

data class ErikRuntimeState(
    val isInitializationComplete: Boolean = false,
    val isIntroAnimationPlaying: Boolean = false,
)
