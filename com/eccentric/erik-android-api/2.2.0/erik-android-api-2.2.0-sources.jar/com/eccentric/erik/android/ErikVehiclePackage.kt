package com.eccentric.erik.android

import org.json.JSONObject

/** Describes one downloadable vehicle package. */
data class ErikVehiclePackage(
    val id: String,
    val downloadUrl: String,
)

/** Reports whether a newer vehicle package is listed in the Erik catalog. */
data class ErikVehicleUpdateInfo(
    val vehicleId: String,
    val installedVersion: String?,
    val latestVersion: String,
    val updateAvailable: Boolean,
    val latestPackage: ErikVehiclePackage,
)

interface ErikVehicleUpdateCallback {
    fun onSuccess(update: ErikVehicleUpdateInfo)

    fun onError(message: String)
}

/** Reports vehicle package preparation progress. */
sealed interface ErikVehicleDownloadState {
    val vehicle: ErikVehiclePackage

    data class Checking(
        override val vehicle: ErikVehiclePackage,
    ) : ErikVehicleDownloadState

    data class Downloading(
        override val vehicle: ErikVehiclePackage,
        val downloadedBytes: Long,
        val totalBytes: Long?,
        val attempt: Int,
    ) : ErikVehicleDownloadState {
        val progressPercent: Int?
            get() =
                totalBytes
                    ?.takeIf { it > 0 }
                    ?.let { ((downloadedBytes * 100) / it).toInt().coerceIn(0, 100) }
    }

    data class Retrying(
        override val vehicle: ErikVehiclePackage,
        val nextAttempt: Int,
        val maximumAttempts: Int,
        val message: String,
    ) : ErikVehicleDownloadState

    data class Extracting(
        override val vehicle: ErikVehiclePackage,
    ) : ErikVehicleDownloadState

    data class Ready(
        override val vehicle: ErikVehiclePackage,
        /** True when preparation reused the package already stored on the device. */
        val reusedLocalPackage: Boolean,
        val capabilities: ErikVehicleCapabilities,
    ) : ErikVehicleDownloadState

    data class Failed(
        override val vehicle: ErikVehiclePackage,
        val message: String,
    ) : ErikVehicleDownloadState

    data class Cancelled(
        override val vehicle: ErikVehiclePackage,
    ) : ErikVehicleDownloadState
}

fun interface ErikVehicleDownloadListener {
    fun onStateChanged(state: ErikVehicleDownloadState)
}

/** Describes controls supported by a prepared vehicle package. */
data class ErikVehicleCapabilities(
    val hasSunroof: Boolean,
    val hasTaillight: Boolean,
    val hasTaillightUpper: Boolean,
    val hasTaillightLower: Boolean,
) {
    fun toJson(): String =
        JSONObject()
            .put("hasSunroof", hasSunroof)
            .put("hasTaillight", hasTaillight)
            .put("hasTaillightUpper", hasTaillightUpper)
            .put("hasTaillightLower", hasTaillightLower)
            .toString()

    companion object {
        @JvmStatic
        fun fromJson(json: String): ErikVehicleCapabilities {
            val value = JSONObject(json)
            return ErikVehicleCapabilities(
                hasSunroof = value.requiredBoolean("hasSunroof"),
                hasTaillight = value.requiredBoolean("hasTaillight"),
                hasTaillightUpper = value.requiredBoolean("hasTaillightUpper"),
                hasTaillightLower = value.requiredBoolean("hasTaillightLower"),
            )
        }

        @JvmStatic
        fun detectFromMicroInteractions(json: String): ErikVehicleCapabilities {
            val value = JSONObject(json)
            val doors = value.optJSONObject("doorStates")
            val lights = value.optJSONObject("lightStates")
            return ErikVehicleCapabilities(
                hasSunroof = doors?.has(ErikDoor.SUNROOF.jsName) == true,
                hasTaillight = lights?.has(ErikLight.TAILLIGHT.jsName) == true,
                hasTaillightUpper = lights?.has(ErikLight.TAILLIGHT_UPPER.jsName) == true,
                hasTaillightLower = lights?.has(ErikLight.TAILLIGHT_LOWER.jsName) == true,
            )
        }
    }
}

interface ErikVehicleCapabilitiesCallback {
    fun onSuccess(capabilities: ErikVehicleCapabilities)

    fun onError(message: String)
}

private fun JSONObject.requiredBoolean(key: String): Boolean =
    requireNotNull(opt(key) as? Boolean) { "Vehicle capabilities are missing '$key'." }

/** Controls one active vehicle package operation. */
interface ErikVehicleDownloadOperation {
    fun cancel()
}
