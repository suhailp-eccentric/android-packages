/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: /Users/suhailpatel94/Desktop/suhail/android-sdk/build-tools/35.0.0/aidl -p/Users/suhailpatel94/Desktop/suhail/android-sdk/platforms/android-35/framework.aidl -o/Users/suhailpatel94/Documents/projects/eccentric/erik-mobile-suite/packages/erik_android_sdk/api/build/generated/aidl_source_output_dir/release/out -I/Users/suhailpatel94/Documents/projects/eccentric/erik-mobile-suite/packages/erik_android_sdk/api/src/main/aidl -I/Users/suhailpatel94/Documents/projects/eccentric/erik-mobile-suite/packages/erik_android_sdk/api/src/release/aidl -d/var/folders/4j/c4ht4zwd5t39tb2q24001x7c0000gn/T/aidl14820945612156529468.d /Users/suhailpatel94/Documents/projects/eccentric/erik-mobile-suite/packages/erik_android_sdk/api/src/main/aidl/com/eccentric/erik/ipc/IErikRenderService.aidl
 */
package com.eccentric.erik.ipc;
public interface IErikRenderService extends android.os.IInterface
{
  /** Default implementation for IErikRenderService. */
  public static class Default implements com.eccentric.erik.ipc.IErikRenderService
  {
    @Override public int getProtocolVersion() throws android.os.RemoteException
    {
      return 0;
    }
    @Override public android.view.SurfaceControlViewHost.SurfacePackage createSession(long sessionId, android.os.IBinder hostToken, int displayId, int width, int height, java.lang.String initialStateJson, java.lang.String assetDirectoryPath, com.eccentric.erik.ipc.IErikClient client) throws android.os.RemoteException
    {
      return null;
    }
    @Override public void execute(long sessionId, long requestId, java.lang.String command, android.os.Bundle arguments, com.eccentric.erik.ipc.IErikClient client) throws android.os.RemoteException
    {
    }
    @Override public void resize(long sessionId, int width, int height) throws android.os.RemoteException
    {
    }
    @Override public void dispatchTouch(long sessionId, android.view.MotionEvent event) throws android.os.RemoteException
    {
    }
    @Override public void resumeSession(long sessionId) throws android.os.RemoteException
    {
    }
    @Override public void pauseSession(long sessionId) throws android.os.RemoteException
    {
    }
    @Override public void closeSession(long sessionId) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements com.eccentric.erik.ipc.IErikRenderService
  {
    /** Construct the stub at attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an com.eccentric.erik.ipc.IErikRenderService interface,
     * generating a proxy if needed.
     */
    public static com.eccentric.erik.ipc.IErikRenderService asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof com.eccentric.erik.ipc.IErikRenderService))) {
        return ((com.eccentric.erik.ipc.IErikRenderService)iin);
      }
      return new com.eccentric.erik.ipc.IErikRenderService.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_getProtocolVersion:
        {
          int _result = this.getProtocolVersion();
          reply.writeNoException();
          reply.writeInt(_result);
          break;
        }
        case TRANSACTION_createSession:
        {
          long _arg0;
          _arg0 = data.readLong();
          android.os.IBinder _arg1;
          _arg1 = data.readStrongBinder();
          int _arg2;
          _arg2 = data.readInt();
          int _arg3;
          _arg3 = data.readInt();
          int _arg4;
          _arg4 = data.readInt();
          java.lang.String _arg5;
          _arg5 = data.readString();
          java.lang.String _arg6;
          _arg6 = data.readString();
          com.eccentric.erik.ipc.IErikClient _arg7;
          _arg7 = com.eccentric.erik.ipc.IErikClient.Stub.asInterface(data.readStrongBinder());
          android.view.SurfaceControlViewHost.SurfacePackage _result = this.createSession(_arg0, _arg1, _arg2, _arg3, _arg4, _arg5, _arg6, _arg7);
          reply.writeNoException();
          _Parcel.writeTypedObject(reply, _result, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_execute:
        {
          long _arg0;
          _arg0 = data.readLong();
          long _arg1;
          _arg1 = data.readLong();
          java.lang.String _arg2;
          _arg2 = data.readString();
          android.os.Bundle _arg3;
          _arg3 = _Parcel.readTypedObject(data, android.os.Bundle.CREATOR);
          com.eccentric.erik.ipc.IErikClient _arg4;
          _arg4 = com.eccentric.erik.ipc.IErikClient.Stub.asInterface(data.readStrongBinder());
          this.execute(_arg0, _arg1, _arg2, _arg3, _arg4);
          break;
        }
        case TRANSACTION_resize:
        {
          long _arg0;
          _arg0 = data.readLong();
          int _arg1;
          _arg1 = data.readInt();
          int _arg2;
          _arg2 = data.readInt();
          this.resize(_arg0, _arg1, _arg2);
          break;
        }
        case TRANSACTION_dispatchTouch:
        {
          long _arg0;
          _arg0 = data.readLong();
          android.view.MotionEvent _arg1;
          _arg1 = _Parcel.readTypedObject(data, android.view.MotionEvent.CREATOR);
          this.dispatchTouch(_arg0, _arg1);
          break;
        }
        case TRANSACTION_resumeSession:
        {
          long _arg0;
          _arg0 = data.readLong();
          this.resumeSession(_arg0);
          break;
        }
        case TRANSACTION_pauseSession:
        {
          long _arg0;
          _arg0 = data.readLong();
          this.pauseSession(_arg0);
          break;
        }
        case TRANSACTION_closeSession:
        {
          long _arg0;
          _arg0 = data.readLong();
          this.closeSession(_arg0);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements com.eccentric.erik.ipc.IErikRenderService
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      @Override public int getProtocolVersion() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        int _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getProtocolVersion, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readInt();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public android.view.SurfaceControlViewHost.SurfacePackage createSession(long sessionId, android.os.IBinder hostToken, int displayId, int width, int height, java.lang.String initialStateJson, java.lang.String assetDirectoryPath, com.eccentric.erik.ipc.IErikClient client) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        android.view.SurfaceControlViewHost.SurfacePackage _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(sessionId);
          _data.writeStrongBinder(hostToken);
          _data.writeInt(displayId);
          _data.writeInt(width);
          _data.writeInt(height);
          _data.writeString(initialStateJson);
          _data.writeString(assetDirectoryPath);
          _data.writeStrongInterface(client);
          boolean _status = mRemote.transact(Stub.TRANSACTION_createSession, _data, _reply, 0);
          _reply.readException();
          _result = _Parcel.readTypedObject(_reply, android.view.SurfaceControlViewHost.SurfacePackage.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public void execute(long sessionId, long requestId, java.lang.String command, android.os.Bundle arguments, com.eccentric.erik.ipc.IErikClient client) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(sessionId);
          _data.writeLong(requestId);
          _data.writeString(command);
          _Parcel.writeTypedObject(_data, arguments, 0);
          _data.writeStrongInterface(client);
          boolean _status = mRemote.transact(Stub.TRANSACTION_execute, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void resize(long sessionId, int width, int height) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(sessionId);
          _data.writeInt(width);
          _data.writeInt(height);
          boolean _status = mRemote.transact(Stub.TRANSACTION_resize, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void dispatchTouch(long sessionId, android.view.MotionEvent event) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(sessionId);
          _Parcel.writeTypedObject(_data, event, 0);
          boolean _status = mRemote.transact(Stub.TRANSACTION_dispatchTouch, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void resumeSession(long sessionId) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(sessionId);
          boolean _status = mRemote.transact(Stub.TRANSACTION_resumeSession, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void pauseSession(long sessionId) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(sessionId);
          boolean _status = mRemote.transact(Stub.TRANSACTION_pauseSession, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void closeSession(long sessionId) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(sessionId);
          boolean _status = mRemote.transact(Stub.TRANSACTION_closeSession, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_getProtocolVersion = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_createSession = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
    static final int TRANSACTION_execute = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
    static final int TRANSACTION_resize = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
    static final int TRANSACTION_dispatchTouch = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
    static final int TRANSACTION_resumeSession = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
    static final int TRANSACTION_pauseSession = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
    static final int TRANSACTION_closeSession = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "com.eccentric.erik.ipc.IErikRenderService";
  public int getProtocolVersion() throws android.os.RemoteException;
  public android.view.SurfaceControlViewHost.SurfacePackage createSession(long sessionId, android.os.IBinder hostToken, int displayId, int width, int height, java.lang.String initialStateJson, java.lang.String assetDirectoryPath, com.eccentric.erik.ipc.IErikClient client) throws android.os.RemoteException;
  public void execute(long sessionId, long requestId, java.lang.String command, android.os.Bundle arguments, com.eccentric.erik.ipc.IErikClient client) throws android.os.RemoteException;
  public void resize(long sessionId, int width, int height) throws android.os.RemoteException;
  public void dispatchTouch(long sessionId, android.view.MotionEvent event) throws android.os.RemoteException;
  public void resumeSession(long sessionId) throws android.os.RemoteException;
  public void pauseSession(long sessionId) throws android.os.RemoteException;
  public void closeSession(long sessionId) throws android.os.RemoteException;
  /** @hide */
  static class _Parcel {
    static private <T> T readTypedObject(
        android.os.Parcel parcel,
        android.os.Parcelable.Creator<T> c) {
      if (parcel.readInt() != 0) {
          return c.createFromParcel(parcel);
      } else {
          return null;
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedObject(
        android.os.Parcel parcel, T value, int parcelableFlags) {
      if (value != null) {
        parcel.writeInt(1);
        value.writeToParcel(parcel, parcelableFlags);
      } else {
        parcel.writeInt(0);
      }
    }
  }
}
