package com.eccentric.erik.android

import org.json.JSONObject

/** Final door state after a hotspot action. */
data class ErikHotspotResult(
    val door: ErikDoor,
    val isOpen: Boolean,
    val errorMessage: String? = null,
    /** Command token used to preserve door command order. */
    val commandToken: String? = null,
) {
    val hotspotName: String get() = door.jsName

    fun toJson(): String = JSONObject().apply {
        put("type", "hotspot")
        put("name", hotspotName)
        put("open", isOpen)
        put("error", errorMessage ?: JSONObject.NULL)
        put("commandToken", commandToken ?: JSONObject.NULL)
    }.toString()

    companion object {
        fun fromJson(json: String): ErikHotspotResult? = runCatching {
            val value = JSONObject(json)
            if (value.opt("type") != "hotspot") return null
            val door = ErikDoor.entries.firstOrNull { it.jsName == value.opt("name") } ?: return null
            val open = value.opt("open") as? Boolean ?: return null
            val error = value.opt("error")
            if (error != null && error != JSONObject.NULL && error !is String) return null
            val token = value.opt("commandToken")
            if (token != null && token != JSONObject.NULL && token !is String) return null
            ErikHotspotResult(door, open, (error as? String)?.takeIf { it.isNotBlank() }, token as? String)
        }.getOrNull()
    }
}
