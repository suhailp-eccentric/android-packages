package com.eccentric.erik.android

data class ErikColor(
    val name: String,
    val displayName: String,
)

data class ErikAssetConfig(
    val colors: List<ErikColor>,
) {
    fun toJson(): String =
        colors.joinToString(
            separator = ",",
            prefix = "{\"colors\":[",
            postfix = "]}",
        ) { color ->
            """{"name":"${color.name.escapeJsonString()}","displayName":"${color.displayName.escapeJsonString()}"}"""
        }

    companion object {
        @JvmStatic
        fun fromJson(json: String): ErikAssetConfig {
            val colors =
                json.jsonArrayObjects("colors").map { colorJson ->
                    val color =
                        ErikColor(
                            name = requireNotNull(colorJson.stringValue("name")) {
                                "Color name is required."
                            },
                            displayName = requireNotNull(colorJson.stringValue("displayName")) {
                                "Color displayName is required."
                            },
                        )
                    require(color.name.isNotBlank()) { "Color name must not be blank." }
                    require(color.displayName.isNotBlank()) { "Color displayName must not be blank." }
                    color
                }
            require(colors.isNotEmpty()) { "Asset config must define at least one color." }
            require(colors.map(ErikColor::name).distinct().size == colors.size) {
                "Asset config contains duplicate color names."
            }
            return ErikAssetConfig(colors)
        }
    }
}

private fun String.jsonArrayObjects(key: String): List<String> {
    val keyMatch = Regex("\"${Regex.escape(key)}\"\\s*:").find(this)
        ?: error("Asset config is missing '$key'.")
    val arrayStart = indexOf('[', keyMatch.range.last + 1)
    require(arrayStart >= 0) { "Asset config '$key' must be an array." }

    val objects = mutableListOf<String>()
    var arrayDepth = 0
    var objectDepth = 0
    var objectStart = -1
    var inString = false
    var escaped = false
    var didCloseArray = false

    for (index in arrayStart until length) {
        val char = this[index]
        if (inString) {
            when {
                escaped -> escaped = false
                char == '\\' -> escaped = true
                char == '"' -> inString = false
            }
            continue
        }

        when (char) {
            '"' -> inString = true
            '[' -> arrayDepth += 1
            ']' -> {
                arrayDepth -= 1
                if (arrayDepth == 0) {
                    didCloseArray = true
                    break
                }
            }
            '{' -> {
                if (objectDepth == 0) objectStart = index
                objectDepth += 1
            }
            '}' -> {
                objectDepth -= 1
                if (objectDepth == 0 && objectStart >= 0) {
                    objects += substring(objectStart, index + 1)
                    objectStart = -1
                }
            }
        }
    }

    require(didCloseArray && objectDepth == 0) { "Asset config '$key' array is malformed." }
    return objects
}

interface ErikColorsCallback {
    fun onSuccess(colors: List<ErikColor>)

    fun onError(message: String)
}
