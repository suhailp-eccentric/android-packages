package com.eccentric.erik.android

import java.io.Serializable

enum class ErikLight(
    val jsName: String,
) {
    DRL("DRL"),
    FRONT_LEFT_HEADLIGHT("HL_FL"),
    FRONT_RIGHT_HEADLIGHT("HL_FR"),
    FRONT_LEFT_FOG_LIGHT("FOG_FL"),
    FRONT_RIGHT_FOG_LIGHT("FOG_FR"),
    TAILLIGHT_UPPER("TAILLIGHT_UPPER"),
    TAILLIGHT_LOWER("TAILLIGHT_LOWER"),
    FRONT_LEFT_DOOR_INDICATOR("DOOR_INDICATOR_LIGHT_FL"),
    FRONT_RIGHT_DOOR_INDICATOR("DOOR_INDICATOR_LIGHT_FR"),
}

enum class ErikLightState : Serializable {
    OFF,
    ON,
    BLINK,
    ;

    val jsValue: String
        get() =
            when (this) {
                OFF -> "false"
                ON -> "true"
                BLINK -> "\"blink\""
            }
}
