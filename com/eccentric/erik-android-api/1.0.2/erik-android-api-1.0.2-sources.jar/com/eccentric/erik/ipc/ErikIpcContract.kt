package com.eccentric.erik.ipc

object ErikIpcContract {
    const val RUNTIME_PACKAGE = "com.eccentric.erik.runtime"
    const val RUNTIME_SERVICE = "com.eccentric.erik.runtime.ErikRenderService"
    const val RUNTIME_ACTION = "com.eccentric.erik.runtime.BIND_RENDERER"
    const val PROTOCOL_VERSION = 4

    const val COMMAND_INIT = "init"
    const val COMMAND_OPEN_DOOR = "openDoor"
    const val COMMAND_CLOSE_DOOR = "closeDoor"
    const val COMMAND_SET_ALL_DOORS_OPEN = "setAllDoorsOpen"
    const val COMMAND_PLAY = "play"
    const val COMMAND_ALL_DOORS = "allDoors"
    const val COMMAND_GO_INTERIOR = "goInterior"
    const val COMMAND_GO_EXTERIOR = "goExterior"
    const val COMMAND_TOGGLE_LIGHTS = "toggleLights"
    const val COMMAND_SET_LIGHT_STATE = "setLightState"
    const val COMMAND_SET_ROTATION_SPEED = "setRotationSpeed"
    const val COMMAND_SET_COLOR = "setColor"
    const val COMMAND_SET_BG_COLOR = "setBGColor"
    const val COMMAND_SKIP_INTRO = "skipIntro"
    const val COMMAND_GET_STATE = "getState"
    const val COMMAND_DOOR_STATES = "doorStates"
    const val COMMAND_GET_ASSET_CONFIG = "getAssetConfig"

    const val ARG_STATE_JSON = "stateJson"
    const val ARG_DOOR = "door"
    const val ARG_OPEN = "open"
    const val ARG_NAME = "name"
    const val ARG_DIRECTION = "direction"
    const val ARG_LIGHTS_ON = "lightsOn"
    const val ARG_LIGHT = "light"
    const val ARG_LIGHT_STATE = "lightState"
    const val ARG_SPEED = "speed"
    const val ARG_COLOR = "color"
    const val ARG_HEX = "hex"
}
