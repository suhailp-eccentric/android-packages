package com.eccentric.erik.android

interface ErikJsonCallback {
    fun onSuccess(json: String)

    fun onError(message: String)
}
