/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: /Users/suhailpatel94/Desktop/suhail/android-sdk/build-tools/35.0.0/aidl -p/Users/suhailpatel94/Desktop/suhail/android-sdk/platforms/android-35/framework.aidl -o/Users/suhailpatel94/Documents/projects/eccentric/erik-mobile-suite/packages/erik_android_sdk/api/build/generated/aidl_source_output_dir/release/out -I/Users/suhailpatel94/Documents/projects/eccentric/erik-mobile-suite/packages/erik_android_sdk/api/src/main/aidl -I/Users/suhailpatel94/Documents/projects/eccentric/erik-mobile-suite/packages/erik_android_sdk/api/src/release/aidl -d/var/folders/4j/c4ht4zwd5t39tb2q24001x7c0000gn/T/aidl16086768714730423680.d /Users/suhailpatel94/Documents/projects/eccentric/erik-mobile-suite/packages/erik_android_sdk/api/src/main/aidl/com/eccentric/erik/ipc/IErikClient.aidl
 */
package com.eccentric.erik.ipc;
public interface IErikClient extends android.os.IInterface
{
  /** Default implementation for IErikClient. */
  public static class Default implements com.eccentric.erik.ipc.IErikClient
  {
    @Override public void onRuntimeStateChanged(long sessionId, boolean isReady, boolean isIntroAnimationPlaying, boolean isInitializing, boolean isInitializationComplete) throws android.os.RemoteException
    {
    }
    @Override public void onCommandResult(long sessionId, long requestId, boolean success, java.lang.String result, java.lang.String errorMessage) throws android.os.RemoteException
    {
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements com.eccentric.erik.ipc.IErikClient
  {
    /** Construct the stub at attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an com.eccentric.erik.ipc.IErikClient interface,
     * generating a proxy if needed.
     */
    public static com.eccentric.erik.ipc.IErikClient asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof com.eccentric.erik.ipc.IErikClient))) {
        return ((com.eccentric.erik.ipc.IErikClient)iin);
      }
      return new com.eccentric.erik.ipc.IErikClient.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_onRuntimeStateChanged:
        {
          long _arg0;
          _arg0 = data.readLong();
          boolean _arg1;
          _arg1 = (0!=data.readInt());
          boolean _arg2;
          _arg2 = (0!=data.readInt());
          boolean _arg3;
          _arg3 = (0!=data.readInt());
          boolean _arg4;
          _arg4 = (0!=data.readInt());
          this.onRuntimeStateChanged(_arg0, _arg1, _arg2, _arg3, _arg4);
          break;
        }
        case TRANSACTION_onCommandResult:
        {
          long _arg0;
          _arg0 = data.readLong();
          long _arg1;
          _arg1 = data.readLong();
          boolean _arg2;
          _arg2 = (0!=data.readInt());
          java.lang.String _arg3;
          _arg3 = data.readString();
          java.lang.String _arg4;
          _arg4 = data.readString();
          this.onCommandResult(_arg0, _arg1, _arg2, _arg3, _arg4);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements com.eccentric.erik.ipc.IErikClient
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      @Override public void onRuntimeStateChanged(long sessionId, boolean isReady, boolean isIntroAnimationPlaying, boolean isInitializing, boolean isInitializationComplete) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(sessionId);
          _data.writeInt(((isReady)?(1):(0)));
          _data.writeInt(((isIntroAnimationPlaying)?(1):(0)));
          _data.writeInt(((isInitializing)?(1):(0)));
          _data.writeInt(((isInitializationComplete)?(1):(0)));
          boolean _status = mRemote.transact(Stub.TRANSACTION_onRuntimeStateChanged, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
      @Override public void onCommandResult(long sessionId, long requestId, boolean success, java.lang.String result, java.lang.String errorMessage) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeLong(sessionId);
          _data.writeLong(requestId);
          _data.writeInt(((success)?(1):(0)));
          _data.writeString(result);
          _data.writeString(errorMessage);
          boolean _status = mRemote.transact(Stub.TRANSACTION_onCommandResult, _data, null, android.os.IBinder.FLAG_ONEWAY);
        }
        finally {
          _data.recycle();
        }
      }
    }
    static final int TRANSACTION_onRuntimeStateChanged = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_onCommandResult = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "com.eccentric.erik.ipc.IErikClient";
  public void onRuntimeStateChanged(long sessionId, boolean isReady, boolean isIntroAnimationPlaying, boolean isInitializing, boolean isInitializationComplete) throws android.os.RemoteException;
  public void onCommandResult(long sessionId, long requestId, boolean success, java.lang.String result, java.lang.String errorMessage) throws android.os.RemoteException;
}
