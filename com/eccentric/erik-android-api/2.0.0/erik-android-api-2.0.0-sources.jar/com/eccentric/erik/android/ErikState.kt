package com.eccentric.erik.android

import java.io.Serializable

data class ErikState(
    val startupCameraAnimation: Boolean? = null,
    val background: ErikBackgroundState? = null,
    val carpaint: String? = null,
    val lightsOn: Boolean? = null,
    val doorStates: Map<ErikDoor, Boolean>? = null,
    val lightStates: Map<ErikLight, ErikLightState>? = null,
    val lightBlinkInterval: Double? = null,
    val cameraAngle: ErikCameraAngle? = null,
    val rotationSpeed: Double? = null,
) : Serializable {
    /**
     * Applies the non-null values from [next] on top of this state.
     *
     * Nested background values and per-door/per-light maps are merged so
     * callers can safely build a configuration through multiple partial
     * [ErikState] instances.
     */
    fun mergedWith(next: ErikState): ErikState =
        ErikState(
            startupCameraAnimation = next.startupCameraAnimation ?: startupCameraAnimation,
            background =
                when {
                    background == null -> next.background
                    next.background == null -> background
                    else ->
                        ErikBackgroundState(
                            transparent = next.background.transparent ?: background.transparent,
                            color = next.background.color ?: background.color,
                        )
                },
            carpaint = next.carpaint ?: carpaint,
            lightsOn = next.lightsOn ?: lightsOn,
            doorStates = mergeMaps(doorStates, next.doorStates),
            lightStates = mergeMaps(lightStates, next.lightStates),
            lightBlinkInterval = next.lightBlinkInterval ?: lightBlinkInterval,
            cameraAngle = next.cameraAngle ?: cameraAngle,
            rotationSpeed = next.rotationSpeed ?: rotationSpeed,
        )

    fun toJson(): String =
        buildJsonObject {
            putIfNotNull("startupCameraAnimation", startupCameraAnimation)
            background?.let { putRaw("background", it.toJson()) }
            putStringIfNotNull("carpaint", carpaint)
            putIfNotNull("lightsOn", lightsOn)
            doorStates?.let { states ->
                putRaw(
                    "doorStates",
                    buildJsonObject {
                        ErikDoor.entries.forEach { door ->
                            states[door]?.let { put(door.jsName, it) }
                        }
                    },
                )
            }
            lightStates?.let { states ->
                putRaw(
                    "lightStates",
                    buildJsonObject {
                        ErikLight.entries.forEach { light ->
                            states[light]?.let { putRaw(light.jsName, it.jsValue) }
                        }
                    },
                )
            }
            putNumberIfNotNull("lightBlinkInterval", lightBlinkInterval)
            cameraAngle?.let { putRaw("cameraAngle", it.toJson()) }
            putNumberIfNotNull("rotationSpeed", rotationSpeed)
        }

    companion object {
        fun fromJson(json: String): ErikState {
            require(json.trim().startsWith("{")) { "Erik state JSON must be an object." }

            val hasBackground = json.hasJsonKey("background")
            val hasDoorStates = json.hasJsonKey("doorStates")
            val hasLightStates = json.hasJsonKey("lightStates")
            val hasCameraAngle = json.hasJsonKey("cameraAngle")
            val backgroundJson = json.extractJsonObject("background")
            val doorStatesJson = json.extractJsonObject("doorStates")
            val lightStatesJson = json.extractJsonObject("lightStates")
            val cameraAngleJson = json.extractJsonObject("cameraAngle")

            return ErikState(
                startupCameraAnimation = json.booleanValue("startupCameraAnimation"),
                background =
                    if (hasBackground) {
                        ErikBackgroundState(
                            transparent = backgroundJson.booleanValue("transparent"),
                            color = backgroundJson.stringValue("color"),
                        )
                    } else {
                        null
                    },
                carpaint = json.stringValue("carpaint"),
                lightsOn = json.booleanValue("lightsOn"),
                doorStates =
                    if (hasDoorStates) {
                        ErikDoor.entries
                            .mapNotNull { door ->
                                if (doorStatesJson.hasJsonKey(door.jsName)) {
                                    doorStatesJson.booleanValue(door.jsName)?.let { door to it }
                                } else {
                                    null
                                }
                            }.toMap()
                    } else {
                        null
                    },
                lightStates =
                    if (hasLightStates) {
                        ErikLight.entries
                            .mapNotNull { light ->
                                if (lightStatesJson.hasJsonKey(light.jsName)) {
                                    lightStatesJson.lightStateValue(light.jsName)?.let { light to it }
                                } else {
                                    null
                                }
                            }.toMap()
                    } else {
                        null
                    },
                lightBlinkInterval = json.numberValue("lightBlinkInterval"),
                cameraAngle =
                    if (hasCameraAngle) {
                        ErikCameraAngle(
                            azimuth = cameraAngleJson.numberValue("azimuth"),
                            elevation = cameraAngleJson.numberValue("elevation"),
                            radius = cameraAngleJson.numberValue("radius"),
                            focalLength = cameraAngleJson.numberValue("focalLength"),
                        ).takeIf { it.hasCompleteOrbit() }
                    } else {
                        null
                    },
                rotationSpeed = json.numberValue("rotationSpeed"),
            )
        }
    }
}

private fun <K, V> mergeMaps(
    current: Map<K, V>?,
    next: Map<K, V>?,
): Map<K, V>? =
    when {
        current == null -> next
        next == null -> current
        else -> current + next
    }

data class ErikBackgroundState(
    val transparent: Boolean? = null,
    val color: String? = null,
) : Serializable {
    internal fun toJson(): String =
        buildJsonObject {
            putIfNotNull("transparent", transparent)
            putStringIfNotNull("color", color)
        }
}

data class ErikCameraAngle(
    val azimuth: Double? = null,
    val elevation: Double? = null,
    val radius: Double? = null,
    val focalLength: Double? = null,
) : Serializable {
    fun hasCompleteOrbit(): Boolean = azimuth != null && elevation != null && radius != null

    internal fun toJson(): String =
        buildJsonObject {
            putNumberOrNull("azimuth", azimuth)
            putNumberOrNull("elevation", elevation)
            putNumberOrNull("radius", radius)
            putNumberOrNull("focalLength", focalLength)
        }
}

interface ErikStateCallback {
    fun onSuccess(state: ErikState)

    fun onError(message: String)
}

private class JsonObjectBuilder {
    private val entries = mutableListOf<String>()

    fun put(
        key: String,
        value: Boolean,
    ) {
        putRaw(key, value.toString())
    }

    fun putIfNotNull(
        key: String,
        value: Boolean?,
    ) {
        value?.let { put(key, it) }
    }

    fun putStringIfNotNull(
        key: String,
        value: String?,
    ) {
        value?.let { putRaw(key, "\"${it.escapeJsonString()}\"") }
    }

    fun putNumberOrNull(
        key: String,
        value: Double?,
    ) {
        putRaw(key, value?.toString() ?: "null")
    }

    fun putNumberIfNotNull(
        key: String,
        value: Double?,
    ) {
        value?.let { putRaw(key, it.toString()) }
    }

    fun putRaw(
        key: String,
        value: String,
    ) {
        entries += "\"${key.escapeJsonString()}\":$value"
    }

    fun build(): String = entries.joinToString(separator = ",", prefix = "{", postfix = "}")
}

private fun buildJsonObject(block: JsonObjectBuilder.() -> Unit): String =
    JsonObjectBuilder().apply(block).build()

private fun String.hasJsonKey(key: String): Boolean =
    Regex("\"${Regex.escape(key)}\"\\s*:").containsMatchIn(this)

private fun String.extractJsonObject(key: String): String {
    val keyIndex = indexOf("\"$key\"")
    if (keyIndex == -1) {
        return "{}"
    }

    val start = indexOf('{', keyIndex)
    if (start == -1) {
        return "{}"
    }

    var depth = 0
    for (index in start until length) {
        when (this[index]) {
            '{' -> depth += 1
            '}' -> {
                depth -= 1
                if (depth == 0) {
                    return substring(start, index + 1)
                }
            }
        }
    }

    return "{}"
}

private fun String.booleanValue(key: String): Boolean? =
    Regex("\"${Regex.escape(key)}\"\\s*:\\s*(true|false)")
        .find(this)
        ?.groupValues
        ?.getOrNull(1)
        ?.toBooleanStrictOrNull()

internal fun String.stringValue(key: String): String? =
    Regex("\"${Regex.escape(key)}\"\\s*:\\s*(null|\"((?:\\\\.|[^\"\\\\])*)\")")
        .find(this)
        ?.let { match ->
            if (match.groupValues.getOrNull(1) == "null") {
                null
            } else {
                match.groupValues.getOrNull(2)?.unescapeJsonString()
            }
        }

private fun String.numberValue(key: String): Double? =
    Regex("\"${Regex.escape(key)}\"\\s*:\\s*(-?\\d+(?:\\.\\d+)?(?:[eE][+-]?\\d+)?|null)")
        .find(this)
        ?.groupValues
        ?.getOrNull(1)
        ?.let { value -> if (value == "null") null else value.toDoubleOrNull() }

private fun String.lightStateValue(key: String): ErikLightState? =
    Regex("\"${Regex.escape(key)}\"\\s*:\\s*(true|false|\"blink\")")
        .find(this)
        ?.groupValues
        ?.getOrNull(1)
        ?.let { value ->
            when (value) {
                "true" -> ErikLightState.ON
                "false" -> ErikLightState.OFF
                "\"blink\"" -> ErikLightState.BLINK
                else -> null
            }
        }

internal fun String.escapeJsonString(): String =
    buildString {
        this@escapeJsonString.forEach { char ->
            when (char) {
                '\\' -> append("\\\\")
                '"' -> append("\\\"")
                '\n' -> append("\\n")
                '\r' -> append("\\r")
                else -> append(char)
            }
        }
    }

private fun String.unescapeJsonString(): String =
    buildString {
        var index = 0
        while (index < this@unescapeJsonString.length) {
            val char = this@unescapeJsonString[index]
            if (char == '\\' && index + 1 < this@unescapeJsonString.length) {
                when (val escaped = this@unescapeJsonString[index + 1]) {
                    '\\' -> append('\\')
                    '"' -> append('"')
                    'n' -> append('\n')
                    'r' -> append('\r')
                    else -> append(escaped)
                }
                index += 2
            } else {
                append(char)
                index += 1
            }
        }
    }
