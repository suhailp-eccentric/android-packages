package com.eccentric.erik.android

data class ErikRuntimeState(
    val isReady: Boolean = false,
    val isIntroAnimationPlaying: Boolean = false,
    val isInitializing: Boolean = false,
    val isInitializationComplete: Boolean = false,
)
