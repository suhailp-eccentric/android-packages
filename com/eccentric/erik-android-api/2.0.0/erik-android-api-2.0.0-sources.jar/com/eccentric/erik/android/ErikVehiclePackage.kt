package com.eccentric.erik.android

/** Describes one downloadable vehicle package. */
data class ErikVehiclePackage(
    val id: String,
    val downloadUrl: String,
)

/** Reports whether a newer vehicle package is listed in the Erik catalog. */
data class ErikVehicleUpdateInfo(
    val vehicleId: String,
    val installedVersion: String?,
    val latestVersion: String,
    val updateAvailable: Boolean,
    val latestPackage: ErikVehiclePackage,
)

interface ErikVehicleUpdateCallback {
    fun onSuccess(update: ErikVehicleUpdateInfo)

    fun onError(message: String)
}

/** Reports vehicle package preparation progress. */
sealed interface ErikVehicleDownloadState {
    val vehicle: ErikVehiclePackage

    data class Checking(
        override val vehicle: ErikVehiclePackage,
    ) : ErikVehicleDownloadState

    data class Downloading(
        override val vehicle: ErikVehiclePackage,
        val downloadedBytes: Long,
        val totalBytes: Long?,
        val attempt: Int,
    ) : ErikVehicleDownloadState {
        val progressPercent: Int?
            get() =
                totalBytes
                    ?.takeIf { it > 0 }
                    ?.let { ((downloadedBytes * 100) / it).toInt().coerceIn(0, 100) }
    }

    data class Retrying(
        override val vehicle: ErikVehiclePackage,
        val nextAttempt: Int,
        val maximumAttempts: Int,
        val message: String,
    ) : ErikVehicleDownloadState

    data class Extracting(
        override val vehicle: ErikVehiclePackage,
    ) : ErikVehicleDownloadState

    data class Ready(
        override val vehicle: ErikVehiclePackage,
        val fromCache: Boolean,
        val capabilities: ErikVehicleCapabilities,
    ) : ErikVehicleDownloadState

    data class Failed(
        override val vehicle: ErikVehiclePackage,
        val message: String,
    ) : ErikVehicleDownloadState

    data class Cancelled(
        override val vehicle: ErikVehiclePackage,
    ) : ErikVehicleDownloadState
}

fun interface ErikVehicleDownloadListener {
    fun onStateChanged(state: ErikVehicleDownloadState)
}

/** Describes controls supported by a prepared vehicle package. */
data class ErikVehicleCapabilities(
    val hasSunroof: Boolean,
    val hasRegularTaillight: Boolean,
    val hasSplitTaillights: Boolean,
) {
    fun toJson(): String =
        """{"hasSunroof":$hasSunroof,"hasRegularTaillight":$hasRegularTaillight,"hasSplitTaillights":$hasSplitTaillights}"""

    companion object {
        @JvmStatic
        fun fromJson(json: String): ErikVehicleCapabilities =
            ErikVehicleCapabilities(
                hasSunroof = json.requiredBoolean("hasSunroof"),
                hasRegularTaillight = json.requiredBoolean("hasRegularTaillight"),
                hasSplitTaillights = json.requiredBoolean("hasSplitTaillights"),
            )

        @JvmStatic
        fun detectFromMicroInteractions(json: String): ErikVehicleCapabilities =
            ErikVehicleCapabilities(
                hasSunroof = json.contains("\"SUNROOF\""),
                hasRegularTaillight = json.contains("\"TAILLIGHT\""),
                hasSplitTaillights =
                    json.contains("\"TAILLIGHT_UPPER\"") ||
                        json.contains("\"TAILLIGHT_LOWER\""),
            )
    }
}

interface ErikVehicleCapabilitiesCallback {
    fun onSuccess(capabilities: ErikVehicleCapabilities)

    fun onError(message: String)
}

private fun String.requiredBoolean(key: String): Boolean =
    requireNotNull(
        Regex("\"${Regex.escape(key)}\"\\s*:\\s*(true|false)")
            .find(this)
            ?.groupValues
            ?.get(1)
            ?.toBooleanStrictOrNull(),
    ) { "Vehicle capabilities are missing '$key'." }

/** Controls one active vehicle package operation. */
interface ErikVehicleDownloadOperation {
    fun cancel()
}
