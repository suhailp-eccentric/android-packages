package com.eccentric.erik.android

import android.content.Context
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.os.Build
import android.view.MotionEvent
import android.view.SurfaceControlViewHost
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.RequiresApi

/**
 * A temporary visual attachment to the process-scoped [RemoteErikSession].
 *
 * Destroying this view detaches its surface but deliberately leaves the
 * renderer session alive for the next screen.
 */
@RequiresApi(Build.VERSION_CODES.R)
internal class RemoteErikView(
    context: Context,
    endpoint: ErikServiceEndpoint = ErikServiceEndpoint.external(),
) : FrameLayout(context) {
    private val session = RemoteErikSession.get(context, endpoint)
    private val surfaceView =
        SurfaceView(context).apply {
            setZOrderOnTop(!session.isShowingInterior())
            holder.setFormat(PixelFormat.TRANSPARENT)
            setOnTouchListener { view, event ->
                if (!session.isShowingInterior()) {
                    return@setOnTouchListener false
                }
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN,
                    MotionEvent.ACTION_MOVE,
                    -> view.parent?.requestDisallowInterceptTouchEvent(true)

                    MotionEvent.ACTION_UP,
                    MotionEvent.ACTION_CANCEL,
                    -> view.parent?.requestDisallowInterceptTouchEvent(false)
                }
                session.dispatchTouch(event)
            }
            layoutParams =
                LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT,
                )
        }

    private var attachedSurfacePackage: SurfaceControlViewHost.SurfacePackage? = null
    private var listener: ((ErikRuntimeState) -> Unit)? = null
    private var resumed = false
    private var destroyed = false

    init {
        addView(surfaceView)
        surfaceView.holder.addCallback(
            object : SurfaceHolder.Callback {
                override fun surfaceCreated(holder: SurfaceHolder) {
                    requestAttachment()
                }

                override fun surfaceChanged(
                    holder: SurfaceHolder,
                    format: Int,
                    width: Int,
                    height: Int,
                ) {
                    requestAttachment()
                }

                override fun surfaceDestroyed(holder: SurfaceHolder) {
                    if (!destroyed) {
                        session.detach(this@RemoteErikView)
                        releaseSurfacePackage()
                    }
                }
            },
        )
    }

    fun setListener(listener: ((ErikRuntimeState) -> Unit)?) {
        this.listener = listener
        session.setListener(this, listener)
    }

    fun currentState(): ErikRuntimeState = session.currentState()

    fun initialize(
        state: ErikState,
        callback: ErikCommandCallback,
    ) {
        session.initialize(state, callback)
    }

    fun initializeForAttachment(
        state: ErikState,
        applyExplicitState: Boolean,
        callback: ErikCommandCallback,
    ) {
        session.initializeForAttachment(state, applyExplicitState, callback)
    }

    fun getState(callback: ErikJsonCallback) {
        session.getState(callback)
    }

    fun getAssetConfig(callback: ErikJsonCallback) {
        session.getAssetConfig(callback)
    }

    fun openDoor(
        door: ErikDoor,
        callback: ErikCommandCallback,
    ) {
        session.openDoor(door, callback)
    }

    fun closeDoor(
        door: ErikDoor,
        callback: ErikCommandCallback,
    ) {
        session.closeDoor(door, callback)
    }

    fun setAllDoorsOpen(
        open: Boolean,
        callback: ErikCommandCallback,
    ) {
        session.setAllDoorsOpen(open, callback)
    }

    fun play(
        name: String,
        direction: String,
        callback: ErikCommandCallback,
    ) {
        session.play(name, direction, callback)
    }

    fun allDoors(
        direction: String,
        callback: ErikCommandCallback,
    ) {
        session.allDoors(direction, callback)
    }

    fun goInterior(callback: ErikCommandCallback) {
        session.goInterior(callback)
        setInteriorComposition(interior = true)
    }

    fun goExterior(callback: ErikCommandCallback) {
        session.goExterior(callback)
        setInteriorComposition(interior = false)
    }

    fun toggleLights(
        lightsOn: Boolean,
        callback: ErikCommandCallback,
    ) {
        session.toggleLights(lightsOn, callback)
    }

    fun setLightState(
        light: ErikLight,
        state: ErikLightState,
        callback: ErikCommandCallback,
    ) {
        session.setLightState(light, state, callback)
    }

    fun setRotationSpeed(
        speed: Double,
        callback: ErikCommandCallback,
    ) {
        session.setRotationSpeed(speed, callback)
    }

    fun setColor(
        colorName: String,
        callback: ErikCommandCallback,
    ) {
        session.setColor(colorName, callback)
    }

    fun setBGColor(
        hex: String,
        callback: ErikCommandCallback,
    ) {
        session.setBGColor(hex, callback)
    }

    fun skipIntro(callback: ErikCommandCallback) {
        session.skipIntro(callback)
    }

    fun doorStates(callback: ErikJsonCallback) {
        session.doorStates(callback)
    }

    fun resume() {
        resumed = true
        session.resume(this)
    }

    fun pause() {
        resumed = false
        session.pause(this)
    }

    fun destroy() {
        if (destroyed) {
            return
        }
        destroyed = true
        session.detach(this)
        listener = null
        releaseSurfacePackage()
        removeAllViews()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        requestAttachment()
    }

    override fun onDetachedFromWindow() {
        if (!destroyed) {
            pause()
            session.detach(this)
            releaseSurfacePackage()
        }
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(
        width: Int,
        height: Int,
        oldWidth: Int,
        oldHeight: Int,
    ) {
        super.onSizeChanged(width, height, oldWidth, oldHeight)
        requestAttachment()
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            attachedSurfacePackage?.notifyConfigurationChanged(newConfig)
        }
    }

    @Suppress("DEPRECATION")
    private fun requestAttachment() {
        val hostToken = surfaceView.hostToken ?: return
        val currentDisplay = display ?: return
        if (destroyed || !isAttachedToWindow || width <= 0 || height <= 0) {
            return
        }
        session.setListener(this, listener)
        session.attach(
            owner = this,
            hostToken = hostToken,
            displayId = currentDisplay.displayId,
            width = width,
            height = height,
            onSurfacePackage = ::attachSurfacePackage,
            onSurfaceLost = ::releaseSurfacePackage,
            onError = {
                releaseSurfacePackage()
            },
        )
        if (resumed) {
            session.resume(this)
        }
    }

    private fun attachSurfacePackage(surfacePackage: SurfaceControlViewHost.SurfacePackage) {
        releaseSurfacePackage()
        attachedSurfacePackage = surfacePackage
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            surfacePackage.notifyConfigurationChanged(resources.configuration)
        }
        surfaceView.setChildSurfacePackage(surfacePackage)
    }

    private fun releaseSurfacePackage() {
        attachedSurfacePackage = null
    }

    private fun setInteriorComposition(interior: Boolean) {
        surfaceView.setZOrderOnTop(!interior)
    }
}
